---
name: paper-to-markdown
description: >-
  Convert a paper PDF (an article, working paper, report or book) to markdown once, so every later
  chat works from the stored copy. Use it before opening, extracting or summarizing a paper PDF,
  even for a quick look at the abstract: "read this paper", "what does Table 3 report", "summarize
  this PDF", or any task that hands over a PDF path. A script converts with pymupdf4llm's layout
  model (headings, page markers, regression tables as markdown tables, figures and display
  equations saved as images, broken ligatures repaired) and stores the copy beside the PDF or in a
  folder the user picks, matched to the PDF by its md5 fingerprint. The first run sets up a Python
  environment for the converter and asks where copies go. An optional Claude Code hook (a check run
  before each tool call) sends direct PDF reads to the stored copy. It does not cover scanned PDFs
  (they need OCR), PDF file operations such as merging or filling forms, or a paper whose LaTeX
  source is at hand.
---

# Paper PDFs Converted Once and Stored as Markdown

A PDF opened directly costs its pages again in every chat that opens it, so a 40-page paper opened
in three chats is paid for three times. This skill converts each paper once into a markdown copy
(`paper.pdf` gets `paper.md`), and every later request works from that copy. The copy is matched to
the PDF by its md5, a fingerprint computed from the file's bytes, so a replaced or revised PDF is
noticed and converted again, and the same file saved under two names is converted only once.

## First run: settings (required once)

The script needs two settings it cannot guess: a Python environment that holds the converter, and
the place where the user wants the stored copies. Both are saved in
`~/.claude/paper-to-markdown/settings.json`, outside the skill folder, so installing a newer version
of the skill keeps them. The same folder holds the converter's virtual environment (when the user
picks one) and `index.tsv`, the list of every conversion.

Every run of the script prints a `SETTINGS` line after its status line. State it to the user in one
line the first time it appears in a chat ("Copies go beside each PDF, and PDFs from Downloads go to
~/Documents/papers_md"). When the script prints `SETUP` instead, run the setup below before anything
else.

Where nothing persists between chats (the Claude apps without a file system), say so and run the
setup in each chat that needs it, with the store in a folder the chat can write to (the chat's
outputs folder): `--interpreter venv --store <that folder>`. It needs Python 3.10 or newer and
access to the Python package index. If the virtual environment cannot be built there, setup prints
the next step for the chat's own Python. Offer the `.md` file and its figures folder as downloads at
the end, so the user can attach the copy to later chats or add it to a Claude Project's knowledge.
This route has not been tested in a Claude app chat, so say so when using it.

### The setup questions

Ask in ONE question card (the `AskUserQuestion` tool when available, else a short numbered list),
each with a recommendation:

1. **Converter environment.** "The converter (pymupdf4llm with its layout model) needs Python 3.10
   or newer. Where do you want it installed?"
   - `A separate environment for this skill` (recommended): a virtual environment in
     `~/.claude/paper-to-markdown/venv`, built from a Python 3.10 or newer found on this computer.
     It keeps the converter's packages apart from every other project. About 110 MB to download
     and about 270 MB on disk.
   - `An environment I already use`: the user names its Python (a conda environment or a virtual
     environment). Installing there can change the versions of packages that other projects in
     that environment use, numpy among them.
2. **Where copies go.**
   - `Beside each PDF` (recommended): `paper.pdf` gets `paper.md` and `paper_figures/` in the same
     folder, so the copy stays with the paper. PDFs in Downloads, on the Desktop, in a temporary
     folder or loose in the home folder are stored in `~/Documents/papers_md/` (the user can name
     another folder).
   - `One folder I name`: every copy goes to that folder, in one subfolder per source folder, and
     project folders stay untouched.
3. **Folders kept free of copies (optional).** "Is there a folder where the skill must never
   write?" Recommend none unless the user names one, and sort each answer into one of two cases:
   - a folder of the user's own compiled drafts, or one that syncs to an online LaTeX editor
     (`--own-drafts`): copies of its PDFs go to the store folder, and the read hook lets Claude
     open its PDFs page by page
   - any other folder (`--no-write`): copies of its PDFs go to the store folder, and the read hook
     still sends its papers to the stored copy
4. **Read hook (Claude Code only).** "Do you want Claude Code stopped from opening paper PDFs
   directly, so every request goes through the stored copy? This adds one entry to
   `~/.claude/settings.json`. It acts only on PDFs that look like research papers (an abstract,
   keywords or JEL codes on the first pages) and on PDFs already converted. Other PDFs, such as a
   contract, a statement, a form or a slide deck, pass untouched." Options: `Yes, add the hook`
   (recommended for anyone who works with many papers: in testing, chats that saw this skill listed
   still opened the PDF directly) and `Not now`. The entry and how to remove it are in
   `references/read_hook.md`. Add it only after this yes, since it changes the user's Claude Code
   configuration.

Then tell the user that setup downloads about 110 MB, and run it with the answers:

```bash
python3 -I "<skill folder>/scripts/setup_env.py" --interpreter venv --store beside
```

| Answer | Option |
|-----------------------------------|----------------------------------------------------------|
| separate environment | `--interpreter venv` |
| an environment the user names | `--interpreter /path/to/python --install` |
| beside each PDF | `--store beside` (add `--fallback-folder FOLDER` to choose the store folder) |
| one folder | `--store FOLDER` |
| a folder of the user's own drafts or one that syncs to an editor | `--own-drafts FOLDER` (repeat for each) |
| another folder to keep free of copies | `--no-write FOLDER` (added to Downloads and Desktop) |

`<skill folder>` is the folder holding this file (in Claude Code usually
`~/.claude/skills/paper-to-markdown`). Setup ends with a `SETTINGS` line and `READY`. With no
Python 3.10 or newer on the computer it prints `SETUP` and how to install one. Running it again
with only the options to change keeps the other answers. `references/setup.md` has the manual
commands, the repair steps and the settings file's fields.

## The read hook (optional)

A skill's description lets a chat find the skill, and the chat may still open the PDF directly. The
hook runs `scripts/pdf_read_hook.py` before every Read and Bash call. The hook is narrow, since a
hook that refused a contract, a bank statement or a CV would get in the way in every chat, so a
doubtful PDF passes. A PDF counts as a paper when it already has a stored copy (here or for another
folder), or when its first three pages hold an abstract, keywords or JEL codes and an introduction,
with none of the words typical of a CV or a conference program (curriculum vitae, discussant,
session, chair). These pass untouched even when they look like papers: a PDF in a
folder saved with `--own-drafts`, a PDF with a `.tex` of the same name beside it (a compiled draft
or deck, checked page by page), an exhibit file of 2 pages or fewer holding under 3,000 characters
of text, a slide deck (a landscape first page), and a fillable form. A paper the test misses, such
as a book, passes too, and the script converts it when run by hand. Then:

| Call | Hook |
|-------------------------------------------------|-------------------------------------------------|
| any request for a paper with no stored copy | refuses it and prints the conversion command |
| a whole-PDF read or full text extraction, copy stored | refuses it and names the stored copy |
| chosen pages (Read with `pages`, `pdftotext -f -l`), copy stored | lets it through with a note naming the copy |
| any other PDF, and a PDF the script marked scanned | does nothing |

A refusal is the hook working: run the command it prints and work from the stored copy. Wildcards
(`pdftotext *.pdf`) are expanded, so a sweep over a folder is caught too. A Bash command that starts
with `PAPER_MD_SKIP=1` passes untouched, for file operations (merging, splitting, rendering pages
for a slide) and for sweeps over many PDFs. The hook lets every call through when it fails, so it
never blocks other work.

## Step 1: The script, run before the PDF is opened

```bash
python3 -I "<skill folder>/scripts/paper_md.py" "<path to the PDF>"
```

Any Python 3.9 or newer starts the script. When a conversion is needed it switches to the
converter's interpreter saved in the settings, so the command stays the same wherever the converter
lives. The first line it prints decides what happens next:

| Status | Meaning | Next |
|-----------------------------|-----------------------------------------------|-------------------------------|
| `FRESH <name.md>` | the stored copy matches the PDF | open that file, convert nothing |
| `COPIED <name.md> (...)` | the same file was converted for another folder | open the copy now placed here |
| `CONVERTED <name.md> (...)` | converted now, first time or after the PDF changed | open that file |
| `SCANNED <pdf>` | half the pages or more have no text layer | stop, see "Content outside the copy" |
| `SETUP ...` | no settings yet, or the converter is missing | run the first-run setup |
| `ERROR ...` | not a PDF, a name clash where the copy goes, or a file or store folder it cannot read or write | fix what it names |

- **Options.** `--check` reports `FRESH`, `STALE` or `MISSING` and converts nothing. `--force`
  converts again.
- **NOTE lines.** A `NOTE` names image-only pages inside an otherwise digital PDF (see "Content
  outside the copy"), a converter version other than the tested one (check one table against the
  PDF page), or a git repository whose `.gitignore` does not cover the new copy. Act on the git
  note before any commit in that repository: a stored copy of someone else's paper is never
  committed, so add the copy and its figures folder (or `*_figures/` and the copies' names) to that
  repository's `.gitignore` first.
- **Time.** The test papers (42 and 56 pages) took 3 and 7 seconds. A book-length PDF takes under a
  minute. Run the script in the foreground.

## Step 2: The stored copy

- **The header first.** The lines above the first `---` give the source path, the page count, how
  many figures and equations are stored as images, and any image-only pages.
- **The outline before the text, for a long paper.** `grep -n '^#' <name>.md` lists the headings
  with line numbers. Open the sections the task needs by line range, or the whole file in order
  when the task is the whole paper.
- **Page markers** (`<!-- page 12 -->`) precede each page's text. Cite a page from them.
- **Tables** are markdown tables with their notes below: coefficients with their standard errors in
  parentheses on the row beneath, stars, and observation counts, each in its column. A header that
  spans columns can come out cut across cells (a country name set over four columns came out as
  `Ethi` and `opia`): rejoin the pieces, and quote a header only from the PDF.
- **Display equations and figures are image links** (`![equation, page 11](<name_figures/p011_01.png>)`).
  Open the image with Read only when the task needs that equation or figure, and open it before
  quoting any display equation, since the text around it holds only inline math in italics.
- **Numbers that go into the user's own writing** are checked against the PDF page once, at the
  page the marker names. The copy is accurate (97% to 100% of the numbers in the source tables of
  the test papers were found in it), and the check makes a quoted number safe to use. A preprint
  can differ from the published article, so confirm which version the PDF is before citing a
  number from it.

## Storage locations

- **Beside the PDF, under its name** (`--store beside`): `<folder>/<name>.pdf` gets
  `<folder>/<name>.md` and `<folder>/<name>_figures/`. The first line of the `.md` is a comment
  holding the PDF's md5, page count, converter version and repair counts, which is how the script
  and the hook recognize the copy. A `<name>.md` that already exists and was not made by this skill
  (the user's own notes) stays untouched, and the copy is then `<name>_paper.md`.
- **In the store folder:** every copy under `--store FOLDER`, and under `--store beside` the copy of
  any PDF in a folder the skill does not write into (Downloads, Desktop, temporary folders, the home
  folder itself, the folders named at setup, and any folder the user cannot write to). The copy
  goes to
  `<store folder>/<source folder name>_<code>/<name>.md`, where the 6-character code comes from the
  source folder's full path, so two folders with the same name keep separate subfolders.
- **`index.tsv`** in the settings folder lists every conversion by md5, copy and PDF path. When the
  same file sits in a second folder, the script copies the existing `.md` and its figures to the new
  location and converts nothing (`COPIED`). Never edit the index by hand.
- **When a PDF changes,** the previous `.md` moves to `_archive_paper_md/` in the same folder under
  the old md5, and the old figures are replaced.

## Content outside the copy

- **Scanned pages.** A PDF whose pages are images has no text to convert. If a skill for scanned
  documents (OCR) is installed, use it. Otherwise add a text layer with an OCR program (for
  example `ocrmypdf input.pdf output.pdf`) and run the script on the output, or, for a few pages,
  open them with Read and `pages` and work from the page images. A `NOTE` about image-only pages
  inside an otherwise digital PDF calls for the same route on those pages.
- **Exact math.** Display equations are images. When the LaTeX source exists (the user's own draft,
  or the source files of an arXiv preprint), use the `.tex` for equations, labels and exhibit
  numbers.
- **Vector figures as data.** A figure is a picture of the plot. A value taken from a figure by eye
  is an estimate, and is reported as one.

## Reference files

- `references/setup.md`: the converter environment, the manual install routes, the settings file's
  fields, repair after a missing-package error, and the test before upgrading the converter.
- `references/read_hook.md`: the optional hook's `settings.json` entry, turning it on and off,
  testing it, and the PDFs it lets through unchecked.
- `references/limits.md`: the known defects of the stored copy, each with what to do.
- `references/route_comparison.md`: why this route was chosen over the other converters, with the
  scores.
- `scripts/paper_md.py` (the converter), `scripts/setup_env.py` (first-run setup),
  `scripts/pdf_read_hook.py` (the optional hook) and `scripts/score_against_latex.py` (the test
  before upgrading the converter, in `references/setup.md`).

## Related tools

- **Skills that work from paper text** (a review, a literature summary, a journal choice) run this
  script on the PDF first and work from the stored copy. LaTeX source, where it exists, still wins
  for exact equations.
- **PDF file operations** (merge, split, rotate, fill a form, add a searchable text layer) belong to
  a PDF tool, such as Anthropic's `pdf` skill where it is installed.
- **Out of scope:** a `.tex` file, a spreadsheet, and a PDF form to fill.

#!/usr/bin/env python3
"""Convert a paper PDF to markdown once, store the copy, and reuse it on every later request

Usage:
    python3 -I paper_md.py <paper.pdf> [--check] [--force]

Any Python 3.9 or newer starts the script. A conversion needs pymupdf4llm and its layout model
(Python 3.10 or newer); when the interpreter running the script lacks them, the script runs itself
again under the interpreter that setup_env.py saved in the settings.

Prints one status line first:
    FRESH <name.md>               the stored copy matches the PDF's md5; read it, convert nothing
    COPIED <name.md> ...          the same file was converted for another folder; copy placed here
    CONVERTED <name.md> ...       converted now (first time, or the PDF changed)
    SCANNED <pdf> ...             half the pages or more have no text layer; the file needs OCR
    MISSING <pdf>                 --check found no copy
    STALE <name.md>               --check found a copy of an older version of the PDF
    SETUP <reason>                setup has not run, or the converter is missing; run setup_env.py
    ERROR <reason>                not a PDF, or a name clash beside it
then a SETTINGS line saying where copies go and which interpreter converts, and any NOTE lines.
Exit codes: 0 FRESH, COPIED or CONVERTED, 2 error, 3 SCANNED, 4 MISSING or STALE under --check,
5 SETUP

Settings: <PAPER_MD_HOME>/settings.json, written by setup_env.py. PAPER_MD_HOME defaults to
~/.claude/paper-to-markdown, outside the skill folder, so a newer version of the skill keeps it.
The same folder holds index.tsv, one line per conversion (md5, copy, PDF, date), so the same file
saved in a second folder gets the existing copy placed beside it with no second conversion.

Where the copy goes:
    storage "beside":  <folder>/<name>.pdf  ->  <folder>/<name>.md  and  <folder>/<name>_figures/
    storage "folder":  <store folder>/<source folder name>_<6 hex>/<name>.md  and  <name>_figures/
    A PDF in a no-write folder (Downloads, Desktop, a temporary folder, the home folder itself, every
    folder listed in the settings, and any folder the user cannot write to) is stored in the store
    folder even under "beside".
    The first line of <name>.md is a comment holding the PDF's md5 and the conversion record, so a
    changed PDF is converted again. If <name>.md already exists and is not a copy made here, the
    copy is <name>_paper.md.
"""

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from pathlib import Path

HOME = Path.home()
APP_HOME = Path(os.environ.get("PAPER_MD_HOME") or (HOME / ".claude" / "paper-to-markdown")).expanduser()
SETTINGS = APP_HOME / "settings.json"
INDEX = APP_HOME / "index.tsv"
BUILD = APP_HOME / "build"
# The versions the route was measured with (references/route_comparison.md); setup_env.py installs them
PINNED = {"pymupdf4llm": "1.28.0", "pymupdf-layout": "1.28.0"}
DEFAULT_NO_WRITE = ["~/Downloads", "~/Desktop"]
TEMP_ROOTS = [tempfile.gettempdir(), "/tmp", "/private/tmp", "/var/folders", "/private/var/folders"]
TAG = "<!-- paper-to-markdown "
ROUTE = "pymupdf4llm layout"
ARCHIVE = "_archive_paper_md"
MIN_CHARS = 50          # a page with fewer extracted characters than this counts as image-only
SCANNED_SHARE = 0.5     # at least this share of image-only pages and the file needs OCR
DPI = 150
CHILD_FLAG = "PAPER_MD_CHILD"


# ---------------------------------------------------------------------------- settings

def load_settings():
    """The saved settings as a dict, or None when setup has not run"""
    try:
        with open(SETTINGS, encoding="utf-8") as f:
            s = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(s, dict) or s.get("storage") not in ("beside", "folder") or not s.get("store_folder"):
        return None
    s.setdefault("no_write_folders", list(DEFAULT_NO_WRITE))
    s.setdefault("own_draft_folders", [])
    return s


def expand(p):
    return Path(os.path.expandvars(str(p))).expanduser()


def short(p):
    """A path with the home folder written as ~"""
    p = str(p)
    h = str(HOME)
    return "~" + p[len(h):] if p == h or p.startswith(h + os.sep) else p


def settings_line(s):
    """One line saying what the settings hold"""
    store = short(expand(s["store_folder"]))
    no_write = ", ".join(short(expand(p)) for p in s["no_write_folders"]) or "none"
    drafts = ", ".join(short(expand(p)) for p in s["own_draft_folders"]) or "none"
    if s["storage"] == "beside":
        where = (f"copies beside each PDF; PDFs in {no_write}, temporary folders and the home folder "
                 f"go to {store}")
    else:
        where = f"every copy in {store} (one subfolder per source folder)"
    return f"SETTINGS {where} | own-draft folders, never written: {drafts} | converter: {s.get('python') or 'not set'}"


# ---------------------------------------------------------------------------- locations

def md5_of(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def slug(text):
    s = re.sub(r"[^A-Za-z0-9_-]+", "_", text).strip("_")
    return (s or "papers")[:60].rstrip("_-")


def is_under(path, root):
    try:
        Path(path).resolve().relative_to(Path(root).resolve())
        return True
    except (ValueError, OSError):
        return False


def in_draft_folder(pdf, s):
    return any(is_under(pdf, expand(p)) for p in s["own_draft_folders"])


def no_write(pdf, s):
    """True when nothing may be written beside this PDF, by the settings or by the folder's permissions"""
    roots = [expand(p) for p in s["no_write_folders"]] + [Path(t) for t in TEMP_ROOTS]
    return (in_draft_folder(pdf, s) or any(is_under(pdf, r) for r in roots)
            or pdf.parent.resolve() == HOME.resolve() or not os.access(str(pdf.parent), os.W_OK))


def folder_key(folder):
    """One subfolder of the store per source folder: its name plus 6 hex of its full path"""
    tag = hashlib.md5(str(folder.resolve()).encode("utf-8")).hexdigest()[:6]
    return f"{slug(folder.name)}_{tag}"


def candidates(pdf, s):
    """The two places a copy of this PDF can sit: <name>.md, then <name>_paper.md"""
    if s["storage"] == "beside" and not no_write(pdf, s):
        base = pdf.parent
    else:
        base = expand(s["store_folder"]) / folder_key(pdf.parent)
    return [base / f"{pdf.stem}.md", base / f"{pdf.stem}_paper.md"]


def figures_dir(md):
    return md.with_name(md.stem + "_figures")


def read_meta(md):
    """The conversion record on the first line of a copy made here, or None"""
    try:
        with open(md, encoding="utf-8") as f:
            first = f.readline().strip()
    except (OSError, UnicodeDecodeError):
        return None
    if not first.startswith(TAG) or not first.endswith("-->"):
        return None
    try:
        return json.loads(first[len(TAG):-3])
    except ValueError:
        return None


def find_copy(pdf, md5, s):
    """Return (state, md) with state 'fresh', 'scanned', 'stale' or 'none', and the path to write"""
    target = None
    for md in candidates(pdf, s):
        meta = read_meta(md) if md.exists() else None
        if md.exists() and meta is None:
            continue
        if meta and meta.get("md5") == md5:
            return ("scanned" if meta.get("scanned") else "fresh"), md
        if meta:
            return "stale", md
        target = target or md
    return "none", target


def read_index():
    rows = []
    if INDEX.exists():
        for line in INDEX.read_text(encoding="utf-8").splitlines():
            parts = line.split("\t")
            if len(parts) >= 3 and not line.startswith("md5\t"):
                rows.append(parts)
    return rows


def copy_elsewhere(md5):
    """A fresh copy of the same file made for another folder, or None"""
    for row in reversed(read_index()):
        other = Path(row[1])
        if row[0] == md5 and other.suffix == ".md" and other.exists():
            meta = read_meta(other)
            if meta and meta.get("md5") == md5 and not meta.get("scanned"):
                return other
    return None


def append_index(md5, md, pdf):
    APP_HOME.mkdir(parents=True, exist_ok=True)
    new = not INDEX.exists()
    with open(INDEX, "a", encoding="utf-8", newline="\n") as f:
        if new:
            f.write("md5\tcopy\tpdf\tconverted\n")
        f.write(f"{md5}\t{md}\t{pdf}\t{dt.date.today().isoformat()}\n")


def git_warning(md):
    """Name the repository when the copy sits inside a git working tree and is not ignored"""
    try:
        top = subprocess.run(["git", "-C", str(md.parent), "rev-parse", "--show-toplevel"],
                             capture_output=True, text=True, timeout=20)
        if top.returncode != 0:
            return None
        root = top.stdout.strip()
        ignored = subprocess.run(["git", "-C", root, "check-ignore", "-q", str(md)], timeout=20)
    except (OSError, subprocess.SubprocessError):
        return None
    return None if ignored.returncode == 0 else root


# ---------------------------------------------------------------------------- conversion

def converter_import():
    """Import the converter, or return None when this interpreter lacks it"""
    try:
        import pymupdf
        import pymupdf4llm
        import pymupdf.layout  # noqa: F401
    except ImportError:
        return None
    return pymupdf, pymupdf4llm


def rerun_under_settings_python(s):
    """Run this script again under the interpreter saved in the settings; returns only on failure"""
    py = s.get("python")
    if not py or os.environ.get(CHILD_FLAG) or not expand(py).exists():
        return
    env = dict(os.environ)
    env[CHILD_FLAG] = "1"
    sys.stdout.flush()
    os.execve(str(expand(py)), [str(expand(py)), "-I", str(Path(__file__).resolve())] + sys.argv[1:], env)


def text_layer(doc):
    """Characters of text per page, and the 1-based pages that are image-only"""
    chars = [len(p.get_text().strip()) for p in doc]
    image_only = [i + 1 for i, c in enumerate(chars) if c < MIN_CHARS and doc[i].get_images()]
    return chars, image_only


def vocabulary(doc):
    words = Counter()
    for p in doc:
        words.update(w.lower() for w in re.findall(r"[A-Za-z]+", p.get_text()))
    return words


def repair_ligatures(md, vocab):
    """Restore fi, fl, ff, ffi and ffl the layout route drops in some table and caption fonts

    A word is changed only when it is absent from the PDF's own plain text and exactly one
    restoration gives a word that text contains
    """
    fixes = Counter()

    def fix(m):
        w = m.group(0)
        lw = w.lower()
        if lw in vocab or "f" not in lw:
            return w
        cands = set()
        for i, ch in enumerate(lw):
            if ch == "f":
                for ins in ("i", "l", "f", "fi", "fl"):
                    c = lw[:i + 1] + ins + lw[i + 1:]
                    if c in vocab:
                        cands.add((i, ins))
        if len(cands) != 1:
            return w
        i, ins = cands.pop()
        upper = w[i + 1:i + 2].isupper() and w[:i + 1].isupper()
        new = w[:i + 1] + (ins.upper() if upper else ins) + w[i + 1:]
        fixes[f"{w} -> {new}"] += 1
        return new

    out = re.sub(r"(?<![A-Za-z])[A-Za-z]+(?![A-Za-z])", fix, md)
    return out, fixes


def classify(png):
    """Label a stored image as an equation or a figure from its shape"""
    import pymupdf
    pix = pymupdf.Pixmap(str(png))
    w, h = pix.width, pix.height
    return ("equation" if h < 0.15 * 11 * DPI and w > 2.5 * h else "figure"), w, h


def build_folder():
    """A plainly named temporary folder for the images

    pymupdf4llm rewrites spaces and brackets in the image path it is given, so the images are built
    under a folder whose path holds none and are moved beside the copy afterwards
    """
    root = BUILD
    if re.search(r"[^A-Za-z0-9_./-]", str(root)):
        root = Path(tempfile.mkdtemp(prefix="paper_md_")).resolve()
    tmp = root / f"p{os.getpid()}"
    if tmp.exists():
        shutil.rmtree(tmp)
    tmp.mkdir(parents=True)
    return tmp


def remove_build(tmp):
    """Delete a build folder, and the temporary root above it when one was made for it"""
    shutil.rmtree(tmp, ignore_errors=True)
    if tmp.parent.resolve() != BUILD.resolve():
        shutil.rmtree(tmp.parent, ignore_errors=True)


def convert(doc, md, pymupdf4llm):
    """Convert into a temporary figures folder; return (folder, body, kinds)"""
    pymupdf4llm.use_layout(True)
    tmp = build_folder()
    try:
        chunks = pymupdf4llm.to_markdown(doc, page_chunks=True, write_images=True,
                                         image_path=str(tmp), image_format="png", dpi=DPI,
                                         use_ocr=False, header=False, footer=False)
    except BaseException:
        remove_build(tmp)
        raise
    fig_name = figures_dir(md).name
    pages, kinds = [], Counter()
    link = re.compile(r"!\[[^\]]*\]\(([^)]+\.png)\)")
    for c in chunks:
        n = c["metadata"]["page_number"]
        text, k = c["text"], 0

        def relink(m):
            nonlocal k
            src = Path(m.group(1))
            if not src.exists():
                return m.group(0)
            k += 1
            name = f"p{n:03d}_{k:02d}.png"
            src.rename(tmp / name)
            kind, w, h = classify(tmp / name)
            kinds[kind] += 1
            return f"![{kind}, page {n}](<{fig_name}/{name}>)"

        text = link.sub(relink, text)
        pages.append(f"<!-- page {n} -->\n\n{text.strip()}\n")
    for leftover in tmp.glob("*.pdf-*.png"):
        leftover.unlink()
    return tmp, "\n\n".join(pages), kinds


def header(meta, title, pdf, kinds, image_only):
    pages_note = ", ".join(map(str, image_only)) if image_only else "none"
    return "\n".join([
        TAG + json.dumps(meta, ensure_ascii=False) + " -->",
        "<!-- Converted once from the PDF named below by the paper-to-markdown skill. Read this file in",
        "     place of the PDF; open a figure or equation image only when its content is needed. -->",
        "",
        f"**Stored copy of:** {title}",
        "",
        f"- Source PDF: `{pdf}`",
        f"- md5 {meta['md5']}, {meta['pages']} pages, converted {meta['converted'][:10]} "
        f"with pymupdf4llm {meta.get('pymupdf4llm', '')} (layout model)",
        f"- Images in `{meta.get('figures_folder', '')}/`: {kinds.get('figure', 0)} figures, "
        f"{kinds.get('equation', 0)} equations; a display equation is stored as an image, so open it "
        "before quoting the math",
        f"- Image-only pages (no text layer, read them as images or after OCR): {pages_note}",
        "",
        "---",
        "",
    ])


def archive(md):
    """Move an older copy's text into the archive folder beside it and drop its figures"""
    meta = read_meta(md) or {}
    arch = md.parent / ARCHIVE
    arch.mkdir(exist_ok=True)
    md.rename(arch / f"{md.stem}_{str(meta.get('md5', 'unknown'))[:8]}.md")
    if figures_dir(md).exists():
        shutil.rmtree(figures_dir(md))


def place_copy(src, md, pdf):
    """Copy a fresh copy of the same file, and its figures, to this PDF's copy location"""
    text = src.read_text(encoding="utf-8")
    first, rest = text.split("\n", 1)
    meta = read_meta(src)
    meta["pdf"] = str(pdf)
    meta["copied_from"] = str(src)
    meta["figures_folder"] = figures_dir(md).name
    old_fig, new_fig = figures_dir(src).name, figures_dir(md).name
    rest = rest.replace(f"](<{old_fig}/", f"](<{new_fig}/")
    source_line = f"- Source PDF: `{pdf}`"
    rest = re.sub(r"^- Source PDF: `.*`$", lambda m: source_line, rest, count=1, flags=re.M)
    rest = rest.replace(f"`{old_fig}/`", f"`{new_fig}/`")
    md.parent.mkdir(parents=True, exist_ok=True)
    try:
        if figures_dir(src).exists():
            shutil.copytree(figures_dir(src), figures_dir(md))
        with open(md, "w", encoding="utf-8", newline="\n") as f:
            f.write(TAG + json.dumps(meta, ensure_ascii=False) + " -->\n" + rest)
    except OSError:
        shutil.rmtree(figures_dir(md), ignore_errors=True)
        raise


def write_text(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


# ---------------------------------------------------------------------------- main

def setup_message(reason):
    script = Path(__file__).resolve().parent / "setup_env.py"
    return (f"SETUP {reason}. Run the first-run setup in SKILL.md, which ends with "
            f"python3 -I \"{script}\" --interpreter venv --store beside")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("pdf")
    ap.add_argument("--check", action="store_true", help="report the state of the copy, convert nothing")
    ap.add_argument("--force", action="store_true", help="convert even when a fresh copy exists")
    a = ap.parse_args()
    try:
        return run(a)
    except OSError as e:
        where = e.filename or "the copy's folder"
        print(f"ERROR could not read or write {where} ({e.strerror or e}). Check that the PDF can be read, "
              "and choose a store folder you can write to with setup_env.py --store FOLDER or "
              "--fallback-folder FOLDER (references/setup.md)")
        return 2


def run(a):
    s = load_settings()
    if s is None:
        print(setup_message(f"no settings at {SETTINGS}"))
        return 5
    pdf = Path(a.pdf).expanduser().resolve()
    if not pdf.is_file() or pdf.suffix.lower() != ".pdf":
        print(f"ERROR not a PDF file: {pdf}")
        return 2
    md5 = md5_of(pdf)
    state, md = find_copy(pdf, md5, s)
    if md is None:
        names = [c.name for c in candidates(pdf, s)]
        print(f"ERROR both {names[0]} and {names[1]} exist where the copy goes and neither is a copy "
              "made by this skill; move one of them")
        return 2
    if state == "fresh" and not a.force:
        print(f"FRESH {md}")
        print(settings_line(s))
        return 0
    if state == "scanned" and not a.force:
        print(f"SCANNED {pdf}: image-only, the file needs OCR (see SKILL.md, Content outside the copy)")
        print(settings_line(s))
        return 3
    if not a.force:
        other = copy_elsewhere(md5)
        if other and other.resolve() != md.resolve():
            if a.check:
                first = f"STALE {md}" if state == "stale" else f"MISSING {pdf}"
                print(f"{first} (a copy of the same file exists at {other})")
                print(settings_line(s))
                return 4
            if state == "stale":
                archive(md)
            place_copy(other, md, pdf)
            append_index(md5, md, pdf)
            print(f"COPIED {md} (same file as {read_meta(other).get('pdf')}, no conversion)")
            print(settings_line(s))
            return 0
    if a.check:
        print(f"STALE {md}" if state == "stale" else f"MISSING {pdf}")
        print(settings_line(s))
        return 4

    mods = converter_import()
    if mods is None:
        rerun_under_settings_python(s)
        print(setup_message(f"the interpreter {sys.executable} lacks pymupdf4llm or its layout model, "
                            f"and the saved converter ({s.get('python') or 'none'}) could not be used"))
        return 5
    pymupdf, pymupdf4llm = mods

    doc = pymupdf.open(str(pdf))
    chars, image_only = text_layer(doc)
    now = dt.datetime.now().isoformat(timespec="seconds")
    md.parent.mkdir(parents=True, exist_ok=True)
    if len(image_only) >= SCANNED_SHARE * doc.page_count:
        # Leave a marked copy so later reads skip conversion and the read hook lets its pages through
        if state == "stale":
            archive(md)
        meta = {"md5": md5, "pdf": str(pdf), "pages": doc.page_count, "scanned": True, "converted": now}
        write_text(md, TAG + json.dumps(meta, ensure_ascii=False) + " -->\n\n"
                   f"`{pdf.name}` is a scan: {len(image_only)} of {doc.page_count} pages have no text layer. "
                   "Read it as page images or after OCR.\n")
        append_index(md5, md, pdf)
        print(f"SCANNED {pdf} ({len(image_only)} of {doc.page_count} pages have no text layer): "
              "the file needs OCR (see SKILL.md, Content outside the copy)")
        print(settings_line(s))
        return 3

    tmp, body, kinds = convert(doc, md, pymupdf4llm)
    try:
        return store(doc, pdf, md, md5, state, s, tmp, body, kinds, image_only, now, pymupdf, pymupdf4llm)
    finally:
        if tmp.exists():
            remove_build(tmp)


def store(doc, pdf, md, md5, state, s, tmp, body, kinds, image_only, now, pymupdf, pymupdf4llm):
    """Write the copy, move its figures beside it, record it, and print the status"""
    body, fixes = repair_ligatures(body, vocabulary(doc))
    title = ((doc.metadata or {}).get("title") or "").strip() or pdf.stem
    meta = {
        "md5": md5, "pdf": str(pdf), "bytes": pdf.stat().st_size, "pages": doc.page_count,
        "converted": now, "route": ROUTE, "pymupdf4llm": pymupdf4llm.__version__,
        "pymupdf": pymupdf.__version__, "dpi": DPI, "figures_folder": figures_dir(md).name,
        "figures": kinds["figure"], "equations": kinds["equation"], "image_only_pages": image_only,
        "ligature_repairs": sum(fixes.values()), "markdown_chars": len(body),
    }
    if state == "stale":
        archive(md)
    elif figures_dir(md).exists():
        shutil.rmtree(figures_dir(md))
    write_text(md, header(meta, title, pdf, kinds, image_only) + body)
    if any(tmp.iterdir()):
        shutil.move(str(tmp), str(figures_dir(md)))
    if tmp.parent.resolve() != BUILD.resolve():
        remove_build(tmp)
    append_index(md5, md, pdf)

    print(f"CONVERTED {md} ({doc.page_count} pages, {len(body):,} characters, about {len(body) // 4:,} tokens, "
          f"{kinds['figure']} figures, {kinds['equation']} equations, {sum(fixes.values())} ligature repairs)")
    print(settings_line(s))
    if pymupdf4llm.__version__ != PINNED["pymupdf4llm"]:
        print(f"NOTE pymupdf4llm {pymupdf4llm.__version__} differs from the tested {PINNED['pymupdf4llm']}; "
              "check one table against the PDF page before relying on table output (references/setup.md)")
    if image_only:
        print(f"NOTE pages {', '.join(map(str, image_only))} have no text layer: read them as images or after OCR")
    repo = git_warning(md)
    if repo:
        print(f"NOTE {md.name} sits inside the git repository {repo} and is not ignored; add it, or the "
              "folder's *.md copies and *_figures/ folders, to that repository's .gitignore before any commit")
    return 0


if __name__ == "__main__":
    sys.exit(main())

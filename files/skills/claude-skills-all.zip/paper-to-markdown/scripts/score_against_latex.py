#!/usr/bin/env python3
"""Score a stored markdown copy against the paper's LaTeX source, to compare two converter versions

Usage:
    python3 -I score_against_latex.py <copy.md> --main <main.tex> [--tables <table.tex> ...]

Three measures, printed one per line:
    TABLE NUMBERS  every decimal number in the table files (layout lengths such as 1.8ex removed):
                   the share found anywhere in the copy, and the share found on a markdown table row
    HEADINGS       every section and subsection title of the main file: the share found on a markdown
                   heading line, compared after lowercasing and dropping everything but letters
    BODY TEXT      every paragraph of the main file with at least 25 words, after a simple removal of
                   LaTeX commands, math and floats: the share of its five-word sequences found in the
                   copy, averaged over paragraphs

The LaTeX cleaning is simple, so the body-text share sits several points below what a careful
cleaning gives (about 90% on the two public test papers). Use the script to compare two converter
versions on the same paper with the same files.
--tables defaults to every file the main file pulls in with \\input that holds a table environment
(tabular, longtable and similar). A table typed inside the main file is scored only when the main
file is also passed with --tables.
"""

import argparse
import re
import sys
from collections import Counter
from pathlib import Path

NUM = re.compile(r"(?<![\d.])-?\d+\.\d+(?![\d.])")
LENGTH = re.compile(r"-?\d+(?:\.\d+)?\s*(?:ex|em|pt|cm|mm|in|bp|\\textwidth|\\linewidth|\\hsize|\\columnwidth)\b")
SETTING = re.compile(r"(?:scale|width|height)\s*=\s*-?\d+(?:\.\d+)?")
TABLE_ENV = re.compile(r"\\begin\{(?:tabular|longtable|tabularx|tabulary|tabu)\b")
DROP_ENVS = ("figure", "table", "equation", "align", "eqnarray", "gather", "multline", "tabular",
             "thebibliography", "displaymath", "math")


def uncomment(tex):
    return re.sub(r"(?<!\\)%.*", "", tex)


def numbers(text):
    return [n.lstrip("-") for n in NUM.findall(text)]


def letters(text):
    return re.sub(r"[^a-z]", "", text.lower())


def words(text):
    return re.findall(r"[a-z0-9]+", text.lower())


def grams(ws, n=5):
    return {tuple(ws[i:i + n]) for i in range(len(ws) - n + 1)}


def table_files(main, src):
    """Files the main file pulls in with \\input that hold a table environment"""
    found = []
    for name in re.findall(r"\\input\{([^}]+)\}", src):
        p = (main.parent / name)
        p = p if p.suffix == ".tex" else p.with_name(p.name + ".tex")
        if p.is_file() and TABLE_ENV.search(p.read_text(encoding="utf-8", errors="replace")):
            found.append(p)
    return found


def table_scores(md, tables):
    rows = "\n".join(line for line in md.splitlines() if line.lstrip().startswith("|"))
    in_md, in_rows = Counter(numbers(md)), Counter(numbers(rows))
    total = found = on_rows = 0
    for tex in tables:
        src = uncomment(tex.read_text(encoding="utf-8", errors="replace"))
        src = SETTING.sub(" ", LENGTH.sub(" ", src))
        nums = numbers(src)
        total += len(nums)
        found += sum(1 for n in nums if in_md[n])
        on_rows += sum(1 for n in nums if in_rows[n])
    return total, found, on_rows


def heading_scores(md, src):
    titles = re.findall(r"\\(?:sub)?section\*?\{([^{}]+)\}", src)
    heads = [letters(line) for line in md.splitlines() if line.startswith("#")]
    hit = [t for t in titles if letters(t) and any(letters(t) in h for h in heads)]
    return titles, hit


def body_paragraphs(src):
    """Plain-text paragraphs of the document body, with commands, math and floats removed"""
    m = re.search(r"\\begin\{document\}(.*?)(\\end\{document\}|$)", src, re.S)
    body = m.group(1) if m else src
    for env in DROP_ENVS:
        body = re.sub(r"\\begin\{" + env + r"\*?\}.*?\\end\{" + env + r"\*?\}", " ", body, flags=re.S)
    body = re.sub(r"\$\$.*?\$\$|\\\[.*?\\\]|\$[^$]*\$", " ", body, flags=re.S)
    body = re.sub(r"\\(?:cite\w*|ref|autoref|eqref|label|input|include|includegraphics|bibliography\w*|url|href)"
                  r"\*?(?:\[[^\]]*\])*\{[^}]*\}", " ", body)
    body = re.sub(r"\\[A-Za-z]+\*?(?:\[[^\]]*\])?", " ", body)
    body = re.sub(r"[{}~\\]", " ", body)
    return [p for p in re.split(r"\n\s*\n", body) if len(words(p)) >= 25]


def body_score(md, src):
    text = re.sub(r"<br>|<[^>]+>|!\[[^\]]*\]\([^)]*\)", " ", md)
    out = grams(words(text))
    shares = []
    for para in body_paragraphs(src):
        g = grams(words(para))
        if g:
            shares.append(sum(1 for x in g if x in out) / len(g))
    return shares


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("copy", help="the stored markdown copy")
    ap.add_argument("--main", required=True, help="the paper's main .tex file")
    ap.add_argument("--tables", nargs="*", help="table .tex files (default: found from the main file)")
    a = ap.parse_args()

    md = Path(a.copy).read_text(encoding="utf-8")
    main_tex = Path(a.main)
    src = uncomment(main_tex.read_text(encoding="utf-8", errors="replace"))
    tables = [Path(t) for t in a.tables] if a.tables else table_files(main_tex, src)

    total, found, on_rows = table_scores(md, tables)
    if total:
        print(f"TABLE NUMBERS {total} in {len(tables)} files: {100 * found / total:.1f}% in the copy, "
              f"{100 * on_rows / total:.1f}% on a markdown table row")
    else:
        print("TABLE NUMBERS none found (pass the table files with --tables)")
    titles, hit = heading_scores(md, src)
    print(f"HEADINGS {len(hit)} of {len(titles)} section and subsection titles found as markdown headings")
    for t in titles:
        if t not in hit:
            print(f"  not a heading: {t}")
    shares = body_score(md, src)
    if shares:
        print(f"BODY TEXT {100 * sum(shares) / len(shares):.1f}% of five-word sequences found, "
              f"averaged over {len(shares)} paragraphs")
    else:
        print("BODY TEXT no paragraph of 25 words or more found in the main file")
    return 0


if __name__ == "__main__":
    sys.exit(main())

#!/usr/bin/env python3
"""Optional Claude Code PreToolUse hook: send every read of a paper PDF through its stored markdown copy

Registered in ~/.claude/settings.json on the Read and Bash tools (references/read_hook.md has the
entry). It needs only the standard library and the skill's settings file. With no settings it does
nothing. The hook is narrow, since refusing a contract, a statement, a CV or a form does harm in
every chat: a PDF counts as a paper only when
  - it already has a stored copy, or the same file was converted for another folder, or
  - its first pages hold an abstract, keywords or JEL codes (LEAD) and an introduction (INTRO), and
    none of the words typical of a CV or a conference program (NOT_PAPER)
Every other PDF passes untouched, and so do these, even when they look like papers:
  - a PDF inside one of the settings' own-draft folders, and a PDF with a .tex of the same name
    beside it (a compiled draft or deck is read page by page to check its rendering)
  - an exhibit file: at most EXHIBIT_PAGES pages holding under EXHIBIT_CHARS characters of text
  - a slide deck (a landscape first page) and a fillable form (a PDF with form fields)

  paper with no copy yet, any read     refused, with the command that converts it (or copies the
                                       copy of the same file made for another folder)
  copy stored, whole PDF or full text  refused, pointing at the stored copy
  copy stored, chosen pages only       allowed, with a note naming the stored copy
  PDF the converter marked scanned     allowed, since its pages are read as images

Shell wildcards (*.pdf) are expanded against the command's folder, up to 50 files per pattern. A
Bash command that starts with PAPER_MD_SKIP=1 passes untouched, for file operations and sweeps over
many PDFs. Any error inside the hook lets the call through, so the hook never blocks other work.

Page counts and first-page text come from poppler's pdfinfo and pdftotext when they are installed,
and otherwise from PyMuPDF through the converter's interpreter saved in the settings. When neither
runs, an unconverted PDF passes.
"""

import glob
import json
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True  # keep the skill folder free of __pycache__ from every hook call
sys.path.insert(0, str(Path(__file__).resolve().parent))
import paper_md  # noqa: E402

EXHIBIT_PAGES = 2
EXHIBIT_CHARS = 3000
TEST_PAGES = 3          # pages whose text the paper test reads
LEAD = [r"\babstract\b", r"\bjel\b", r"\bkey\s?words\b"]
INTRO = r"\bintroduction\b"
NOT_PAPER = [r"\bcurriculum vitae\b", r"\bteaching experience\b", r"\bdiscussants?\b",
             r"\bsession\s+(?:[0-9]+|[ivx]+|[a-h])\b", r"\bchair\s*:", r"\bcoffee break\b",
             r"\bconference program", r"\bprogram(?:me)? committee\b"]
SCRIPT = Path(__file__).resolve().parent / "paper_md.py"
EXTRACTORS = re.compile(r"\b(pdftotext|pdftoppm|pdftocairo|pdfplumber|pymupdf4llm|pypdf|PyPDF2|get_text|extract_text|fitz|pymupdf|paper_to_markdown)\b")
PDF_TOKEN = re.compile(r"'([^']+\.pdf)'|\"([^\"]+\.pdf)\"|((?:[^\s'\"\\]|\\ )+\.pdf)\b", re.I)
PYMUPDF_PROBE = ("import sys, json, pymupdf\n"
                 "d = pymupdf.open(sys.argv[1])\n"
                 "n = min(d.page_count, int(sys.argv[2]))\n"
                 "r = d[0].rect if d.page_count else None\n"
                 "print(json.dumps({'pages': d.page_count, 'text': ''.join(d[i].get_text() for i in range(n)),\n"
                 "                  'landscape': bool(r and r.width > r.height), 'form': bool(d.is_form_pdf)}))\n")


def tool(name):
    """A poppler program on PATH or in the usual Homebrew folders, or None"""
    found = shutil.which(name)
    if found:
        return found
    for folder in ("/opt/homebrew/bin", "/usr/local/bin", "/usr/bin"):
        if Path(folder, name).is_file():
            return str(Path(folder, name))
    return None


def run(args):
    """A command's output, or None when it fails"""
    p = subprocess.run(args, capture_output=True, text=True, timeout=20)
    return p.stdout if p.returncode == 0 else None


def probe(pdf, s):
    """Page count, text of the first TEST_PAGES pages, landscape first page and form fields, or None"""
    info, totext = tool("pdfinfo"), tool("pdftotext")
    if info and totext:
        out = run([info, str(pdf)])
        m = re.search(r"^Pages:\s+(\d+)", out or "", re.M)
        if m:
            size = re.search(r"^Page size:\s+([\d.]+) x ([\d.]+)", out, re.M)
            form = re.search(r"^Form:\s+(\S+)", out, re.M)
            text = run([totext, "-l", str(TEST_PAGES), str(pdf), "-"]) or ""
            return {"pages": int(m.group(1)), "text": text,
                    "landscape": bool(size and float(size.group(1)) > float(size.group(2))),
                    "form": bool(form and form.group(1).lower() != "none")}
    py = s.get("python")
    if py and paper_md.expand(py).exists():
        out = run([str(paper_md.expand(py)), "-I", "-c", PYMUPDF_PROBE, str(pdf), str(TEST_PAGES)])
        try:
            return json.loads(out or "")
        except ValueError:
            return None
    return None


def looks_like_paper(pdf, s):
    """True when the first pages read like research writing; any doubt lets the PDF through"""
    info = probe(pdf, s)
    if info is None or info["form"] or info["landscape"]:
        return False
    text = info["text"].lower()
    if info["pages"] <= EXHIBIT_PAGES and len(text.strip()) < EXHIBIT_CHARS:
        return False
    if any(re.search(p, text) for p in NOT_PAPER):
        return False
    return any(re.search(p, text) for p in LEAD) and bool(re.search(INTRO, text))


def convert_cmd(pdf, s):
    py = str(paper_md.expand(s.get("python") or "python3"))
    return f"{shlex.quote(py)} -I {shlex.quote(str(SCRIPT))} {shlex.quote(str(pdf))}"


def decide(pdf, page_limited, s):
    """Return (decision, message) for one PDF, or (None, None) to let the call through"""
    if paper_md.in_draft_folder(pdf, s) or pdf.with_suffix(".tex").exists():
        return None, None
    md5 = paper_md.md5_of(pdf)
    state, md = paper_md.find_copy(pdf, md5, s)
    if state == "scanned":
        return None, None
    if state == "none" and not paper_md.copy_elsewhere(md5) and not looks_like_paper(pdf, s):
        return None, None
    if state != "fresh":
        why = "has changed since its markdown copy was made" if state == "stale" else "has no markdown copy yet"
        return "deny", (f"paper-to-markdown: {pdf.name} {why}. Run this once, then read the .md it prints:\n"
                        f"{convert_cmd(pdf, s)}\nIf the same file was converted for another folder, the "
                        "command copies that copy and converts nothing. If it prints SCANNED, the file is "
                        "image-only and needs OCR. For file operations, or a sweep over many PDFs, start the "
                        "Bash command with PAPER_MD_SKIP=1.")
    if page_limited:
        return "allow", (f"paper-to-markdown: the stored copy of {pdf.name} is {md}. Read chosen PDF pages only to "
                         "check a number, a table header or an equation against the copy.")
    return "deny", (f"paper-to-markdown: {pdf.name} is already stored as markdown: {md}. Read that file (its "
                    "header and `grep -n '^#'` give the outline), and open a PDF page with Read and `pages` "
                    "only to check a detail.")


def respond(decision, message):
    out = {"hookSpecificOutput": {"hookEventName": "PreToolUse"}}
    if decision == "deny":
        out["hookSpecificOutput"].update(permissionDecision="deny", permissionDecisionReason=message)
    else:
        out["hookSpecificOutput"]["additionalContext"] = message
    print(json.dumps(out))


def pdfs_in(cmd, cwd):
    for m in PDF_TOKEN.finditer(cmd):
        raw = (m.group(1) or m.group(2) or m.group(3)).replace("\\ ", " ")
        if "$" in raw:
            continue
        path = Path(raw).expanduser()
        path = path if path.is_absolute() else cwd / path
        if any(ch in raw for ch in "*?["):
            for hit in sorted(glob.glob(str(path)))[:50]:
                yield Path(hit)
        else:
            yield path


def main():
    s = paper_md.load_settings()
    if s is None:
        return
    data = json.load(sys.stdin)
    name, inp = data.get("tool_name"), data.get("tool_input") or {}
    cwd = Path(data.get("cwd") or Path.cwd())
    if name == "Read":
        f = inp.get("file_path") or ""
        if not f.lower().endswith(".pdf"):
            return
        pdf = Path(f).expanduser()
        pdf = pdf if pdf.is_absolute() else cwd / pdf
        if not pdf.is_file():
            return
        decision, msg = decide(pdf.resolve(), bool(inp.get("pages")), s)
        if decision:
            respond(decision, msg)
        return
    if name == "Bash":
        cmd = inp.get("command") or ""
        if cmd.lstrip().startswith("PAPER_MD_SKIP=1") or "paper_md.py" in cmd or not EXTRACTORS.search(cmd):
            return
        page_limited = bool(re.search(r"pdftotext[^|;&]*\s-f\s+\d+[^|;&]*\s-l\s+\d+", cmd))
        notes = []
        for pdf in pdfs_in(cmd, cwd):
            if not pdf.is_file():
                continue
            decision, msg = decide(pdf.resolve(), page_limited, s)
            if decision == "deny":
                respond("deny", msg)
                return
            if msg:
                notes.append(msg)
        if notes:
            respond("allow", "\n".join(dict.fromkeys(notes)))


if __name__ == "__main__":
    try:
        main()
    except Exception:
        pass
    sys.exit(0)

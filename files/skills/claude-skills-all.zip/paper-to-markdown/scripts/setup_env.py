#!/usr/bin/env python3
"""First-run setup for paper-to-markdown: the converter's Python environment and the settings file

Usage:
    python3 -I setup_env.py --show
    python3 -I setup_env.py --interpreter venv --store beside [--fallback-folder FOLDER]
                            [--no-write FOLDER ...] [--own-drafts FOLDER ...]
    python3 -I setup_env.py --interpreter /path/to/python --install --store /path/to/folder

--interpreter venv      create a virtual environment (default <PAPER_MD_HOME>/venv) from a Python
                        3.10 or newer found on this computer, and install the tested converter in it
--interpreter current   use the Python running this script
--interpreter PATH      use that Python (an existing conda or virtual environment)
--install               with current or PATH: install the converter into that environment when it
                        is missing (this can change package versions other projects use there)
--store beside          copies beside each PDF; PDFs in no-write folders go to --fallback-folder
                        (default ~/Documents/papers_md)
--store FOLDER          every copy in FOLDER, one subfolder per source folder
--no-write FOLDER       a folder never written into, added to Downloads and Desktop (repeatable)
--own-drafts FOLDER     a folder of the user's own compiled drafts or one that syncs to an online
                        editor: never written into, and the read hook leaves its PDFs alone
--venv-dir DIR          where the virtual environment goes
--base-python PATH      the Python the virtual environment is built from

Run again with only the options to change; the others keep their saved values. The settings file is
<PAPER_MD_HOME>/settings.json, where PAPER_MD_HOME defaults to ~/.claude/paper-to-markdown.
Prints SETTINGS and READY on success, SETUP or ERROR with the reason otherwise.
Exit codes: 0 ready, 2 error, 5 settings missing (with --show)
"""

import argparse
import datetime as dt
import json
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parent))
import paper_md  # noqa: E402

MIN_PYTHON = (3, 10)
VERSION_CHECK = ("import sys, pymupdf, pymupdf4llm, pymupdf.layout; "
                 "print(pymupdf4llm.__version__, pymupdf.__version__, sys.version.split()[0])")


def pins():
    return [f"{name}=={version}" for name, version in paper_md.PINNED.items()]


def run(args, timeout=1800):
    """Run a command and return (exit code, combined output)"""
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.SubprocessError) as e:
        return 1, str(e)
    return p.returncode, (p.stdout or "") + (p.stderr or "")


def python_version(py):
    code, out = run([str(py), "-I", "-c", "import sys; print('%d.%d' % sys.version_info[:2])"], timeout=60)
    m = re.search(r"(\d+)\.(\d+)", out) if code == 0 else None
    return (int(m.group(1)), int(m.group(2))) if m else None


def find_base_python(given):
    """A Python 3.10 or newer to build the virtual environment from, or None"""
    names = [given] if given else []
    if not given:
        names.append(sys.executable)
        for minor in range(14, 9, -1):
            names.append(f"python3.{minor}")
        names.append("python3")
        for folder in ("/opt/homebrew/bin", "/usr/local/bin"):
            for minor in range(14, 9, -1):
                names.append(f"{folder}/python3.{minor}")
    seen = set()
    for name in names:
        path = shutil.which(name) or (name if Path(name).is_file() else None)
        if not path or path in seen:
            continue
        seen.add(path)
        v = python_version(path)
        if v and v >= MIN_PYTHON:
            return path
    return None


def venv_python(venv):
    win = venv / "Scripts" / "python.exe"
    return win if win.exists() else venv / "bin" / "python3"


def check_converter(py):
    """(True, versions) when the interpreter imports the converter under -I, else (False, the error)

    The versions come from standard output only, so a warning the import prints on standard error
    does not replace them
    """
    try:
        p = subprocess.run([str(py), "-I", "-c", VERSION_CHECK], capture_output=True, text=True, timeout=300)
    except (OSError, subprocess.SubprocessError) as e:
        return False, str(e)
    if p.returncode == 0:
        lines = p.stdout.strip().splitlines()
        return True, lines[-1] if lines else ""
    err = (p.stderr or p.stdout or "").strip().splitlines()
    return False, err[-1] if err else f"exit {p.returncode}"


def install(py):
    print(f"INSTALLING {' '.join(pins())} into {py} (about 110 MB to download, about 270 MB on disk)", flush=True)
    code, out = run([str(py), "-m", "pip", "install", "--disable-pip-version-check"] + pins())
    if code != 0 and "externally-managed-environment" in out:
        print(f"SETUP {py} belongs to the system or a package manager, which refuses pip installs "
              "(externally-managed-environment). Run setup with --interpreter venv, which builds a separate "
              "environment. In a disposable sandbox such as a Claude app chat, installing anyway with\n"
              f"  \"{py}\" -m pip install --break-system-packages {' '.join(pins())}\n"
              "and then running setup with --interpreter current also works")
    elif code != 0:
        print("ERROR pip failed; its last lines:")
        print("\n".join(out.strip().splitlines()[-8:]))
    return code == 0


def setup_interpreter(a):
    """Return the converter's interpreter path as a string, or None after printing why"""
    if a.interpreter == "venv":
        venv = Path(a.venv_dir).expanduser() if a.venv_dir else paper_md.APP_HOME / "venv"
        py = venv_python(venv)
        if not py.exists():
            base = find_base_python(a.base_python)
            if not base:
                print("SETUP no Python 3.10 or newer found. Install one (python.org, Homebrew "
                      "`brew install python@3.12`, or your package manager), then run this again, "
                      "or pass --base-python PATH")
                return None
            print(f"CREATING virtual environment {venv} from {base}", flush=True)
            code, out = run([base, "-m", "venv", str(venv)], timeout=600)
            if code != 0:
                print(f"SETUP could not create the virtual environment ({out.strip()[-300:]}). Next step: "
                      "install the system's venv package (on Debian or Ubuntu, python3-venv) and run this "
                      "again, or use a Python you already have with --interpreter current --install (or "
                      "--interpreter PATH --install). In a disposable sandbox such as a Claude app chat, "
                      "where that Python refuses pip installs, run\n"
                      f"  \"{base}\" -m pip install --break-system-packages {' '.join(pins())}\n"
                      "and then setup with --interpreter current")
                return None
            py = venv_python(venv)
        ok, info = check_converter(py)
        if not ok and not install(py):
            return None
    else:
        py = Path(sys.executable if a.interpreter == "current" else a.interpreter).expanduser()
        if not py.exists():
            print(f"ERROR no interpreter at {py}")
            return None
        v = python_version(py)
        if not v or v < MIN_PYTHON:
            print(f"SETUP {py} is Python {'.'.join(map(str, v)) if v else 'unknown'}; the converter needs "
                  "3.10 or newer. Use --interpreter venv, which looks for one")
            return None
        ok, info = check_converter(py)
        if not ok:
            if not a.install:
                print(f"SETUP {py} lacks the converter. Install it into that environment with\n"
                      f"  \"{py}\" -m pip install {' '.join(pins())}\n"
                      "or run this again with --install, or use --interpreter venv to keep it separate")
                return None
            if not install(py):
                return None
    ok, info = check_converter(py)
    if not ok:
        print(f"ERROR {py} still cannot import the converter: {info}")
        return None
    print(f"CONVERTER {py}: pymupdf4llm, PyMuPDF and Python versions {info}")
    return str(py)


def folder_list(values):
    return [str(Path(v).expanduser().resolve()) for v in values]


def save(s):
    paper_md.APP_HOME.mkdir(parents=True, exist_ok=True)
    tmp = paper_md.SETTINGS.with_name("settings.json.tmp")
    with open(tmp, "w", encoding="utf-8", newline="\n") as f:
        json.dump(s, f, indent=2)
        f.write("\n")
    os.replace(tmp, paper_md.SETTINGS)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--show", action="store_true", help="print what the settings hold and stop")
    ap.add_argument("--interpreter", help="venv, current, or a path to a Python")
    ap.add_argument("--install", action="store_true", help="install into an existing interpreter")
    ap.add_argument("--store", help="beside, or a folder for every copy")
    ap.add_argument("--fallback-folder", help="with --store beside: where copies of PDFs in no-write folders go")
    ap.add_argument("--no-write", action="append", default=[], help="a folder never written into")
    ap.add_argument("--own-drafts", action="append", default=[], help="a folder of the user's own drafts")
    ap.add_argument("--venv-dir", help="where the virtual environment goes")
    ap.add_argument("--base-python", help="the Python the virtual environment is built from")
    a = ap.parse_args()

    saved = paper_md.load_settings()
    if a.show:
        if saved is None:
            print(f"SETUP no settings at {paper_md.SETTINGS}")
            return 5
        print(paper_md.settings_line(saved))
        return 0

    s = dict(saved or {})
    if not s and (not a.interpreter or not a.store):
        print("ERROR the first setup needs both --interpreter and --store")
        return 2

    if a.store:
        if a.store == "beside":
            s["storage"] = "beside"
            if a.fallback_folder or not s.get("store_folder"):
                s["store_folder"] = folder_list([a.fallback_folder or "~/Documents/papers_md"])[0]
        else:
            s["storage"] = "folder"
            s["store_folder"] = folder_list([a.store])[0]
    elif a.fallback_folder:
        s["store_folder"] = folder_list([a.fallback_folder])[0]
    s.setdefault("no_write_folders", folder_list(paper_md.DEFAULT_NO_WRITE))
    s.setdefault("own_draft_folders", [])
    for key, new in (("no_write_folders", a.no_write), ("own_draft_folders", a.own_drafts)):
        for folder in folder_list(new):
            if folder not in s[key]:
                s[key].append(folder)

    if a.interpreter:
        py = setup_interpreter(a)
        if not py:
            return 2
        s["python"] = py
    elif not s.get("python"):
        print("ERROR no converter interpreter saved yet; pass --interpreter")
        return 2

    s["saved"] = dt.date.today().isoformat()
    store = Path(s["store_folder"])
    store.mkdir(parents=True, exist_ok=True)
    save(s)
    print(paper_md.settings_line(s))
    print(f"READY settings saved to {paper_md.SETTINGS}")
    return 0


if __name__ == "__main__":
    sys.exit(main())

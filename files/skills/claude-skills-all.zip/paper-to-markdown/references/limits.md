# Known Defects of the Stored Copy

Found when testing the converter on economics papers with LaTeX source (two working papers, and two
published papers whose arXiv preprints come with their source files) and on one published journal
article. Each entry says what to do when it matters. The two public examples below come from the
food-security paper listed in `route_comparison.md`.

- **A header that spans several columns is cut across cells.** In a regression table with a country
  name set over each block of four columns, the names came out as `|Ethi|opia|` and
  `|Ma<br>Mild|lawi<br>Moderate|`, with the country row merged into the row of outcome names below
  it. Every body cell was correct. Read the header from the joined cells, and open the PDF page
  before quoting a header word for word.
- **A row label can take the row's first number.** In a summary table, the row
  `|Cash Transfers from Govt and NGOs<br>0.064|57|36|` holds the share engaged (0.064) inside the
  label cell, so every number after it sits one column to the left of its header. Compare a row's
  number of cells with the header's before taking a value from it.
- **A table continued on the next page comes out as two tables,** the second under the next page
  marker, with its header repeated or cut differently. Join the parts before taking a value from a
  column.
- **Display equations are images only.** The text around an equation keeps inline math as italic
  letters with the subscripts flattened (`_yit−_ 1` for y with the subscript i, t−1), and hats,
  bars and tildes are often lost. Open the equation image, or the `.tex` when it exists, before
  writing about the math.
- **Tables set as images in the PDF** (a scanned table, or a table pasted in as a picture) arrive as
  a figure image. Their numbers have to be read from the image, at the cost of OCR or image work.
- **A figure image holds whatever was drawn in the figure region,** including a title or notes
  drawn inside the graphic. The caption and notes typeset by the paper are text in the `.md` copy.
- **Rotated (landscape) tables and two-column journal layouts** were not in the test set. Check the
  order of the text on the first page of such a paper against the PDF before relying on it.
- **The equation and figure labels come from the image's proportions:** an image under about 250
  pixels tall and more than 2.5 times as wide as tall is called an equation. A short wide figure,
  such as a one-row legend strip, can be called an equation. The label only decides what the link
  says.
- **Hyphenated line breaks inside table cells** survive as `<br>` and a hyphen
  ("mathemat-<br>ics"). Rejoin the word when quoting.
- **Numbers.** On the longest test paper, 97.2% of the decimal numbers in the source tables were
  found in the copy, against 98.4% for pdftotext. The missing ones sit mostly in tables whose cells
  hold a number and a bracket or symbol together. A number quoted in the user's own work is checked
  against the PDF page.
- **The read hook** (the optional check Claude Code runs before each tool call) has limits of its
  own (the PDFs it lets through, wildcards, shell variables), listed in `read_hook.md`.

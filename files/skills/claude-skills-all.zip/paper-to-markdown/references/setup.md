# Converter Environment and Settings

## Requirements

- **Python 3.10 or newer for the converter:** pymupdf4llm 1.28.0 and its layout model,
  pymupdf-layout 1.28.0, which bring PyMuPDF 1.28.0, onnxruntime, numpy, networkx, PyYAML and
  tabulate. These are the versions the route was measured with (`route_comparison.md`).
- **Any Python 3.9 or newer to start the scripts.** They use only the standard library until a
  conversion is needed, so the `/usr/bin/python3` that macOS ships (3.9) can launch them while the
  converter lives in another environment.
- **Size:** about 110 MB to download and about 270 MB on disk (measured on macOS with Apple silicon
  and Python 3.11, where setup took under a minute).
- **Optional:** poppler's `pdfinfo` and `pdftotext`, which the read hook (the optional check
  Claude Code runs before each tool call, `read_hook.md`) uses when they are
  installed. Without them it counts pages with PyMuPDF through the converter's interpreter.

## Setup script

`scripts/setup_env.py` runs these steps:

1. It picks a Python 3.10 or newer: the one running it, then `python3.14` down to `python3.10` and
   `python3` on the PATH, then the same names in `/opt/homebrew/bin` and `/usr/local/bin`.
   `--base-python PATH` names one directly.
2. It creates the virtual environment (default `~/.claude/paper-to-markdown/venv`, or
   `--venv-dir DIR`). A virtual environment cannot be moved after it is built, so build it where it
   will stay.
3. It installs the pinned versions with pip and imports them under `-I` to check.
4. It writes `settings.json`, creates the store folder, and prints the `SETTINGS` line and `READY`.

With `--interpreter current` or `--interpreter PATH` it uses an existing environment. It installs
there only with `--install`, since an install can change the versions of packages other projects in
that environment use. Otherwise it prints the pip command to run.

`python3 setup_env.py --show` prints what the settings hold.

## Manual routes

A virtual environment by hand, then registered with the skill:

```bash
python3.12 -m venv ~/.claude/paper-to-markdown/venv
~/.claude/paper-to-markdown/venv/bin/python3 -m pip install "pymupdf4llm==1.28.0" "pymupdf-layout==1.28.0"
python3 -I "<skill folder>/scripts/setup_env.py" --interpreter ~/.claude/paper-to-markdown/venv/bin/python3 --store beside
```

A conda environment:

```bash
conda create -n paper-md python=3.12
conda run -n paper-md python -m pip install "pymupdf4llm==1.28.0" "pymupdf-layout==1.28.0"
python3 -I "<skill folder>/scripts/setup_env.py" --interpreter "$(conda run -n paper-md python -c 'import sys; print(sys.executable)')" --store beside
```

A computer without Python 3.10 or newer gets one from python.org, Homebrew
(`brew install python@3.12`), the system's package manager, or `uv python install 3.12`.

## The settings file

`~/.claude/paper-to-markdown/settings.json`, written by the setup script:

```json
{
  "storage": "beside",
  "store_folder": "/Users/<you>/Documents/papers_md",
  "no_write_folders": ["/Users/<you>/Downloads", "/Users/<you>/Desktop"],
  "own_draft_folders": [],
  "python": "/Users/<you>/.claude/paper-to-markdown/venv/bin/python3",
  "saved": "2027-01-15"
}
```

| Field | Meaning |
|---------------------|----------------------------------------------------------------------|
| `storage` | `beside` (copy beside each PDF) or `folder` (every copy in the store folder) |
| `store_folder` | where copies go under `folder`, and under `beside` for PDFs in a no-write folder |
| `no_write_folders` | folders the skill never writes into, whose PDFs are still converted, with the copy in the store folder |
| `own_draft_folders` | the same, and the read hook also lets Claude open their PDFs directly |
| `python` | the interpreter that holds the converter |
| `saved` | the date of the last setup run |

Temporary folders, the home folder itself and any folder the user cannot write to are always
treated as no-write folders. To change a
setting, run the setup script again with only that option (`--store ~/papers_md`), or edit the file
and keep it valid JSON. The environment variable `PAPER_MD_HOME` moves the whole settings folder
(settings, `index.tsv` and the default environment), which is useful for a test that must not change
the real settings.

## Repair after a missing-package error

1. **Check the environment is whole** before rebuilding it:
   `<python> -I -c "import pymupdf4llm, pymupdf.layout; print(pymupdf4llm.__version__)"`. An import
   that hangs or fails with a timeout error can mean that a cloud-sync service (iCloud Drive,
   OneDrive and similar) holds the environment's files online only. Make that folder available
   offline, or keep the environment outside synced folders. Reinstalling does not help.
2. **Rebuild a missing or broken environment** by deleting its folder and running the setup script
   again with `--interpreter venv`.
3. **Pin both packages together.** pymupdf4llm refuses to import unless its version matches
   PyMuPDF's exactly, so pin both or upgrade both together.
4. **Run the converter's Python with `-I`** when calling it directly (the hook's command does),
   which keeps the interpreter from loading modules out of the current folder or the PDF's folder.
   A package installed with `pip install --user` is invisible under `-I`, so install into the
   environment itself.

## Upgrading the converter

A new pymupdf4llm can change the output. The 2.x series needs Python 3.11 or newer and has not been
tested with these scripts. Before upgrading, convert one paper whose LaTeX source is available (an
arXiv preprint with its source files works) with the old and the new version, and compare three
measures: the share of the decimal numbers in the source tables that sit on a markdown table row,
the share of section titles found as markdown headings, and the share of each source paragraph's
five-word sequences found in the output. `scripts/score_against_latex.py` computes all three:

```bash
python3 -I "<skill folder>/scripts/score_against_latex.py" paper.md --main paper.tex
```

It finds the table files the main file pulls in with `\input`, or takes them with `--tables`. Its
LaTeX cleaning is simple, so compare the two versions with the same script and files. Keep the
upgrade only if none of the three falls. Existing copies stay valid after an upgrade, and `--force`
refreshes one when needed. The converter prints a `NOTE` whenever the installed pymupdf4llm differs
from the tested version.

## Removal

Delete `~/.claude/paper-to-markdown/` (settings, index and environment), remove the hook entry if it
was added (`read_hook.md`), and delete the skill folder. Stored copies stay where they are.

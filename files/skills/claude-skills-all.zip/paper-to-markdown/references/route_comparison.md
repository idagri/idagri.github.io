# Route Comparison

Why the skill converts with pymupdf4llm's layout model, which other routes were measured, and the
scores behind the choice.

## Routes measured

| Route | Result |
|------------------------------------------------|------------------------------------------------|
| pdftotext (poppler), plain text order | text only, no tables, no headings |
| pdftotext `-layout` | text laid out in columns, no tables |
| pdfimages (poppler) | raster images only, so every vector figure is missed |
| pymupdf4llm 1.28, layout model off | markdown, tables mostly lost |
| pymupdf4llm 1.28, layout model on (`pymupdf-layout`) | chosen |
| marker, Docling, Nougat, MinerU | not measured: each needs a model download of several GiB |

Tesseract and other OCR programs are needed only for scanned PDFs.

## Test and scores

Two economics working papers with LaTeX source, one book-length with a long appendix and one of
journal length, with display equations, about 85 regression and summary tables between them, and
vector and raster figures. The LaTeX source gives the correct text:

- **Body text:** share of each source paragraph's five-word sequences found in the output,
  averaged over paragraphs (after dropping the few paragraphs that no route recovers at half, which
  were edited after the PDF was compiled).
- **Table numbers:** share of the decimal numbers in the source tables found in the output, and
  the share found on a markdown table row.
- **Headings:** share of section and subsection titles found as markdown headings.

| Route | Body text | Table numbers | In table rows | Headings |
|------------------------------|--------------|--------------|--------------|----------|
| pdftotext plain | 98.2%, 98.0% | 98.4%, 98.7% | 0%, 0% | 0%, 0% |
| pdftotext `-layout` | 97.7%, 97.6% | 98.4%, 98.7% | 0%, 0% | 0%, 0% |
| pymupdf4llm, no layout model | 96.8%, 97.6% | 93.3%, 97.6% | 5.3%, 0.2% | 17%, 23% |
| pymupdf4llm, layout model | 98.1%, 98.0% | 97.2%, 97.6% | 91.2%, 96.2% | 100%, 96% |
| this skill's script | 98.2%, 98.0% | 97.2%, 97.6% | 91.2%, 96.2% | 100%, 96% |

Each cell gives the longer paper first, then the shorter one. The script took under a minute on
the longer paper, against a few seconds for pdftotext.

## Check on public papers

The same table and heading measures, run on two published papers whose arXiv preprints come with
LaTeX source under open licenses, converted by this skill's script in a fresh virtual environment
built by its setup script (pymupdf4llm 1.28.0, Python 3.11):

| Paper | Pages | Source table numbers | In the copy | On a table row | Headings |
|--------------------|-------|-------|-------|-------|----------|
| Hiring subsidies | 42 | 32 | 100% | 100% | 10 of 10 |
| Food insecurity | 56 | 420 | 100% | 98.1% | 22 of 22 |

The conversions took 3 and 7 seconds. The food-insecurity paper holds the regression tables
(coefficients, standard errors in parentheses, stars, observation counts). Every one of them came
out as a markdown table, and the only source numbers left off a table row were the thresholds of
the star key (0.001, 0.01 and 0.05), which sit in the notes text below each table.

- Hiring subsidies: Andrea Albanese, Bart Cockx and Muriel Dejemeppe, "Long-Term Effects of Hiring
  Subsidies for Low-Educated Unemployed Youths", Journal of Public Economics 235 (2024), 105137.
  Preprint arXiv:2406.08357v1, CC BY-NC-ND 4.0.
- Food insecurity: Ann M. Furbush, Anna Josephson, Talip Kilic and Jeffrey D. Michler, "Coping or
  Hoping? Livelihood Diversification and Food Insecurity in the COVID-19 Pandemic", Food Policy 131
  (2025), 102819. Preprint arXiv:2409.02285v1, CC BY 4.0.

## Deciding factors

- **Tables.** Only the layout model keeps a regression table as a table: coefficient, standard
  error and stars in their columns. pdftotext recovers the same numbers as a stream of tokens
  with the column structure gone.
- **Equations.** pdftotext and the no-layout route scatter a display equation over several lines
  (the sum sign, the subscripts and the equation number on separate lines). The layout model
  stores each display equation as an image, which is exact when opened.
- **Figures.** pdfimages finds raster images only, and most figures in an economics paper are
  vector graphics. The layout model renders every figure region to an image.
- **One defect, repaired in the script.** The layout route drops the letters of the fi, fl and
  ff ligatures in some table and caption fonts ("frst", "fagship", "efect", dozens of words in the
  longer paper). PyMuPDF's plain text of the same page keeps them, so the script builds the
  paper's own vocabulary from that text and restores a broken word only when exactly one
  restoration gives a word the paper uses. After repair, a 16-word check list found no broken
  word in either paper. The two public papers needed no repair.

The script also drops running headers and page numbers (`header=False, footer=False`) and adds
its own page markers. Body-text recovery did not fall when the headers were dropped.

# The Optional Read Hook

## Purpose

A skill's description lets a chat find the skill, and the chat may still open a PDF directly: in
testing, fresh chats asked to "read this paper" saw this skill listed and opened the PDF anyway,
paying for every page again. A hook is a command Claude Code runs before a tool call, set in
`~/.claude/settings.json`. This one runs `scripts/pdf_read_hook.py` before every Read and Bash call
and sends paper PDFs to their stored copy. The skill works without it when called by hand.

## Behavior

The hook is narrow. A hook that refused a contract, a bank statement, a CV or a form would get in
the way in every chat, so a doubtful PDF passes. A PDF counts as a paper in two cases:

- it already has a stored copy, or the same file was converted for another folder
- its first three pages hold an abstract, keywords or JEL codes and an introduction, and none of the
  words typical of a CV or a conference program: curriculum vitae, teaching experience, discussant,
  a numbered session, "chair:", coffee break, conference program, program committee

These pass untouched even when they look like papers:

- a PDF inside a folder listed under `own_draft_folders` in the skill's settings (saved with
  `--own-drafts`), and a PDF with a `.tex` of the same name beside it (a compiled draft or deck is
  checked page by page)
- an exhibit file: 2 pages or fewer holding under 3,000 characters of text (a figure or table PDF a
  script wrote), since a figure is checked by looking at it
- a slide deck (a landscape first page) and a fillable form (a PDF with form fields)

Every other PDF passes too: a contract, a statement, a CV or a conference program (even one that
quotes a paper's abstract), a report or a book with no abstract. A
paper the test misses is converted by running the script by hand, and from then on its stored copy
makes the hook act on it.

| Call | Hook |
|-------------------------------------------------|-------------------------------------------------|
| any request for a paper with no stored copy | refuses it and prints the conversion command |
| a whole-PDF read or full text extraction, copy stored | refuses it and names the stored copy |
| chosen pages (Read with `pages`, `pdftotext -f -l`), copy stored | lets it through with a note naming the copy |
| any other PDF, and a PDF the script marked scanned | does nothing |

For Bash, the hook acts only when the command calls a PDF text tool (`pdftotext`, `pdftoppm`,
`pdfplumber`, `pypdf`, PyMuPDF and similar) on a PDF it names. Shell wildcards (`*.pdf`) are expanded
against the command's folder, up to 50 files per pattern. A command that starts with
`PAPER_MD_SKIP=1` passes untouched, for file operations (merging, splitting, rendering pages for a
slide) and for sweeps over many PDFs.

## Turning it on

Add this entry to `~/.claude/settings.json`. When the file already has a `hooks` block, add the
inner object to its `PreToolUse` list and keep every entry already there:

```json
{
  "hooks": {
    "PreToolUse": [
      {
        "matcher": "Read|Bash",
        "hooks": [
          {
            "type": "command",
            "command": "python3 -I \"$HOME/.claude/skills/paper-to-markdown/scripts/pdf_read_hook.py\"",
            "timeout": 60
          }
        ]
      }
    ]
  }
}
```

- The path assumes the skill sits in `~/.claude/skills/paper-to-markdown/`. For a skill installed
  in a project's `.claude/skills/`, write that path.
- The command runs under the `python3` on the PATH, any version 3.9 or newer, and needs only the
  standard library. It reads the skill's settings, so setup has to have run first. With no settings
  file it does nothing.
- Claude Code reads hook settings when a chat starts. Open a new chat after adding the entry, and
  check the `/hooks` menu if a refusal does not appear.

## Turning it off

Delete that one entry (the object whose command names `pdf_read_hook.py`) from
`~/.claude/settings.json`. The skill keeps working when called by hand. To let a single command
through, start it with `PAPER_MD_SKIP=1`.

## Testing

Send the hook a sample call on standard input and look at what it prints:

```bash
echo '{"tool_name": "Read", "tool_input": {"file_path": "/path/to/paper.pdf"}, "cwd": "/path/to"}' \
  | python3 -I "<skill folder>/scripts/pdf_read_hook.py"
```

Empty output means the call passes. Otherwise it prints JSON: a refusal holds
`"permissionDecision": "deny"` and the reason, and a note holds `"additionalContext"`. Add
`"pages": "3-4"` to `tool_input` to see the note for chosen pages.

## Limits

- **A failure inside the hook never blocks a call.** An error, a missing settings file, a missing
  interpreter or a timeout lets the call through.
- **Page counts and first-page text** come from poppler's `pdfinfo` and `pdftotext` when
  installed, else from PyMuPDF through the converter's interpreter. When both are missing, every
  PDF without a stored copy passes.
- **The paper test** reads only the first three pages. A paper with no abstract, keywords or JEL
  codes there, or with no section called Introduction, passes until it is converted by hand, and so
  does a paper whose first pages thank a discussant. A document of another kind that opens with an
  abstract and an introduction (a grant proposal, a thesis) is refused until it is converted, or
  opened by a Bash command that starts with `PAPER_MD_SKIP=1`.
- **The exhibit threshold.** A short paper holds far more text than 3,000 characters in two pages
  (a 2-page paper tested held 3,629 characters, a figure PDF 159), so a short paper is still caught.
- **A PDF named only through a shell variable** (`pdftotext "$f"`) cannot be resolved before the
  command runs, so it passes.
- **Tested on macOS** with Claude Code's Read and Bash tools. Windows paths were not tested.

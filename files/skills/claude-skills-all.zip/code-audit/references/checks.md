# Code Audit Checks

The check procedures behind `SKILL.md`: how a finding is built, how severe it is, what may be
certified, and one procedure per dimension of a code-text audit. Each dimension states a
language-independent check first (a relation between a text claim and a code line that any auditor
can run on code nobody has seen), then the triggers that prompt it, the consequence tier, which side
to fix, what may be certified, and a published case. Language-specific command patterns are in
`stack_notes.md`. Worked findings are in `examples.md`.

The recurring published case is the replication package of Bessone, Rao, Schilbach, Schofield and
Toma, "The Economic Consequences of Increasing Sleep Among the Urban Poor," Quarterly Journal of
Economics 136(3), 2021 (Harvard Dataverse, doi:10.7910/DVN/GJ9QPC), read statically. The others are
documented published corrections, cited where they appear.

Consequence tiers used throughout:

- **Estimates**: a point estimate moves.
- **Inference**: standard errors, clustering or significance move while the point estimate does not.
- **Sample**: N or the composition of the sample changes.
- **Presentation**: labels, units, notes or reported figures only.

## Part 1: Construction of a finding

### The defining test

A deep finding could not have been written without this particular code and this particular draft.
Delete the quoted text location, the `script:line` and any number recomputed from the paper's own
output. If a sensible remark survives ("cluster at the right level", "check the merges for
duplicates"), the finding was shallow and reads as advice on any package. If what remains is
empty, the specifics were essential and the finding is deep. A pure code lint fails this test by
construction, because it never quoted a text claim. Every check below names the text claim it can
contradict. A check that touches no text claim is at most a code check or a disclosure note.

### Rules against overfitting

- The published cases in these files show what deep, grounded findings look like. They are not an
  answer key. Never search a new package for "the hand-typed figure" or "the state-year fixed effect
  that was state-only in the code" because a case has one. Run the package-independent check and
  report what it hits.
- Triggers and code signatures prompt a mechanical check. They never diagnose anything. Seeing
  `merge m:m`, a bare `reghdfe` or an `egen std` before a sample restriction means: run the check. A
  bare package default (fixest clustering on the first fixed effect, `winsor2` cutting at 1 and 99)
  is a finding only when a text claim contradicts it.
- A finished finding is unique to its package. The check that produces it works on any package.

### The finding contract

Every finding, in every dimension:

- **Title**: the failure and its location ("Missing interaction in Equation 1"), so the diagnosis is
  legible before the body.
- **Both ends**: the exact passage, quoted, with its location, and the code location as
  `script:line` or a line range. Quote enough of the passage to show the claim is not qualified
  elsewhere in the same sentence, footnote or note block.
- **Argument**: grounded in evidence. Causal connectives state the logic, every number is quoted
  from the paper or the output or derived in front of the reader, and any independent check is one
  the author can reproduce. Humility: the paper may be right and the audit wrong, so the argument
  rests on evidence the author can check.
- **Register follows severity**, decided first (below), then surfaced in the wording:
  - Blocking register: "internally inconsistent", "contradicts", "incorrect as written", and for the
    top tier "critical", "consequential", "necessary".
  - Middle register: "appears problematic", "seems stronger than the code supports", "requires
    clarification", "the current text overstates".
  - Minor register: "minor inconsistency", "slight mismatch", "would smooth the exposition",
    "consider revising".
  A typo and a fatal flaw must not arrive in the same register. Uniform alarm is the shallow form
  of severity.
- **Courtesy**: a code-versus-writeup uncertainty becomes a verification request, a benign
  explanation is offered when one is plausible, and bad intent is never imputed. Praise is rare and
  always specific.
- **The confirmation half**: concluding that a construction checks out, or that a slip cancels
  later and the conclusions are likely unaffected, is calibration. Certifying soundness is a
  finding with the same burden of evidence as a reported problem (Certification, below).
- **Fix**: minimal and proportionate, often a short menu ordered by cost and keyed to whichever
  explanation turns out true. Supply the corrected note, varlist or option yourself when cheap. The
  author owns the paper, and no request should hold it hostage.
- **Length tracks depth**: two sentences for a pure inconsistency, up to about 250 words for a
  finding with a mechanism chain. Most run 60 to 150 words.

### Severity

Severity is a decision, made before any wording. Three questions:

- Does the discrepancy break the paper's central claim as written (a specification the text names
  and the code does not run, a headline number that does not match the shipped output)?
- Can it be corrected within one revision, with the code and data as they stand (fix a table note
  or an equation, against re-collecting data or rebuilding a crosswalk)?
- Is the uncertainty about the code, or only about the writeup (does the code do the wrong thing,
  or does correct code have an imprecise description)?

Mapping: breaks the headline and cannot be corrected is [Blocking]. Breaks the headline and can be
corrected is [Major]. Local or writeup-only is [Minor] or a verification request. The code-text
twist on the third question: many findings have a bad branch that would be blocking and a benign
branch that is a one-word text fix (a control coded in levels, in which case the result may not
survive, or described loosely, in which case only the note is wrong). A static read usually cannot
decide the branch, so these default to [Major] and are framed as verification requests.

### Certification parity

The audit certifies a claim only when it was traced end to end: the text location, the code
location, and the numeric or mechanical agreement all confirmed. A claim tagged NOT YET TRACED or
NOT STATIC stays out of "What checks out". A false endorsement costs more than a miss, because it
reassures the author about the exact link the audit exists to test.

State the tier each certification earned. Reproduces from shipped output is a lower tier than
reproduces from raw data. Where a shipped file replaces a computation, say so: "the adjusted
p-values in the table are the ones in the shipped csv" certifies the source of the values, and it
does not certify that the default run computed them.

A static read may certify only facts visible in the code: a literal an auditor can see (a cluster
argument, an `absorb()` term, a declared cardinality, the range written into a `collapse`). Four
classes are out of static reach and go to a verification request, or to a targeted rerun where the
mode allows one:

1. Coverage: that a range or a collapse spans every intended row (a range that stops short neither
   errors nor looks wrong on a read-through).
2. Row counts after a join or merge: that it neither fanned out nor dropped rows.
3. "Nothing else silently drops": an unbounded negative a static read cannot support.
4. A claim about "all X" inferred from a subset. Certify an "all" claim only after every instance
   in scope has been read, and otherwise narrow it to the instances traced ("clustering is at the
   participant level in Tables II to IV as traced").

### The eight moves

Moves 1 to 7 build one located finding, usually in this order. Move 8 builds a package-level
judgment.

1. **Cite both ends.** Open from a verbatim excerpt at the finest grain the paper offers (section,
   equation, table and column, note, footnote) and cite the code at `script:line`. Locations come in
   pairs, because the finding is the relation between them.
2. **Recompute the disputed value from the shipped output.** Recompute a t from a displayed
   coefficient and standard error, rebuild an in-text contrast from table cells, compare a draft
   cell with the exact `.tex` or `.csv` the script writes. A two-decimal 0.08 implies an unrounded
   value below 0.085, which cannot round to 0.09: arithmetic like that turns a hunch into a finding.
3. **State the command's mechanism in explicit steps.** Two to four steps from the exact command and
   its documented behavior to the point of failure. `reghdfe` with no `vce()` reports unadjusted
   conventional standard errors, so a "clustered at the participant level" claim over a bare call
   describes inference that never ran. State the semantics, then the conclusion.
4. **Reconcile across the document and the package.** Besides the text against the code: a table
   note against the estimating command, the README's exhibit table against the files in both
   directions, and a writer script against its reader. Cite every end, so a one-spot fix cannot
   leave the discrepancy standing elsewhere.
5. **Verify against the artifact the package ships.** Open the generating script and read what
   produced the cell, trace an exhibit's input to its source, search the package for the check a
   uniqueness claim would need. "This looks wrong" is a hunch. Locate the faulty line or produce the
   mismatched cell, and drop the item if neither is possible.
6. **Bound the damage, and voice uncertainty as a verification request.** State what survives,
   grade the certainty, tie severity to the central claim. A stale comment is not evidence of bad
   faith. When the disputed object cannot be resolved statically (a variable built earlier than the
   shipped data, data not shipped), say so and ask.
7. **Name which side to fix.** Text when the code is right and the prose misdescribes it. Code when
   the text states the intended analysis and the code departs from it. Often a menu keyed to the
   branch the author confirms. Proportionate: no request to rerun the whole pipeline for a note.
8. **Synthesize located traces into a package-level judgment.** Several traces assembled into one
   structural statement under the package's regime: for example, a well-mapped package whose two
   gaps in number origins both trace to hand-maintained intermediate files outside the pipeline.

### The map

Build four tables before tracing any claim (steps in `SKILL.md`, Step 2): the script inventory, the
run order, the exhibit index, and the claims table. Three details matter in practice.

- **Run order.** Read the master script for run order, data dependencies (every generated dataset,
  its writer before its readers), conditional calls (scripts that run only when a global is set,
  called from inside other scripts), and path conventions. Where no master exists, reconstruct the
  order before tracing.
- **Exhibit index.** Start from the exhibits the draft renders, since that list is small even when
  the package is not. Exhibit file names are often assembled from macros and loop variables, so an
  exact-name search maps only part of them. Search the full stem, then the stem without generated
  suffixes, then shorter prefixes, and prefer the most recent producer that writes the file. An
  exhibit with no producer after every search is a lead for dimension 1, often a hand-maintained
  table.
- **Claims table.** Key every claim to its dimension and tag it TRACED, NOT YET TRACED or NOT STATIC
  (with the reason).

### Deposit regimes

The regime that produced a package sets how much a package-level finding weighs. Say in the report
which standard the package was held to.

- **Verified before acceptance** (American Economic Association journals, Review of Economic
  Studies, Econometric Society journals for packages accepted after mid-2023): a data editor ran the
  code and reproduced the manuscript's exhibits before publication. A "does not run" or "does not
  reproduce" finding is rare there, and stronger when real. Construction and cleaning code is
  mandatory under AEA policy even when the raw data are withheld, so missing construction code is a
  policy gap. A passing check proves the code reproduces its own tables. It does not prove the code
  matches the prose, and it cannot reveal a sort that changes from one run to the next.
- **Documented deposit** (for example the Quarterly Journal of Economics): documentation and
  final-model reproduction are promised, with no third-party run. Package-integrity gaps are more
  likely and less damning there.
- **No deposit yet** (Mode 1, a live project): package-integrity items are not findings. Note them
  once, in the package map, as what a deposit will need. The dominant risk is staleness: whether
  the number the draft shows is the number the current code produces, whether an older producer
  would overwrite a shipped exhibit at an older sample, and whether the prose still describes the
  construction the code now runs.
- **The user's own package before deposit** (Mode 2a): hold it to the target journal's regime, and
  treat every integrity gap as a finding to fix before submission.

The absence of a uniqueness check before a merge is a weak signal everywhere (it is the norm in
published packages) and sharpens only when a text claim about uniqueness or match rates rests on it.

## Part 2: The dimensions

## 1. Origin of each number

Every number a reader can see, in prose, a table cell or a plotted point, is a claim that some line
of code computed it and wrote it to the output the exhibit is built from. Walk the chain backward
from the printed number to the output file to the `script:line` that writes it, then confirm the
shipped output holds the number the draft prints.

1. Build the exhibit index (from the README's exhibit table if one exists) and verify it in both
   directions.
2. For each exhibit, find the line that writes the output (`esttab`, `outreg2`, `estout`, `ggsave`,
   `to_csv`, `write.csv`) and the line that supplies each number to it.
3. Compare the shipped output cell with the draft cell, number for number. Where the output does
   not ship, certify the chain and leave the value uncertified.
4. For a number in prose, trace it to the same outputs, or recompute it in front of the reader from
   other reported numbers.

This dimension owns whether a number traces to code and whether the output matches the cell.
Whether the specification behind it matches the text is dimension 2, its inference is dimension 5,
and its sample is dimension 3. File a finding once, under the dimension whose check settles it.

### 1.1 Broken chain: hand-typed exhibits and orphan files

- **Check.** An exhibit whose numbers never came from the estimation: typed as literals into the
  plotting or table script, or read from an intermediate file that no script in the package writes.
  The text claim is the exhibit's own promise ("plots the treatment effects", "based on the
  estimates in Table IV"). Find the line that produces each plotted or tabulated value. A literal
  vector, or a read of a file with no writer, means the exhibit can drift from the estimates it
  claims to display.
- **Triggers.** An inline data literal (`tibble()`, `data.frame()`, `c(...)`, a pandas
  `DataFrame({...})` of hardcoded rows, a Stata `input` block) in a results exhibit. A read of a
  file that no script writes, according to a package-wide search. The README classing that file as a
  base dataset. A disclaiming comment ("made up", "TEMP", "hardcoded from table"). A figure the text
  calls stylized or illustrative may be drawn by hand.
- **Tier.** Presentation when the typed value matches the estimate. Estimates or inference when it
  does not.
- **Which side.** Almost always code: read the value from the saved estimation output and delete the
  literal. Phrase it as a verification request and offer the benign explanation (a late
  transcription that a stale comment outlived).
- **Certify only** when a real script reads a real estimation output that a real script writes, and
  the value matches the draft cell. A literal or an orphan input means the exhibit is reported as
  not traced.
- **Published case.** In the Bessone et al. package, Online Appendix Figure A.IX is built from a
  hand-typed tibble at `Figure_A9.R:30-34`, and one of its five y-values is 0.09 where Table III and
  the text report 0.08. Main-text Figure VI reads `summary_coefficients.csv`, which the README lists
  as a base dataset and no script writes, although the figure note says the coefficients come from
  Table IV (`examples.md`, examples 1 and 2).

### 1.2 Intact chain, wrong number: aggregation range and formula

- **Check.** A number can have a real producing line and still not be the number the text names,
  because the aggregation covers the wrong rows or the formula differs from the one described. Read
  the range, weight and grouping of every `mean`, `sum`, `collapse`, `egen` or spreadsheet `AVERAGE`
  that feeds a reported statistic, and the construction of any weight or transformation the text
  names.
- **Triggers.** A hardcoded cell range or row bound (`AVERAGE(B2:B15)` where the series runs to
  B20, a Stata `in 1/40`, a pandas `.iloc[:N]`). A weight whose inversion can flip (`[aweight=sd]`
  where the text says inverse variance). A literal pasted for a cell the text attributes to a named
  source and year.
- **Tier.** Estimates, often inference.
- **Which side.** Code when the range or formula contradicts a correctly stated method. Text when
  the coded method is defensible and the prose misdescribes it. Ask which the authors intend.
- **Certify only** the code-visible facts: the weight is the inverse the text names, the grouping
  matches, the literal range is the one written. Whether the range spans every intended row needs
  the data, so mark it not verifiable statically.
- **Published cases.** Reinhart and Rogoff (2010): a spreadsheet `AVERAGE` stopped short of five
  high-debt countries, and the growth average for debt above 90% moved from about -0.1% to about
  +2.2% once the range was complete. Levitt (1997), via McCrary (2002): the text weights by inverse
  variance, and the code weighted by the residual standard deviation itself, giving the noisiest
  series the most weight. Piketty (2014): chart cells that did not match their cited source or year.

### 1.3 Recomputing from reported values

- **Check.** Some numbers must satisfy an arithmetic relation with other printed numbers, so they
  can be checked with no code at all: a p-value from a coefficient and standard error, a combined
  effect from its parts, a share from its components, the same estimate printed at two precisions.
  This is the fallback when the code path is opaque or the output did not ship.
- **Tier.** Inference for recomputed significance, estimates or presentation for arithmetic
  mismatches.
- **Which side.** Text when the recomputation shows the printed significance or magnitude is wrong.
  A verification request when rounding or transcription could explain it. Show the arithmetic.
- **Certify** an identity the audit recomputed and found to hold, and say so. It certifies that one
  identity and nothing about the estimate's own origin.
- **Published cases.** Miguel and Kremer (2004): a "proportion anemic" result reported significant
  at 95% recomputes to p of about 0.19 from the printed coefficient and standard error. In the
  Bessone et al. package, the text's "25 minutes versus 25 minutes" contrast recomputes exactly
  (0.33h plus 0.09h equals 0.42h, or 25.2 minutes), which is a certifiable identity.

## 2. Specification against the estimating command

The estimating command is the specification. The prose, the display equation and the table notes are
three claims about it. Rebuild the specification from the call itself (its absorbed or dummy fixed
effects, its varlist, its `vce`, its weights, its estimator and the `if` it runs on), then make
every description agree with it. This class of error survives pre-publication verification, because
a passing check proves the code reproduces its tables and says nothing about whether the code
matches the prose.

Boundary: whether the cell matches the output is dimension 1, how the sample was built is dimension
3, whether a control was constructed correctly is dimension 4, and clustering and standard-error
conventions are dimension 5.

### 2.1 Fixed effects

- **Check.** List every fixed effect the prose and the equation name, and every one the design
  requires, then confirm a literal one-to-one counterpart in the command's `absorb()`, `i.` terms or
  `| fe |` part. Two directions fail. A named effect with no counterpart (an interaction the text
  calls state-year that the code has only as two main effects) leaves the confound unabsorbed. A
  command term the text does not name, at or above the level the treatment varies, absorbs the
  variation the design needs. Switching between non-equivalent commands across tables while
  describing one structure is itself a claim to check (`reghdfe`, `areg` and `xtreg, fe` differ in
  degrees of freedom and singleton handling).
- **Triggers.** "X-by-Y fixed effects", "within-unit", a subscripted dummy in the equation, a design
  name (two-way fixed effects, event study) that requires a specific absorbed set. In the code: an
  absorb list with fewer, more or differently interacted terms than the equation.
- **Tier.** Estimates. Presentation when only a display equation is stale and the command is right.
- **Which side.** Code when the command lacks an effect the identification argument needs, phrased
  as verification ("the regression as coded absorbs only state. Either restore the state-by-year
  interaction the text and Equation (n) describe, or correct the description and revisit what
  identifies the effect"). Text when only the equation or note misstates a correct command.
- **Certify only** after matching each named effect to a term in the exact command behind the
  exhibit and confirming no extra absorbing term above the treatment level. A certified fixed-effect
  structure certifies neither the controls nor the sample it runs with.
- **Consequence before severity.** When the omitted effect is orthogonal to the regressor (a
  time-invariant regressor in a balanced panel, for example), compute what moves before tagging
  severity: the point estimate and even the clustered standard errors may not change while the
  R-squared does.
- **Published cases.** Donohue and Levitt (2001), via Foote and Goetz (2008): the prose describes
  state-year effects, and the regressions included only state effects. In the Bessone et al.
  package, Table II names day-in-study and date fixed effects, age quartiles, gender, a baseline
  control, participant clustering and the post-treatment sample, and `Table_2.do:50-54` has every
  one, so the fixed-effect structure certifies.

### 2.2 Controls and functional form

- **Check.** Treat the controls named in the prose and every note as a set, and the form each is
  named in (quartile dummies, logs, changes, an interaction) as part of the claim, then read the
  varlist. Three directions fail: fewer controls than claimed (a stale or out-of-scope macro expands
  to nothing, so `regress y $controls` runs with no controls), more than the note discloses, or a
  different form (single-year dummies where the text says quartiles, levels where it says changes).
  A control the text says a column includes that the column cannot include (a baseline term for an
  outcome with no baseline period) is the degenerate case.
- **Triggers.** "All specifications control for", "we additionally control for", a note listing
  controls, "in changes", "in logs", "quartiles of". In the code: a macro varlist whose latest
  in-scope definition must be traced, `i.age` where the text says quartiles, a level where the text
  says a change.
- **Tier.** Estimates when a control is missing or wrongly transformed. Presentation when only the
  note is wrong.
- **Which side.** Under-disclosure is a text fix. A wrong form is a code fix if the text's form is
  intended. When a macro cannot be resolved statically, ask what it expands to where the table runs.
- **Certify** "controls as stated" only after every macro is expanded to its in-scope definition at
  the call and matched name by name and form by form.
- **Published cases.** Boissel and Matray (2022, retracted 2023): a firm-size control specified in
  changes in the manuscript was coded in levels in the code behind the event-study figure, and a
  pre-trend appeared once it was specified as described. In the Bessone et al. package, a Table III
  note names one added control for the savings rows, and the command has six more (`examples.md`,
  example 4).

### 2.3 Estimator, weights and the sample restriction in the call

- **Check.** Three elements the command declares and the text names. The estimator ("PPML", "2SLS
  with X instrumented by Z") against the command and its endogenous and instrument lists. The weight
  type against the stated motive: sampling weights call for `pweight`, analytic weights for
  `aweight`, and the two give identical point estimates and different standard errors. The `if` in
  the call, and any saved estimation-sample indicator, against the sample the text says the
  regression uses.
- **Triggers.** "We estimate by PPML", "IV with ... as instruments", "weighted by population",
  "sampling weights", "on the post period". In the code: `poisson` or `glm` under a PPML claim with
  many fixed effects (where `ppmlhdfe` detects separation), `[aweight=]` under a representativeness
  claim, an `if` that differs from the described sample.
- **Tier.** Estimates for the estimator and the `if`, inference for the weight type.
- **Which side.** Code when the wrong command, weight or `if` ran and the text names the intended
  one. Text when the prose names a cleaner estimator or a different sample than the code defensibly
  runs.
- **Certify** an estimator, a weighting or a restriction only after a close look at the command that
  runs it. Never certify "PPML" or "IV" from the method's name.
- **Published case.** In the Bessone et al. package, the IV in `Table_A17.do:53` instruments exactly
  the two endogenous sleep variables the text names with a factorial of the treatment cells, so the
  instrument structure certifies.

## 3. Sample construction

The text makes its most falsifiable promises about the sample, and code breaks them most easily
without an error. Rebuild the sample the code builds (the ordered keep, drop and merge steps, plus
the listwise deletion each estimation command performs on the variables in its call), then make it
agree with every N in a note or flow sentence, every drop rule, and every "same sample across
columns" claim.

- **Stated N against the filter chain.** Rebuild the surviving rows from the code and compare with
  each count the paper commits to. With the data on hand and a rerun allowed, reproduce the N.
  Otherwise reconcile the rules and report the count itself as not verifiable.
- **Both directions of disclosure.** A drop in the code the text never mentions is an undocumented
  sample change, and a hardcoded patch on one unit is a code-only data correction. A restriction the
  text states with no code line is an unsupported claim. A sample rule belongs once in the text and
  once in the code, as the same rule.
- **Missing values against the stated policy.** The paper's policy ("we drop observations missing
  X", "missing coded as zero", "complete cases") is a claim, and the tool's default often does
  something else without a warning: Stata's missing values counted as larger than any threshold, an
  estimation command dropping rows for each added covariate, a groupby dropping missing-key groups,
  unmatched merge rows leaving through a later missing-value drop so attrition is blamed on "missing
  data". Find where missingness enters, name what the default does, and confirm the text names that
  behavior.
- **Column drift against "adds a control".** A table presented as "column (k) adds X" claims the
  sample is otherwise fixed, so a moving coefficient reads as the control's contribution. If the
  code does not fix one sample and reuse it, a control with extra missingness moves the sample, and
  the coefficient movement is partly composition.

Triggers: a count in a note, "we drop / exclude / restrict to", "the sample is identical across
columns", "balanced panel", a stated attrition rate. In the code: a filter whose count cannot match
the note, a hardcoded `replace` keyed on one unit id, a table's columns with no shared sample
indicator, an inequality used for selection with no missing guard, a merge whose unmatched rows
leave through a later deletion with no count.

- **Tier.** Sample, escalating to estimates when the drop is correlated with treatment or outcome or
  when a cross-column contrast is read causally. Presentation when only a note's N is imprecise.
- **Which side.** Usually text, when the code's sample is defensible and the writeup under-describes
  it. Code when the sample built is not the one the paper argues for. Phrase it as a verification
  request when the N cannot be reproduced.
- **Certify** the presence of a mechanism: an equal-N claim when one estimation-sample indicator is
  fixed and reused, a stated drop rule when its exact condition is in the code. A present rule does
  not certify that the sample equals the text's, and "nothing else silently drops" is never
  certified.
- **Published cases** (Bessone et al. package). The baseline control is described over the first
  eight days, and `Table_4.do:28-29` drops day 1 before the baseline means are built (`examples.md`,
  example 5). `Table_2.do:8-11` patches two participants by hand, disclosed only in code comments
  (example 6). The positive case: `Table_2.do:103-104` saves `gen in_sleep = e(sample)` from column
  1 and restricts columns 2 and 3 to it, which certifies the equal N across those columns.

## 4. Variable definitions and their reference sample

A constructed variable is defined by two elements: the transformation and the sample it is computed
on. A z-score over the full sample and one over the estimation or control sample share a name and a
definition sentence, and they are different variables with different coefficients. The construction
sentence rarely states the reference sample, and the code almost always fixes it silently.

- **Formula.** For each variable the text defines by a transformation (log, winsorization at stated
  cuts, a deflator with a base year, a unit multiplier, a median or quartile split, a
  standardization, a recoded category), read the construction line against the sentence. Do the
  winsor cuts equal the stated percentiles. Does a rate "multiplied by 100" have the factor. Is the
  omitted category the one the text names. Does a treatment "coded 1/0" use the codes the data hold.
  Does a stated missing-value code survive the reader's default coding.
- **Reference sample (the priority).** For every mean, standard deviation, median, percentile or
  covariance that enters a construction, identify the rows it is computed over, in execution order,
  and compare them with the sample the definition implies. Does the `summarize`, `egen` or quantile
  run before or after the restrictions that define the analysis sample. Does any by-group match the
  stated grouping (control group, year, stratum). An index built with a skip-missing reduction uses
  a different set of components on each row, which is neither "complete cases" nor "missing as
  zero". Trace forward too: which shipped variant of a variable an exhibit script selects
  (`keep if type == ...`) is part of its definition.
- **Triggers.** "Standardized to mean zero and unit variance", "normalized by the control group's
  mean and standard deviation", "winsorized at the 1st and 99th percentiles", "above the median",
  "the omitted category is", "deflated to 2015 dollars". In the code: a location statistic with no
  sample qualifier, or one whose qualifier differs from the stated one, computed before the
  restriction the text implies.
- **Tier.** Estimates, chiefly. Sample when the transformation decides inclusion (a median split, a
  recode that adds or drops rows). Presentation when the construction is defensible and only its
  description is wrong.
- **Which side.** Code when the text's sample is the right one and the statistic was computed on the
  wrong set (move the `summarize` after the restriction). Text when the code's construction is
  deliberate and the sentence compressed it. Name both branches and both fixes in the request.
- **Certify** a definition only after both parts trace to construction code that ships: the
  transformation and the exact reference sample. Leave out constructions that do not ship (a ratio
  that arrives pre-built in the cleaned data) and choices the text never describes, which are
  neither reported nor certified.
- **Published cases** (Bessone et al. package). Passing: the notes say outcomes are normalized by
  the control group's mean and standard deviation, and `Table_4.do:35-38` runs
  `sum <var> if treat_pool == 0 & treat_nap == 0 & post_treatment == 1` before
  `gen <var>_post_std = (<var> - r(mean)) / r(sd)`. Discrepancy: the index weights are built from
  residuals standardized on the full post-treatment sample, all arms pooled, where the sentence
  implies the control group (`anderson_index_program.do:67-68`, `examples.md`, example 3).

## 4b. Merges and duplication

Weight this dimension above the others. More documented corrections trace to merges, crosswalks
and duplication than to any other code operation: a many-to-many merge on an unenforced sort order
(Moretti 2021, via Wiebe), a hand crosswalk that assigns one country another's value (Acemoglu,
Johnson and Robinson 2001, via Albouy 2012), and duplicated observations that a mass reproduction
study found among the genuine coding errors in about a quarter of papers that already reproduce
(Brodeur, Mikola and Cook, "Mass Reproducibility and Replicability: A New Hope," IZA Discussion
Paper 16912, 2024).

Treat every merge as a claim about the relation between two datasets. The text describes the link
(its level, cardinality, match rate and what happens to non-matches), and the code implements it.
The absence of an `isid`, `duplicates`, `validate` or `relationship` guard is the norm in published
packages, so it prompts the check. The finding fires only when a
missing or weak uniqueness guarantee meets a text claim about uniqueness, match rate or link level.

### 4b.1 Keys and declared cardinality

- **Check.** For each merge: the key columns, the text's claim about the link level ("at the
  firm-year level", "one-to-one"), and whether the key is unique on the side the design treats as
  unique, with a declared cardinality that matches. The sharp case is a genuine many-to-many (Stata
  `merge m:m`, a pandas merge with no `validate=`, a dplyr join with no `relationship=`), where the
  pairing depends on the current sort order and may differ from run to run.
- **Tier.** Estimates and sample.
- **Which side.** Usually code (add the guard, replace `m:m` with a keyed join or `joinby`). Text
  when the code is right and the prose mislabels the level.
- **Certify** only that the declared cardinality is enforced (a 1:1 or m:1 that stops with r(459) on
  a non-unique key, or a `validate=` or `relationship=` guard) and that the declared level matches
  the text. Whether the key means the same thing on both sides needs the data.
- **Note.** In Stata, 1:1 and m:1 test only the "1" side. The "many" side and `m:m` are tested by
  nothing.

### 4b.2 Unmatched rows and match rate

- **Check.** What the code does with rows that fail to match, against the text's account (a match
  rate, "we keep all baseline respondents", or silence beside a table that implies the full sample).
  The silent path is a merge followed by `keep if _merge == 3`, a default inner join, or `drop
  _merge` with no tabulation or assertion in between, after which unmatched rows leave through a
  later listwise deletion.
- **Tier.** Sample, and estimates when non-match is related to treatment or the outcome.
- **Which side.** Text when the code is right but silent (report the match rate and what happened to
  unmatched rows). Code and text when the handling itself is wrong.
- **Certify** the handling of unmatched rows only when the code makes it explicit and it matches the
  text (`assert _merge == 3`, or `keep(match)` with a reported rate). Silence in both is a request.
- **Published case.** In the Bessone et al. package, `Table_A5.do:21-22` runs
  `merge m:1 pid post_treatment using ...` followed directly by `drop _merge`, with no tabulation,
  so unmatched rows survive with missing index values and leave in the next regression. Whether any
  row fails to match needs the data, so the finding is a request for the match rate.

### 4b.3 Silent duplication and fan-out

- **Check.** Every step that can multiply rows (a merge on a key that is not unique on the side
  assumed unique, a merge onto a collapsed aggregate where the fine side has unintended duplicates,
  a crosswalk that maps one unit to several), against the stated unit of observation and N. A
  `collapse` makes its output unique at its `by()` level, so the declared "1" side passes its check
  by construction and the merge never errors. All the risk sits on the fine side, and the visible
  cleanup of the aggregate side makes it look safe.
- **Tier.** Estimates (duplicated rows reweight the regression) and sample (inflated N).
- **Which side.** Code when unintended (a uniqueness guard at the fine side's unit before the merge,
  or a documented deduplication rule). Text when intended and misdescribed.
- **Certify** "no silent duplication at this step" only from a guard visible in the code at the
  claimed unit, or a cardinality that forbids it. A reproduced exhibit is no evidence of uniqueness.
- **Invented example.** The text says "we merge county-level policy onto the firm-year panel" and
  reports N firm-years. The code runs `collapse (mean) policy, by(countyid)` then
  `merge m:1 countyid using policy` with no `isid firmid year` first. If an earlier reshape left
  duplicate firm-years, the policy is copied onto each duplicate and the estimation N exceeds the
  stated count.

### 4b.4 Recombination rules when units are merged into a parent

- **Check.** When a build merges smaller units into a parent (a boundary harmonization, a
  reclassification, an entity resolution), each analysis variable is re-aggregated by some rule, and
  that rule need not match the paper's definition. Read the rule per variable. A variable rebuilt as
  a weighted mean on the recombined rows and computed as a plain mean everywhere else is two
  different objects in one estimation sample.
- **Triggers.** One weighted-recombination list applied to many variables (`local W var1 var2 ...`
  followed by a weighted ratio by group, a pandas `groupby().apply()` with a weighted-average lambda
  over a column list, an R `summarise(across(all_of(vars), ~weighted.mean(.x, w)))`), especially
  when the list mixes measures whose correct aggregation differs. The sharpest sign is a minimum or
  a count inside a weighted-mean list.
- **Tier.** Sample when the variable gates the estimation sample, estimates when it is the treatment
  or an outcome. Count the affected rows before calling it negligible.
- **Which side.** Usually text (state the rule in the definition). Code when the variable should
  never have been on the list.
- **Certify** a merge chain's mechanics separately from the meaning of the variables that survive
  it: "cardinality and unmatched handling verified, recombination rules not traced".
- **Invented example.** A firm build merges subsidiaries into their parent companies and applies
  one sales-weighted list to every variable. The list includes "distance to the nearest supplier",
  which the paper defines as a minimum over the parent's plants and uses as a sample gate. For the
  merged parents the gate becomes a weighted mean of distances, which is never below their minimum,
  so the gate admits or drops some of them differently from the minimum the paper defines. Every
  merge in the build declares a self-enforcing cardinality, so an audit limited to cardinality finds
  nothing.

## 4c. Crosswalks, panels and spatial links

This dimension owns links across geography or time: crosswalks, spatial joins, changing boundaries,
and the panel operators (differences, lags, within-unit changes) that presume a stable panel key.
A spatial join that duplicates a feature once per intersecting polygon is a many-to-many merge in
geographic form, audited the same way. Not every package has a crosswalk: a single-city trial has
none, so say so and audit the attrition analog (4c.3).

### 4c.1 Crosswalk cardinality, spatial-join fan-out and key integrity

- **Check.** Locate the crosswalk (the file or dictionary mapping source units to targets) and the
  join that applies it, then three relations. Crosswalk cardinality: each source unit maps to its
  own target at a comparable unit of measurement, with no target borrowed from another unit and no
  pooling across incompatible sources. Join cardinality: the row count after the join equals the
  count before for a claimed one-to-one or point-in-polygon assignment. Key integrity: the key
  survives every read and write unchanged (leading zeros lost to type guessing, field names
  truncated on a shapefile write).
- **Tier.** Sample and estimates.
- **Which side.** Code for a fan-out or a corrupted key. Text when the crosswalk is applied
  correctly and the prose overstates it as clean (disclose split units and how they were
  apportioned).
- **Certify** only the code-visible criteria: a unique crosswalk key at the claimed grain, and a key
  that survives every read and write. The row-count criterion needs a run.
- **Published case.** Acemoglu, Johnson and Robinson (2001), via Albouy (2012): the
  settler-mortality rate is described as a comparable rate assigned to each of 64 former colonies,
  and 36 of the 64 were assigned a rate borrowed from another country, with incomparable populations
  pooled into one series.

### 4c.2 Panel operators and the grouping they trust

- **Check.** For each difference, lag or growth variable, identify the panel key the text says it
  respects ("first-differenced within city") and the sort or group the code applies right before the
  operator. If that sort or group omits the panel unit, or the operator relies on row order across
  gaps, the variable differences or lags across the wrong boundary.
- **Triggers.** A lag or difference built by row offset (`x[_n-1]`) where a declared-panel operator
  belongs, a sort key before the operator that omits the unit, a first-or-last selection that
  trusts the current sort.
- **Tier.** Estimates, and reproducibility when the order before the operator is itself not fixed.
- **Which side.** Code (add the unit to the sort or group key, or use `xtset` and `L.`, `D.`).
- **Certify** only after confirming the sort or group key contains the panel unit and imposes a
  deterministic order.
- **Published case.** Moretti (2021), via Wiebe: the instrument's first difference was taken after
  sorting by field, firm and year but not city, so it differenced across cities, and an earlier
  reordering made the instrument differ between runs.

### 4c.3 Panel attrition and the identifying variation that survives

- **Check.** Who leaves the sample between waves or periods, and what identifying variation remains.
  Join the text's attrition claim ("balanced across arms", "94% wore the device") to the code that
  builds the sample. Does the code ever test whether treatment predicts staying in the sample. After
  the drops, does treatment still vary within the cells the fixed effects leave.
- **Tier.** Sample, and estimates when attrition is differential.
- **Which side.** Usually a verification request: the data often allow the selection test the paper
  did not run (regress an in-sample indicator on treatment).
- **Certify** "attrition is balanced" only after the selection test was run and its result seen. A
  bounds routine whose formula was not read line by line is certified as present, and its values
  stay uncertified.

## 5. Inference

This dimension checks that the inference the text names is the inference the command runs. Estimator
identity is dimension 2.3. This dimension takes the estimator as given and audits standard errors,
clustering, degrees of freedom, multiple-testing adjustments and where p-values come from. Two gates
come first.

- **Identification gate.** Before any standard-error finding, check whether the command's absorbed
  effects absorb the variation the treatment needs. If a fixed effect enters at or above the level
  the treatment varies, the coefficient is not identified and the finding belongs to dimension 2.
- **Default gate.** A package default that differs from some convention is not a finding. It becomes
  one only when a quoted text claim contradicts it.

### 5.1 Degrees of freedom, singletons and separation

- **Check.** `reghdfe`, `areg` and `xtreg, fe` treat degrees of freedom and fixed effects nested in
  clusters differently, so standard errors can move when tables switch commands under one described
  structure. `reghdfe` drops singleton groups and `ppmlhdfe` drops separated observations, both
  silently changing N. Reconcile any stated N under dimension 3.
- **Tier.** Inference, and sample for the N.
- **Which side.** Text to disclose the drops and the convention when the code is defensible. Code
  when the convention is not the one the design needs.

### 5.2 Clustering

- **Check.** For every regression whose text names a clustering level, read the `vce(cluster ...)`,
  `cluster = ~var` or formula-slot argument of the command, and confirm the variable exists at the
  claimed level. This is the most productive check in the dimension and the one most exposed to
  silent defaults: a bare `reghdfe` reports unadjusted standard errors, `robust` without a cluster
  variable is not clustering, `feols` with no `vcov=` clusters on the first fixed effect, and `felm`
  clusters only when the fourth formula part names a variable.
- **Tier.** Inference only.
- **Which side.** Usually code (add or repair the clustering option). Text when the code clusters
  correctly and only the note names the wrong level.
- **Certify** only after the option, its level and the existence of that level in the data are
  traced. A blanket "all standard errors are clustered at X" is a claim about every exhibit: certify
  it only after every command in scope was read, else narrow the certification to those read.
- **Invented example, then the published foil.** A paper says standard errors are clustered at the
  village level, and the command is `reghdfe y treat x, absorb(village)` with no `vce()`: the table
  reports conventional standard errors (unless `absorb(village)` absorbs `treat`, in which case the
  identification gate fires). In the Bessone et al. package, the text's participant-level clustering
  matches `cluster(pid)` in `Table_2.do:54` and `Table_4.do:52`, so the claim certifies for the
  tables traced.

### 5.3 Tuning constants and silent conventions

- **Check.** When the text names a specific convention or constant (a small-sample correction, an
  equivalence with another program's standard errors, a Conley distance cutoff, a regression
  discontinuity bandwidth), trace the literal argument the command receives and confirm it equals
  the stated value. Nothing here is a finding unless a quoted value contradicts a literal read in
  the command.
- **Triggers.** "Standard errors match Stata's reghdfe" over a `feols` with no `ssc()`. "Robust, as
  in Stata" over `vcovHC()` with no `type=` (the default is HC3, and Stata's `robust` is HC1). A
  stated bandwidth or cutoff beside a different literal. Sample-derived constants (medians, cutoffs)
  frozen into code with no comment on their source.
- **Tier.** Inference, and estimates when a bandwidth or radius changes the estimation window.
- **Published case.** In the Bessone et al. package, the randomization-inference script rebuilds
  strata with hardcoded sample medians and a first-wave date (`Table_4_RI.do:125-141`). The
  permutation scheme matches the described stratification, so this is a code check. No sentence of
  the text is contradicted.

### 5.4 Stars and the source of p-values

- **Check.** Separate three objects: which p-values the stars represent (unadjusted or adjusted),
  how the unadjusted ones are computed, and where adjusted (family-wise or false-discovery) p-values
  come from, computed in the run or read from a shipped file.
- **Triggers.** A note pinning stars to "unadjusted p-values". A claim that adjusted p-values
  "control the family-wise error rate" (confirm a permutation or step-down procedure runs, on the
  design's real randomization scheme). Adjusted values imported from a shipped csv under a default
  that skips the computation. Permutation or bootstrap draws that reproduce only under an unpinned
  random number generator.
- **Tier.** Presentation and inference.
- **Certify** "the printed adjusted p-values are the ones the package ships" and, separately, "the
  named procedure is implemented". Certify that the adjusted values are correct only after a rerun
  with recomputation switched on, or after a value-by-value check of the shipped file.
- **Published case.** In the Bessone et al. package, the default `global RI = 0` makes `Table_4.do`
  import the adjusted p-values from a shipped `pval_adj_table_pool.csv`. Only with `RI = 1` are they
  recomputed from 10,000 re-randomizations, so a default run certifies them by their source. Their
  computation stays uncertified.

## 6. Robustness claims

A robustness sentence claims that an alternative estimation was run and that the conclusion
survived it. Two failures need different findings: the exercise is named and nothing in the package
implements it (existence), or it ships and its output does not support the summary word (adequacy).
Whether a requested robustness check could change a conclusion is a question about the argument,
outside this audit.

### 6.1 Existence

- **Check.** List every robustness sentence. Map each to a script that implements the alternative
  and an output from which the claim could be read. A clause with neither is a certification gap:
  the words claim evidence the package does not hold.
- **Triggers.** "Results are robust to", "a variety of methods", "unchanged when we", "qualitatively
  similar", especially with no table or figure named. In the package: no exhibit row for the
  exercise, and no second estimation command where the text promises several.
- **Which side.** Usually text: narrow the sentence to what was deposited, or add the exhibit. In
  Mode 1 and Mode 2a, the fix is often code: deposit the script that was run.
- **Published case.** In the Bessone et al. package, a footnote says results are "robust to a
  variety of methods" for a baseline imbalance, and the only method in the package is the baseline
  control already in the main specification (`examples.md`, example 8).

### 6.2 Adequacy

- **Check.** When a robustness script is present, read the values its exhibit holds and check that
  they support the word: the sign survives, significance survives, the magnitude stays in the range
  the text implies. A bounds exercise supports "robust" only if the informative end of the bound
  keeps the headline sign. In a coordinated reproduction of over 100 papers, only about 70% of
  pre-registered alternative analyses held (Brodeur, Mikola and Cook 2024, IZA Discussion Paper
  16912), so agreement is checked
  in the output each time.
- **Which side.** A verification request first. A static read confirms the exhibit is produced. It
  does not confirm that a hand-coded formula is correct.
- **Certify** the wiring only (the package produces the exhibit). The word "robust" needs the output
  values and, for a hand-coded routine, a line-by-line read or a rerun.

## 7. Data sources, vintages and seeds

Where the numbers came from before any regression ran: the named data source, the vintage or
extract, and the seed behind any randomness. Most packages ship cleaned analysis data with no
raw-to-clean code, so many source claims are out of static reach: say so precisely. Whether a source
is the right one (two datasets measuring one object and disagreeing) is a measurement debate,
outside this audit. The audit may note that the text never says which source the code read.

### 7a. Source identity and containment

- **Check.** For every dataset the text names, find the code that reads it and confirm three points:
  the file opened is the named source, it contains the claimed variable, and it holds it at the
  claimed unit and time coverage.
- **Triggers.** A named survey or registry with no matching read path. A variable named one way in
  the text and another in the code with no crosswalk. A level word ("firm-year") that the regressed
  object's key does not match.
- **Which side.** Usually text (name the exact source, variable and level). Phrase a containment gap
  as a request ("please confirm whether `age` in this dataset is the four-category quartile
  variable or age in years").
- **Certify** source identity only when the import path names the file, the text names the same
  source, and the level is legible from the shipped data's own keys. Under a cleaned-only deposit,
  that a variable means what the text says (its units, its construction) is out of static reach: the
  most the audit may certify is that the shipped variable is used as the text says it is used.
- **Published case.** In the Bessone et al. package, the text says age enters as quartiles,
  `Table_2.do:48` uses `i.quart_age`, and `Table_4.do:52` uses `i.age`. Whether `age` is the
  quartile variable or years cannot be settled because no construction code ships, so the finding is
  a request to rename or document.

### 7b. Vintage and extract

- **Check.** For every number drawn from a source that can be revised or re-extracted
  (administrative microdata, national accounts, census vintages, deflators, boundary files), the
  text names the vintage or extraction date, and the code's data path targets it. Correct code run
  against a shifted vintage does not reproduce correct numbers, and nothing in the code shows it.
- **Triggers.** A revisable source cited with no release date, a deflator with no stated base year,
  a boundary file whose vintage the text leaves open, a five-year survey claim over a single-year
  file, no software or package versions in the README.
- **Which side.** Text, almost always (add the extract date, release or base year).
- **Certify** a vintage only with a release or extract identifier on both the text side and the code
  side. Its absence is reported as a gap, and silence about vintage is never read as an endorsement.
- **Published case.** Piveteau (AEJ: Applied Economics, 2021), described in the AEA Data Editor's
  report of October 28, 2021: the code was correct, and by the time the data editor ran it
  the confidential customs extract had been replaced by an updated vintage, so the numbers did not
  reproduce and one sub-model could not be estimated.

### 7c. Seeds and randomization

- **Check.** For every result that depends on random draws (randomization inference, bootstrap,
  permutation, simulation, sample splits), the stated seed is passed into the call that drew the
  shipped output, the replication count matches, and the draw is reproducible across versions and
  stable under the code's sort order.
- **Triggers.** A stated seed with no seed on the governing call, a seed set far before a draw that
  later sorts can perturb (in Stata, `set seed` does not fix ties in an unstable sort), a
  replication count the master overrides, `set.seed()` with no `RNGversion()` in R,
  `random_state=None` in Python.
- **Which side.** Code (pass the seed into the call, align the count) or text (state the operative
  seed and count).
- **Certify** a seed only end to end: the stated seed governs the specific call that produced the
  output.

### 7d. External benchmarks

- **Check.** When the source cannot be opened, compare the paper's reported sample statistics with
  an independently known benchmark for the same population, and look for agreement too exact, or
  variance too small, to be genuine sampling. This is a question for the authors. It says nothing
  about authenticity.
- **Published case.** LaCour and Green (Science, 2014, retracted), via Broockman, Kalla and Aronow:
  a panel "newly fielded for the study" had a baseline wave statistically indistinguishable from an
  existing survey.

## 8. Package integrity

Every other dimension traces one claim to one line. This one audits the connections: whether the
code, run as its master script says, produces the exhibits the draft prints, and whether the
package's own map of itself is accurate. The text side here includes the README (a formal
exhibit-to-program table in the standard template) and the draft's list of exhibits. In Mode 1 these
items are not findings (see deposit regimes). A flat deposit (all files in one folder) makes README
folder paths logical, so a subfolder missing on disk is not a missing file.

### 8.1 The exhibit table, verified in both directions

- **Check.** Forward: each README row names a script that exists and writes the named output, and
  the output is on disk. Reverse: every exhibit in the draft has a row, and every output a script
  writes has a row. The reverse pass catches the more dangerous case, an exhibit or output no row
  accounts for.
- **Which side.** Usually text (repair or add the row).
- **Published case.** In the Bessone et al. package, the README maps Table A2 to one output, while
  `Table_A2.do` writes two, and both appear in the paper. Three other rows point at file names that
  do not resolve. After the full check in both directions, every shipped output mapped.

### 8.2 Master script, run order and orphans

- **Check.** Rebuild the call graph from the master file before trusting a "runs all scripts" claim,
  then test that each script runs after the writers of the datasets it reads, and that no script is
  an orphan (never called and mapped to no exhibit). Resolve every way a script calls another (`do`,
  `run`, `include`, `rsource`, `source`, `subprocess`).
- **Triggers.** A "calls all scripts" claim beside scripts the master never names, conditional calls
  that make the claim true only indirectly, a generated dataset whose writer comes after a reader,
  scattered absolute paths, a setup step described as one path edit that needs several.
- **Published case.** In the Bessone et al. package, the master never calls the
  randomization-inference scripts directly: they run inside the table scripts when `$RI == 1`. A
  naive orphan check would report them, and the true orphan count is zero once the call graph
  follows the conditional calls.

### 8.3 Staleness

- **Check.** An output older than its producing script, or an intermediate file no script writes,
  means the shipped exhibit was not produced by the shipped code as it now stands. File modification
  times corroborate and never decide: a flat deposit or a fresh checkout resets them all. The
  decisive check re-derives the value or finds the missing writer (dimension 1).
- **Which side.** Code: export the numbers from the estimation script, so the exhibit is rebuilt on
  every run.

### 8.4 Completeness and archiving

- **Check.** Before any single check, confirm that the package is complete and archived in a durable
  repository.
  Missing construction code, a coefficient file no script writes, an intermediate on an inaccessible
  server, or the absence of the exact code version behind the published tables is a first-order
  finding, because it makes any later error impossible to diagnose.
- **Tier.** It caps the certifiable scope of the whole audit, so report it first.
- **Published case.** Giuliano and Spilimbergo (2014, retracted 2023): the notice says the result
  could not be replicated, likely because of a coding error, and that the original code and data
  were no longer available to find the line at fault.
- **Certify** "the exhibit table is accurate" only after both directions were run, "no orphan
  scripts" only after the full call graph, and "the master reproduces the exhibits in order" only
  after every data dependency was checked against the run order. Under a deposit with no third-party
  run, the honest ceiling of a static read is "the code, as read, would produce this".

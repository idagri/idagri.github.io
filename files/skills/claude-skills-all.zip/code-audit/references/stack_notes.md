# Stack Notes: Command-to-Claim Patterns

Language-specific patterns for Stata, R and Python. Each entry names the text claim the pattern can
contradict (Claim), the code signature (Code), the check an auditor makes in the code without
executing it (Check), the consequence tier (Tier: estimates, inference, sample, presentation), and
the source of the behavior. The dimension numbers refer to `checks.md`.

Rules for every entry:

- **A signature prompts a check.** It is never the finding. A bare default becomes a discrepancy
  only when a quoted text claim contradicts it. A hit with no text claim behind it is at most a code
  check.
- **Absence of a guard is the norm.** Many published packages do not run a uniqueness check
  anywhere, so a missing `isid` or `validate=` is a weak signal until a text claim about uniqueness
  or a match rate depends on it.
- **Versions matter.** Several defaults changed across major versions (pandas `groupby` `dropna`,
  `to_datetime` inference, R's random number generator, dplyr join warnings, shapely and GEOS). Read
  `requirements.txt`, `environment.yml`, `renv.lock` or the README's version list first, and check a
  pinned older version against its own documentation. Missing version pins undercut any claim of
  exact reproducibility.
- **Source labels.** "Source" means a documented default or a published result, with the package
  version where the behavior was confirmed by running it. "Observed pattern" means the failure was
  seen in real research code and its mechanism follows from the arithmetic or the algorithm, with no
  documented default behind it. An observed-only entry prompts a check like any other, but it says
  nothing about how often the failure occurs, so it does not outrank a documented one in severity.

## Stata

Batch logs: a Stata batch run (`stata-se -b do file.do`) echoes the commands inside both branches of
an `if {...} else {...}`, and only the branch taken produces output. A line such as
`. di "NOTE: file not found, skipping merge"` is a command echo from an untaken branch, and it does
not show that the merge was skipped. Echoed commands start with `. `, output lines do not. To decide
whether a branch ran, look for its output (the `_merge` tabulation, the matched count). To find real
failures, search for lines matching `^r\([0-9]+\);`. The text of a defensive `di as error` message
is no evidence, since it may sit in a branch that never ran. A batch run exits 0 even when the
do-file stopped on an error.

### Merges and duplication

- **S1. Many-to-many merge.** Claim: a merge described as one-to-one or many-to-one on a key. Code:
  `merge m:m key using ...`. Check: there is almost no legitimate use. The key identifies rows on
  neither side, so Stata pairs rows in their current sort order, and the result neither errors nor
  reproduces the intended link. Check whether `joinby` (all pairwise matches) was intended. Tier:
  sample and estimates. Source: Stata `merge` manual. Published case: Moretti (2021), via Wiebe,
  where `m:m` merges on an unenforced sort made the cleaned panel differ from run to run.
- **S2. Cardinality declared loosely on the "many" side.** Claim: "we merge at the firm-year level".
  Code: `merge 1:1`, `m:1` or `1:m` with no prior `isid` or `duplicates report` on the side claimed
  unique, or a key that is only part of the stated unit (`merge 1:1 id` where the unit is `id` by
  `year`). Check: a duplicated "1" side stops with r(459). The silent risk is on the "many" side,
  where unintended duplicates each receive the using values and N grows with no error. Tier: sample
  and estimates. Source: Stata `merge` manual.
- **S3. Unmatched rows dropped silently.** Claim: "we drop observations that could not be matched",
  or no match rate beside a table that implies the full sample. Code: `keep if _merge == 3`,
  `drop if _merge != 3` or `drop _merge` with no `tab _merge` or `assert` before it. Check: look for
  a tabulation, `assert _merge == 3` or `keep(match)` before the result is used. A guard on a
  `_merge` category that the merge's own `keep()` already discarded can never fire. For long integer
  keys, check the creation site: a `float` holds every integer only up to `16777216`, so an ID
  created as float merges to the wrong partner with no missing values. Store IDs as `long`, `double`
  or text. Tier: sample, and estimates for the mis-keyed case. Source: Stata `merge` manual, Stata
  Blog "Merges gone bad".
- **S4. No uniqueness check before a merge or reshape claimed unique.** Claim: "each row is a unique
  firm-year". Code: no `isid` or `duplicates report` before a merge or reshape that needs the key to
  be unique, or a bare `duplicates drop` with no report first. Check: a bare `duplicates drop` keyed
  on value columns can discard different units that happen to share those values. Confirm the key
  names the unit's own identifier. Tier: sample. Source: Stata `duplicates` manual.
- **S5. A same-named variable on both sides.** Claim: "we merge in the updated version of X", or a
  comparison where one arm uses a rebuilt variable the file already holds. Code: `merge ... , nogen`
  or `keepusing()` bringing in a variable whose name already exists in the master, with no prior
  `rename`. Check: Stata keeps the master's copy and discards the using copy, silently, so the merge
  rate is perfect and the analysis uses the old variable under the new name. `set varabbrev off`
  does not help, since the names are identical. After the merge, the count of rows with a
  non-missing value must equal the number matched. The `update` option has its own trap: with
  `keep(master match)` it can leave rows unchanged, so merge incoming values under new names and
  `replace` explicitly. A structural sign: if widening a window can only add units and N falls, a
  name is being shadowed. Tier: estimates, and sample. Source: Stata `merge` manual. Observed
  pattern.
- **S6. Merge after a collapse.** Claim: "we merge the aggregate onto the finer data at the group
  level". Code: `collapse ..., by(group)` then `merge m:1 group using aggregate`. Check: the
  collapse makes its output unique at `by()`, so the "1" side passes its check by construction and
  the merge never errors. Confirm the `by()` list equals the merge key exactly, and that the fine
  side has a uniqueness check at its claimed unit. Tier: estimates and sample. Source: Stata `merge`
  manual.

### Specification and the estimation sample

- **S7. Estimation sample drift.** Claim: a summary table "for the estimation sample", or a results
  table where "column 2 adds X". Code: `summarize` or `tabstat` with no `if e(sample)` (or a saved
  indicator), or a table's regressions with different `if` clauses and no shared sample indicator
  while later columns add covariates with their own missing values. Check: each estimation command
  drops rows missing any of its variables, so the regression sample is usually smaller than a
  separately run summary. Look for `gen insample = e(sample)` after the most restrictive column and
  `if insample` elsewhere. Note that after some commands (for example `acreg`), `e(sample)` equals 1
  on the whole `if` window, including rows the command dropped, so a sample declared as an explicit
  condition and checked with `count if <condition>` against `e(N)` is safer. Tier: presentation up
  to estimates. Source: Jann, Stata Tip 44.
- **S8. Stale or empty macro control lists.** Claim: "all specifications control for X1, X2, X3".
  Code: `global controls ...` or `local controls ...` defined once and used across many regressions,
  or a local used outside the file or block that set it. Check: an undefined macro expands to
  nothing without an error, so `regress y $controls` can run as `regress y`. Trace every macro in an
  estimation command to its latest in-scope definition (locals do not survive across separate runs).
  Also check whether a shared global was updated for a later table while an earlier saved output
  still reflects the old list. Tier: estimates, and presentation for a note that overstates the
  controls. Source: Stata FAQ on macro scope.

### Sample construction

- **S9. Missing values counted as larger than any number.** Claim: "we drop observations with X
  above 1,000", "we winsorize above the 99th percentile". Code: `if x > c` (or `>=`) with no
  `& x < .` or `!missing(x)` in the same condition, in a `keep`, `drop`, `replace` or `gen`. Check:
  Stata orders `.` and `.a` to `.z` above every number, so `x > 1000` is true for missing `x`. Tier:
  sample and estimates. Source: Stata FAQ "Logical expressions and missing values". An author is
  least likely to catch this when the error moves the result in the expected direction, which is
  where a static audit adds value.

### Variable construction and its reference sample

- **S10. Standardization or group statistic on the wrong sample.** Claim: "standardized in the
  estimation sample", "z-scores relative to the control group". Code: `egen z = std(x)` (or `mean`,
  `sd`) run on the full data before a restriction, or `egen ..., by(group)` with a grouping the text
  does not name. Check: `egen` computes over the rows in memory at call time. Trace each call back
  to the `if`, `keep` or `drop` before it. Check the other direction too:
  `egen z = std(x) if insample` is missing outside `insample`, so a transform computed on a fixed
  sample and fed to a regression whose sample is meant to grow (a wider radius, a pooled robustness
  arm) silently caps that regression's N. The sign is an N that fails to grow when the stated
  restriction loosens. Tier: estimates. Source: Stata `egen` manual.
- **S11. Winsorization cuts or reference distribution.** Claim: "winsorized at the 1st and 99th
  percentiles", "within each year". Code: `winsor2 var, cuts(a b)` on the pooled sample when the
  text says within year, cuts that differ from the stated percentiles, or a call before a
  restriction the text applies first. Check: `winsor2` defaults to 1 and 99 and takes `by()`. Tier:
  estimates. Source: `winsor2` help (SSC).
- **S12. Collapse and missing values.** Claim: "district totals are the sum of their villages", "we
  average X at the group level", a group N. Code: `collapse (sum) x` or `(mean) x, by(group)` with
  no count of non-missing values. Check: `(sum)` returns 0 for a group whose every value is missing,
  which then reads as a measured zero, and `(mean)` uses the non-missing rows as its denominator. In
  both cases the output does not show how many rows were missing. Native `collapse` has no option to
  return missing: add `(count) n_x = x` to the same collapse and `replace x = . if n_x == 0`
  afterward (the user-written `gcollapse` accepts `missing`). Apply integer census expansion weights
  as `[fweight = w]`. A collapse grouped on part of the true key blends distinct records into one
  number. Tier: sample and estimates. Source: Stata `collapse` manual.

### Panels and longitudinal links

- **S13. Reshape errors fixed by dropping rows.** Claim: "the panel is balanced", "X is constant
  within unit". Code: `duplicates drop id time, force` or `bysort id time: keep if _n == 1` placed
  only to stop `reshape` from erroring. Check: the reshape error was the data's signal, and the fix
  hides it. Tier: sample. Source: Stata `reshape` manual.
- **S14. Lags by row offset.** Claim: "the lagged value of X", "the first difference within unit".
  Code: `gen lag_x = x[_n-1]`, or a difference by row arithmetic after a `sort` that omits the panel
  unit. Check: `x[_n-1]` is the previous row in the current sort, which across gaps or units is the
  wrong period or the wrong unit. `xtset id time` then `L.x` or `D.x` uses the time variable,
  returns missing across a gap and never crosses units. Tier: estimates. Source: Stata `xtset`
  manual. Published case: Moretti (2021), via Wiebe.

### Inference

- **S15. Clustering named in the text, absent or different in the command.** Claim: "standard errors
  are clustered at the district level". Code: `regress` with no `vce()`, `robust` only, `cluster()`
  on another variable, or `reghdfe ... absorb(...)` with no `vce(cluster ...)`, whose default is
  unadjusted conventional standard errors. Check: match each table's stated level to the exact
  argument, and confirm the variable exists at that level. Tier: inference. Source: Stata FAQ on
  robust and cluster standard errors, Cameron and Miller (2015).
- **S16. `reghdfe`, `areg` and `xtreg, fe` treated as interchangeable.** Claim: one two-way
  fixed-effects model described across tables. Code: switching commands across tables. Check:
  `reghdfe` follows the `xtreg` degrees-of-freedom convention (which differs from `areg`), excludes
  a fixed effect nested in the cluster from the count, and drops singleton groups by default,
  silently changing N. Reconcile the stated N with possible singleton drops, especially under
  `quietly`, and confirm that the fixed effect said to be nested in the cluster is the same variable
  in `absorb()` and in `vce(cluster ...)`. Tier: inference and sample. Source: Correia (2015),
  `reghdfe` documentation.
- **S17. Weight type.** Claim: "weighted by population", "sampling weights make the sample
  representative". Code: `[aweight=w]` where the text describes sampling weights (`pweight`), or
  `[fweight=w]` on a variable that is not an integer count. Check: `aweight` and `pweight` give the
  same point estimates in linear regression and different standard errors. Tier: inference, and
  estimates in nonlinear models. Source: Stata weights FAQ, Solon, Haider and Wooldridge (2015).
- **S18. A spatial-HAC routine that reports success with a variance that is not a variance.** Claim:
  "standard errors allow for spatial correlation within N km", especially in a sweep over cutoffs
  whose best cell is the headline. Code: `acreg` or another Conley routine in a loop, success judged
  by `_rc`, the estimate posted with no check on `e(V)`. Check: the Conley variance matrix can be
  non-positive-definite when the cutoff is wide relative to the sample, and the command still
  returns rc 0. The standard error then comes back missing or tiny, the F enormous, and in a sweep
  these cells sort to the top. Require a check that the relevant diagonal of `e(V)` is positive, and
  that the count of failed cells is reported. Tier: inference. Source: kernel HAC estimators need
  not be positive semi-definite without a suitable kernel. Observed pattern for the silent return
  code.
- **S19. PPML with many fixed effects run as plain Poisson.** Claim: "we estimate the gravity
  equation by PPML" with high-dimensional fixed effects. Code: `poisson` or `glm, family(poisson)`.
  Check: plain Poisson can fail to converge or converge wrongly under separation, and `ppmlhdfe`
  detects and drops separated observations. Reconcile its "observations dropped due to separation"
  with the reported N. Tier: sample and estimates. Source: Correia, Guimaraes and Zylkin (2020).

### Reproducibility and defensive code

- **S20. Sort order treated as reproducible.** Claim: "we keep the first record per firm", "the
  earliest record", or exact cross-run reproducibility. Code: `sort var` without `, stable` followed
  by `by var: keep if _n == 1`, or reliance on `set seed` or `set sortseed`. Check: Stata's default
  sort breaks ties at random, so the kept row can change between runs, machines and processor counts
  (Stata/MP differs by core count). Use `sort var, stable` or add an identifier to the sort key.
  Tier: sample, hence estimates. Source: Stata `sort` manual.
- **S21. Name abbreviation and `capture`.** Code: no `set varabbrev off` at the top of the file, and
  `cap drop`, `cap gen`, `cap rename` where success matters. Check: with abbreviation on,
  `cap drop x` deletes `x_pc` when `x` does not exist, and `cap gen x = ...` silently does nothing
  when an imported `x` already exists, keeping the import's missing pattern. Rebuild derived
  variables with `cap drop x` followed by a plain `gen`, after `set varabbrev off`. Tier: estimates.
  Source: Stata `set varabbrev` and `capture` manuals.

## R

Every pattern is a static read. A bare package default is a finding only when a text claim
contradicts it.

### Merges, duplication and match rates

- **R1. Base `merge()` fans out on duplicate keys.** Claim: a one-to-one or many-to-one link, or a
  stated merged N. Code: `merge(x, y, by = ...)` with no `anyDuplicated()` check before and no
  `nrow()` assertion after. Check: duplicate keys on both sides produce every matching pair,
  silently. Confirm `by` is the full unit key (`district` where the key is district by year is the
  bug). `merge()` also sorts on the key by default, so later position-based alignment is suspect.
  Tier: sample and estimates. Source: `base::merge` help.
- **R2. Base `merge()` is an inner join by default.** Claim: "we keep all firms", or an N that
  assumes nothing was dropped. Code: `merge()` with no `all`, `all.x` or `all.y`. Check: unmatched
  rows on either side disappear. Tier: sample. Source: `base::merge` help.
- **R3. dplyr joins do not block many-to-many.** Claim: "each row is a unique firm-year". Code:
  `left_join()`, `inner_join()` or `full_join()` with no `relationship=`. Check: dplyr 1.1.0 and
  later warn on a many-to-many match and still return it, older versions say nothing, and
  `suppressWarnings()` hides the warning. Tier: sample and estimates. Source: dplyr join reference.
- **R4. readr type guessing strips leading zeros from IDs.** Claim: IDs match exactly across files
  (FIPS, ZIP, respondent IDs). Code: `read_csv()` with no `col_types` pinning the ID to character.
  Check: the type is guessed from the first rows read, so an ID that looks numeric there loses its
  leading zeros elsewhere. Tier: sample (spurious non-matches, or a match to the wrong unit).
  Source: readr column-type documentation.
- **R5. `left_join()` then `na.omit()`.** Claim: "we drop observations with missing X". Code: a
  left join followed, often much later, by `na.omit()`, `drop_na()` or `complete.cases()`. Check:
  rows that never matched are dropped as "missing", and the match rate never appears. Look for a
  match-rate count or an `anti_join()` between the two steps. Tier: sample. Source: dplyr joins and
  `na.omit` semantics.

### Sample construction and missing data

- **R6. `filter()` drops NA rows.** Claim: a stated missing-data policy. Code: `filter(df, x > c)`
  on a variable with missing values and no `is.na()` clause. Check: a comparison with NA is NA, and
  `filter()` keeps only TRUE rows, so missing rows leave uncounted. Tier: sample. Source: dplyr
  `filter()` reference.
- **R7. `lm()` and `glm()` drop rows per column.** Claim: "all columns use the same N". Code:
  successive models fit on the raw frame with the default `na.action = na.omit` and no shared
  complete-cases frame. Check: each model drops rows missing any of its own variables. Tier: sample.
  Source: `stats::lm` help.
- **R8. `aggregate()` drops whole groups.** Claim: "a balanced panel of district-years". Code:
  formula `aggregate(y ~ g1 + g2, data, FUN = mean)` with no `na.action`. Check: a missing value in
  any formula variable drops the row before aggregation, so cells can vanish. Tier: sample. Source:
  `stats::aggregate` help.

### Variable definitions and coding

- **R9. `cor()` and `cov()` ignore the table's missing-data rule.** Claim: "statistics exclude
  missing values". Code: `mean(x, na.rm = TRUE)` beside a bare `cor(x, y)` with no `use=`. Check:
  the default `use = "everything"` returns NA for any cell with a missing input. Tier: presentation.
  Source: `stats::cor` help.
- **R10. haven value labels left as raw codes.** Claim: "treatment is coded 1 for treated, 0 for
  control". Code: `read_dta()` then arithmetic or `== 1` on a labelled column with no `as_factor()`
  or check of the codes. Check: the stored values are Stata's codes, which may be 1 and 2. Tier:
  estimates and sample. Source: haven documentation.
- **R11. Two `as_factor()` functions.** Code: `library(haven)` followed by forcats or the tidyverse,
  then an unqualified `as_factor()`. Check: haven's version uses the value labels, forcats' version
  orders levels by first appearance, and which one runs depends on the order packages were attached.
  Tier: estimates and presentation. Source: haven and forcats documentation.
- **R12. Factor level order sets the omitted category.** Claim: "coefficients are relative to
  region A". Code: `factor(region)` with no `levels=` or `relevel()`. Check: the first level after
  sorting is the reference, whatever the text says. Tier: estimates and interpretation. Source:
  `stats::relevel` help.

### Inference

- **R13. fixest default standard errors.** Claim: "clustered at the district level" or "robust".
  Code: `feols(y ~ x | fe1 + fe2)` with no `vcov=` or `cluster=` and no `setFixest_vcov()`. Check:
  the default is IID with no fixed effects and clustering on the first fixed effect with them, with
  no warning. Tier: inference. Source: fixest reference.
- **R14. fixest small-sample correction.** Claim: "standard errors match Stata's reghdfe" or a named
  correction. Code: no `ssc()` override. Check: the defaults are one convention among several. A
  bare call is not a finding unless the text makes one of these claims. Tier: inference. Source:
  fixest `ssc()` reference.
- **R15. `lfe::felm` clusters only in the fourth formula part.** Claim: "clustered by firm". Code:
  `felm(y ~ x | fe)` or a `0` in the fourth part, then `summary(m, robust = TRUE)`. Check: that
  summary reports heteroskedasticity-robust standard errors, which look like clustered ones. Tier:
  inference. Source: `lfe::felm` help.
- **R16. sandwich defaults to HC3.** Claim: robust standard errors "as in Stata". Code: `vcovHC(m)`
  with no `type=`. Check: the default is HC3, and Stata's `robust` is HC1. Tier: inference. Source:
  sandwich reference.

### Seeds and versions

- **R17. `set.seed()` across the R 3.6.0 change.** Claim: "results are exactly reproducible with the
  seed in the code". Code: `set.seed(n)` with no `RNGversion()` and no R version pinned, before
  `sample()`, a bootstrap or a simulation. Check: R 3.6.0 changed the sampling algorithm, so one
  seed gives different draws before and after. Tier: inference. Source: R `Random` help.
- **R18. `stringsAsFactors` changed in R 4.0.0.** Code: base `read.csv()` or `data.frame()` with no
  `stringsAsFactors=`, no version pin, and later branching on `is.factor()`. Check: the same code
  treats columns differently across versions. Without the branching this is only a reproducibility
  note. Tier: presentation. Source: R 4.0.0 NEWS.

### Spatial (sf)

- **R19. `st_area()` and `st_length()` units.** Claim: "areas in square kilometers". Code:
  `as.numeric(st_area(x)) / 1e6` on an object whose CRS is in feet or missing. Check: the result is
  in the CRS's own unit, and `as.numeric()` strips the unit before anything can object. Tier:
  estimates. Source: sf reference.
- **R20. `st_join()` duplicates rows on several matches.** Claim: "each observation is assigned to
  its containing district". Code: `st_join(x, y)` with the default `st_intersects`, no
  `largest = TRUE`, and polygons that can overlap or share edges. Check: a feature matching several
  polygons is copied once per match. Look for `largest = TRUE` or a row-count assertion. Tier:
  sample and estimates. Source: sf `st_join` reference.

## Python: pandas

### Merges, joins and duplication

- **P1. Merge without `validate=`.** Claim: a one-to-one or many-to-one match. Code: `pd.merge()` or
  `.merge()` with no `validate="1:1"`, `"m:1"` or `"1:m"` (`validate="m:m"` checks nothing). Check:
  compare the stated cardinality with the key's uniqueness, and look for `indicator=True` and an
  asserted match rate. Tier: sample and estimates. Source: pandas `merge` reference.
- **P2. Inner join by default.** Claim: "we keep all observations from the main sample". Code:
  `merge()` with no `how=`. Check: unmatched rows vanish. Tier: sample. Source: pandas `merge`
  reference.
- **P3. Integer IDs upcast to float.** Claim: "the ID is an integer". Code: an `int64` key that
  meets a NaN (an outer or left merge, `reindex`, `concat` of unequal frames) and is later used as a
  key, with no `astype("Int64")`. Check: the column becomes float, and large IDs lose precision past
  `2**53`. An outer merge can upcast keys even when every key matches. Tier: presentation,
  escalating to sample. Source: pandas nullable-integer guide.
- **P4. Merging on float keys.** Claim: "matched on coordinates", "matched on the rate". Code: a
  merge on a `float64` key built by arithmetic. Check: last-digit differences fail to match, and
  under an inner join the rows drop. Round identically or cast to text on both sides. Tier: sample.
  Source: pandas issue tracker.
- **P5. Duplicated index after `concat`.** Claim: "we stack the waves into one panel". Code:
  `pd.concat([...])` with neither `ignore_index=True` nor `verify_integrity=True`, then `.loc[id]`.
  Check: a duplicated label returns several rows. Tier: sample and presentation. Source: pandas
  `concat` reference.
- **P6. Keys of different widths or types.** Claim: "villages are matched to the census". Code: a
  merge on a code stored as text on one side and as a number on the other, or with different widths,
  or a numeric `.dta` ID cast with `.astype(str)` (which gives `"1101.0"`). Check: the merge matches
  nothing and raises nothing, and the result reads like genuine non-overlap. Print
  `.str.len().unique()` and a few values on both sides first, pad the short key (`str.ljust` for a
  code that stops at a coarser level, `str.zfill` for one missing its leading zeros) and never
  truncate the long one. Tier: sample. Observed pattern.
- **P7. A coarser key derived by arithmetic.** Claim: "village records are matched to their
  district". Code: `df["parent"] = df["child"] // N` or `.str[:k]`. Check: the divisor is a fact
  about the coding system, so check it against the system's documentation or a printed example row.
  A wrong divisor gives keys that match nothing, and an empty sample follows with no error. Tier:
  sample. Observed pattern.

### Variable construction and missing data

- **P8. Index alignment on assignment.** Claim: "we assign the computed series to the dataset".
  Code: `df["new"] = series` where the series came from a different subset, a `groupby` or a
  separate read. Check: labels that do not overlap receive NaN, which a later `dropna` removes
  uncounted. Tier: sample and estimates. Source: pandas user guide.
- **P9. `groupby` drops missing keys.** Claim: "we compute means for all districts". Code: `groupby`
  with no `dropna=False`. Check: rows whose key is missing leave the aggregate (the default since
  pandas 1.1). Tier: sample. Source: pandas `groupby` reference.
- **P10. `skipna=True` against a stated rule.** Claim: "missing values are treated as zero", "we
  require all components". Code: `.mean()`, `.sum()` or `.std()` building an index or score with no
  `fillna`, `dropna` or `skipna=False`. Check: the default applies neither stated rule. Tier:
  estimates. Source: pandas reduction reference.
- **P11. Chained indexing.** Claim: "we recode X for the subsample meeting C". Code:
  `df[df.c]["x"] = v`, or a slice edited later, where the edit needs `.loc[df.c, "x"] = v` or an
  explicit `.copy()`. Check: the edit may never reach the frame used later, and suppressed warnings
  hide the sign. Tier: estimates. Source: pandas indexing guide.
- **P12. `read_csv` missing-value defaults.** Claim: "missing values are coded -99". Code:
  `read_csv()` with no `na_values=`, or with `na_values=` and `keep_default_na=True`. Check: the
  default list (`"NA"`, `"NULL"`, `"None"`, `"n/a"`, `"nan"`) turns valid codes into missing, and a
  real missing code such as `-99` stays as data. Tier: estimates and sample. Source: pandas
  `read_csv` reference.
- **P13. Ambiguous dates.** Claim: "dates are recorded day first". Code: `pd.to_datetime(col)` with
  no `dayfirst=` and no `format=`. Check: dates with both parts at 12 or below parse silently under
  the wrong convention. Only an explicit `format=` is deterministic. Tier: sample and estimates.
  Source: pandas `to_datetime` reference.
- **P14. Missingness decided at ingestion.** Claim: "villages with no market are coded zero", "the
  measure is missing outside coverage". Code: a `.fillna(0)` (or Stata
  `replace v = 0 if missing(v)`) between a read and an aggregation, and equally its absence before a
  sum of components or a presence indicator. Check: both directions. A blank that means unknown,
  filled with zero, creates observations that survive every later filter. A blank that means zero,
  left missing, makes a sum of components missing whenever one part is blank, and a presence
  indicator built as `count >= 1` takes only the values one or missing, so its mean over non-missing
  rows is exactly 1. Check whether each variable's meaning of a blank was decided, and where. A mean
  or median fill is the same decision as a zero fill: print how many rows each fill touched. Tier:
  estimates and sample. Observed pattern.
- **P15. `groupby().sum()` returns 0 for an all-missing group.** Claim: "the district total is the
  sum of its villages", or a ratio with such a sum on top. Code: `.sum()` with no `min_count=1`.
  Check: a group with no observed values returns `0.0` and stays in the table as a confident zero.
  This differs from P9, which drops a group whose key is missing. Tier: estimates. Source: pandas
  `sum` reference (`min_count` defaults to 0), confirmed on pandas 2.3.3.
- **P16. Winsorization undone by aggregation.** Claim: "yields are winsorized at the 1st and 99th
  percentiles", with results at a coarser level. Code: `np.clip` (or `winsor2`) on a ratio at a fine
  level, then the coarse level recomputed as `sum(numerator) / sum(denominator)`. Check: the coarse
  ratio recovers the unwinsorized value exactly, because the sums run over the untouched numerator
  and denominator. Rebuild the numerator from the clipped ratio before aggregating, and check
  whether the percentiles come from the fine or the coarse distribution. Tier: estimates. Observed
  pattern.
- **P17. A correlation offered as proof that a rebuild is exact.** Claim: "our reconstruction
  matches the published series (r = 1.00)". Code: `np.corrcoef` or `.corr()` reported as the
  validation, with no slope, intercept or largest absolute deviation. Check: correlation is
  unchanged by any linear rescaling, so it shows that the two series share information. It cannot
  show that they are the same numbers. A rebuild on a compressed scale can correlate above 0.999
  with its target. When such a rebuild is then subtracted from a target-scale variable, the
  resulting coefficients fall between the naive and the intended ones, which looks reassuring. Ask
  for a slope near one, an intercept near zero and a bounded largest deviation. Tier: estimates.
  Observed pattern.
- **P18. A variable name that states a unit the data do not have.** Claim: "a one-hour increase in
  travel time", "in 2010 dollars", "an additional kilometer". Code: a column named `*_min`, `*_km`
  or `*_usd` whose producer never applied the conversion, or two sources of one quantity where only
  one was rescaled. Check: trace the unit to the line that created it, and test it against a known
  real-world value (a familiar city pair, a known distance). Many estimators are unchanged by a
  constant rescaling inside a log with unit fixed effects, so reproduced point estimates are no
  evidence that the units are right, and any sentence converting the coefficient into minutes or
  dollars is off by the conversion factor. Tier: presentation and estimates. Observed pattern.
- **P19. Mixed columns read from `.dta` as `object`.** Claim: any sample rule built on a numeric
  column. Code: `pyreadstat` or `pd.read_stata` with a column returned as `object`, then `.notna()`
  or comparisons. Check: `.notna()` is true for a string, so a rule can admit values nobody
  measured, and an integer list matched against an `object` ID column matches nothing. Coerce with
  `pd.to_numeric(errors="coerce")` and assert that the non-missing count did not fall. Tier: sample.
  Observed pattern.

### Sample construction and selection rules

- **P20. Unstable sort before keep-first.** Claim: "we keep the earliest record per unit". Code:
  `sort_values(col).drop_duplicates(subset=key, keep="first")` or `.groupby(key).first()` where the
  sort has ties within the key and no `kind="stable"` or tie-break column, or a `groupby` result
  combined with another frame by position. Check: which tied row survives is not determined. Tier:
  sample and estimates. Source: pandas `sort_values` (the default `quicksort` is not stable).
- **P21. Two scripts build the same list with the filter on opposite sides of the aggregation.**
  Claim: one count used twice ("the N facilities in the measure are the N on the map"). Code: one
  script aggregates first and then filters on a non-missing coordinate, another filters first and
  then deduplicates. Check: the two disagree on units whose first record lacks the coordinate.
  Locate every script that builds the list and compare the order of filter and aggregation. Tier:
  presentation, and sample when the list defines a measure's support. Observed pattern.
- **P22. An exclusion at the wrong administrative level.** Claim: "we exclude district D because the
  policy does not apply there". Code: a mask keyed on a finer identifier than the unit the text
  names, or an exclusion before an aggregation that averages the unit back in. Check: the exclusion
  agrees with the text only while the finer unit is the sole member of the coarser one. Hold the
  verb to the code too: "dropped" where the code drops, "winsorized" where it clips. Tier: sample.
  Observed pattern.
- **P23. Every coverage check is internal.** Claim: "we observe all districts", or a coverage gap
  reported as a feature of the setting ("these units have no residents"). Code: every reconciliation
  internal to the build (parts sum to the total, aggregates match the micro file) and none against
  an external published total. Check: a truncated source file still sums to itself. Compare each
  unit with the issuing agency's published figure. A unit at zero differs in kind from a unit that
  is merely low: a partial undercount is absorbed by a unit fixed effect, a missing unit creates
  false zeros. Tier: sample and estimates. Observed pattern.

### Seeds

- **P24. Seeds that do not reproduce the stated seed.** Claim: "we set the seed to N", "a fixed
  80/20 split". Code: `.sample()` or `train_test_split()` with no `random_state=`, or one shared
  random generator passed to several calls, so an added earlier draw shifts every later one. Check:
  confirm an integer `random_state=` matching the stated seed on each call. Tier: estimates and
  inference. Source: scikit-learn `train_test_split` reference, pandas `.sample()` reference.

### Checks on the run behind the output

Run these early, because a hit changes what the rest of the audit is auditing.

- **P25. The file read is not the specification that ran.** Claim: any reported specification for a
  script whose behavior is set outside the file. Code: `os.environ.get("X", default)` in a producer,
  a driver `.sh` or `Makefile` that sets the variables, a notebook with injected parameters, or a
  producer cloned from another with its own edited defaults. Check: the defaults written in the file
  are not what ran. Reconcile the reported specification with how the run was launched (the driver,
  the log header). Two related cases: a path macro assigned inside a cloned script points its whole
  chain at another data vintage, and a diagnostic copied from a sibling script keeps the sibling's
  banner, so its output claims a check it did not run. Where a package ships environment-driven
  producers and no driver, the specification cannot be recovered from the deposit, and that is
  itself the finding. Tier: estimates. Observed pattern.
- **P26. A solver's "converged" flag away from a fixed point.** Claim: "the model converged", or a
  reported objective or moment from a fitted equilibrium model. Code: `scipy.optimize.fixed_point`,
  Anderson mixing or another accelerator, with success judged by the returned flag. Check: these
  methods stop on the change between iterates, so they can report success at a point that is not a
  fixed point. Ask that the residual itself (`||F(x*) - x*||`) was printed or asserted, and whether
  several starting values were tried. Tier: estimates. Source: the documented stopping rules of the
  accelerators.
- **P27. Cached intermediate files go stale.** Claim: the pipeline is consistent end to end. Code:
  `to_parquet`, `.npy` or `.feather` files keyed only by a file name, or a producer writing a dated
  output while its consumer reads an older date. Check: compare modification times of each
  intermediate and its inputs, and look for a date mismatch between the newest output and the name
  the consumer reads. Tier: estimates when a stale file feeds a table. Observed pattern.
- **P28. The chain runs only because an intermediate is already committed.** Claim: "the code
  reproduces every exhibit from the raw data". Code: a script that reads a file which a later script
  in the run order writes, with an old copy present in the package. Check: list, for every script,
  the files it reads and writes, and confirm each read is produced by an earlier script or is a
  genuine input. A clean run into an empty data folder exposes each forward dependency as a missing
  file. Tier: package integrity, and estimates when the committed file is stale. Observed pattern.

## Python and R: spatial work

The recurring silent failure: a spatial operation finishes and returns plausible numbers while using
the wrong CRS, the wrong units or the wrong cardinality. Trace the active CRS back to the last read,
`set_crs` or `to_crs` before every geometric call. A package computing travel times, market access
or raster-based exposures may never create a GeoDataFrame, so the vector entries return nothing
there. Run the raster entries instead.

### CRS and projection

- **G1. Area, length or distance on a geographic CRS.** Claim: "areas in square kilometers",
  "distance in kilometers". Code: `.area`, `.length`, `.distance()`, `.buffer()` while the CRS is in
  degrees (often EPSG:4326), sometimes with a stray "degrees to km" constant. Tier: estimates.
  Source: geopandas documentation.
- **G2. `set_crs()` where `to_crs()` was needed.** Claim: "coordinates were reprojected". Code:
  `set_crs(epsg)` (or with `allow_override=True`) with reprojection intent. Check: `set_crs`
  relabels and does not move any coordinate. Tier: estimates. Source: geopandas documentation.
- **G3. Buffer distance in CRS units.** Claim: "a 5 km buffer". Code: `buffer(5)` under a geographic
  CRS (5 degrees), or a literal that does not match the metric unit (`buffer(5000)` under UTM is 5
  km). Tier: sample and estimates. Source: geopandas documentation.
- **G4. Centroid on unprojected geometry.** Code: `.centroid` under a degree CRS, fed to a distance
  or nearest join. Check: unlike `.area`, the centroid call does not warn about the CRS. Tier:
  estimates. Source: geopandas documentation.
- **G5. A multipart centroid outside its own polygon.** Claim: "distances from each unit's center".
  Code: `.centroid` on `MultiPolygon` rows (archipelagos, split units) feeding a distance or a
  least-cost origin. Check: count `(~gdf.contains(gdf.centroid)).sum()`. `representative_point()`
  always lies inside. Unless the text says how the point is chosen, this is a disclosure note. Tier:
  sample and estimates. Source: shapely centroid semantics.
- **G6. Metric and still the wrong projection family.** Claim: areas, densities or shape measures.
  Code: `.to_crs(3857)` (Web Mercator) then `.area`, one UTM zone across several zones, or an
  equal-area CRS used for distances. Check: areas need an equal-area projection and distances an
  equidistant one or a geodesic. Web Mercator inflates area by about the squared secant of latitude
  (about 1.7 times at 40 degrees, 4 times at 60), so the area variable becomes a function of
  latitude. Tier: estimates. Source: EPSG registry entry for 3857.
- **G7. Axis order in a manual reprojection.** Code: `Transformer.from_crs("EPSG:4326", target)`
  with `always_xy=False` (the default), or `points_from_xy(df.lat, df.lon)` with the arguments
  reversed. Check: usually loud (points in the ocean), silent near the equator, where latitude and
  longitude ranges overlap. Tier: sample and estimates. Source: pyproj documentation.
- **G8. `simplify()` tolerance and empty geometries.** Claim: "all N units are shown", or a
  simplified layer reused for analysis. Code: `simplify(t)` with `t` read as meters under a degree
  CRS, or `preserve_topology=False` with a tolerance near the smallest unit's size. Check: under
  `preserve_topology=False` a small polygon becomes an empty geometry that stays in the frame as a
  row, so a row count still matches. Count `is_empty` and total area on both sides. Tier:
  presentation, and sample when the layer is reused. Source: shapely `simplify` reference, confirmed
  on shapely 2.0.7.
- **G9. A longitude-latitude plot is not the named projection.** Claim: a figure note naming a
  projection. Code: geometry still in EPSG:4326 at plot time. Check: compare the CRS at the plotting
  call with the caption. Clean when the caption does not name a projection. Tier: presentation.
  Source: geopandas `plot` reference.
- **G10. A hand-rolled mean of coordinates used as a location.** Claim: "each unit's coordinates are
  its centroid". Code: a weighted mean of longitude and latitude columns in pandas or Stata. Check:
  no `.centroid` call exists to search for, so trace the coordinate columns. A weighted mean is not
  a centroid, and the point can fall outside a fragmented unit. Where it feeds Conley standard
  errors, it moves the neighborhoods. Tier: inference and estimates. Observed pattern.

### Spatial joins

- **G11. `sjoin` duplicates rows.** Claim: "each observation is assigned to its district". Code:
  `gpd.sjoin()` with no row-count assertion or largest-overlap rule afterward. Check: a point on a
  shared boundary matches two polygons and appears twice. Tier: sample and estimates. Source:
  geopandas `sjoin` reference.
- **G12. Predicate choice.** Claim: a stated boundary rule ("strictly within"). Code: the default
  `predicate="intersects"` or a predicate that differs from the text. Check: predicates differ only
  at edges, so aggregates look unchanged while the matched set differs. A bare `intersects` where
  the text describes an area-overlap screen admits units below the threshold. Tier: sample. Source:
  geopandas `sjoin` reference.
- **G13. `sjoin_nearest` with no `max_distance`.** Claim: "matched to the nearest station",
  implicitly nearby. Code: no `max_distance=`. Check: every row gets a match however far. Look for a
  summary of the distances. Tier: sample and estimates. Source: geopandas `sjoin_nearest` reference.
- **G14. Nearest match by matrix `argmin`.** Code: `D.argmin(axis=1)` and `D.min(axis=1)` on a full
  distance or cost matrix. Check: G13's mechanism with nothing to search for. Check whether the
  minimum is ever summarized (a maximum, a histogram). A floor applied with no cap (`np.maximum(D,
  floor)`) guards a divide-by-zero and does nothing about implausibly distant matches. Tier: sample
  and estimates. Observed pattern.

### Aggregation and overlay

- **G15. `dissolve()` keeps the first row's attributes.** Claim: "we aggregate blocks to regions"
  with summed or weighted attributes. Code: `dissolve(by=...)` with no `aggfunc=`. Check: the
  default `"first"` keeps one arbitrary row's values. Tier: estimates. Source: geopandas `dissolve`
  reference.
- **G16. `overlay()` repairs invalid inputs.** Code: `gpd.overlay()` on unvalidated layers. Check:
  invalid geometries are repaired internally and near-boundary mismatches create sliver polygons
  that inflate piece counts. Look for a minimum-area filter. Tier: sample and presentation. Source:
  geopandas `overlay` reference.
- **G17. `.buffer(0)` as a validity repair.** Claim: "invalid geometries were repaired". Code:
  `geometry.buffer(0)` with no counts before or after. Check: on a self-intersecting ring it keeps
  one lobe and discards the rest, and it can leave an empty geometry in the frame. `make_valid()`
  keeps the whole area. Compare total area across the step. Tier: sample and estimates. Source:
  shapely `make_valid` reference, confirmed on shapely 2.0.7.

### Raster extraction

- **G18. `zonal_stats` center-point rule.** Claim: "the average of the raster within each polygon".
  Code: `rasterstats.zonal_stats()` with no `all_touched=`. Check: a cell counts only if its center
  is inside, so a polygon a few pixels across can get zero or one cell. Tier: estimates. Source:
  rasterstats manual.
- **G19. Raster and vector in different CRSs.** Code: zonal statistics, `rasterio.mask` or
  `exact_extract` where the vector's CRS differs from the raster's, with no `to_crs(raster.crs)`.
  Check: rasterstats does no reprojection. The silent case is projected against projected (two UTM
  zones), which returns plausible numbers from the wrong ground. Tier: estimates. Source:
  rasterstats manual.
- **G20. Hand-rolled zonal statistics.** Code: `rasterio.features.rasterize()` in a windowed loop
  with `np.bincount`. Check: G18 and G19 still apply and their searches do not fire. Add two
  questions: a polygon straddling two read windows must be counted once (safe with full-width row
  strips, broken under tiled windows), and the nodata guard needs the raster's own sentinel,
  non-finite values and negative fill. Tier: estimates. Observed pattern.
- **G21. A coarse gridded total allocated by area.** Claim: "GDP (or population, or emissions)
  within each unit", or any per-capita ratio from a gridded product. Code: an extensive quantity on
  a coarse grid allocated to units by area overlap, where units are small relative to the cell.
  Check: a sparsely populated unit still collects its full geometric share, and any ratio with
  population below it explodes. Allocate by a covariate that holds the quantity (population for
  GDP): `Q(unit) = sum over cells c of Q(c) * pop(unit and c) / pop(c)`. Then a unit with no people
  gets none, and the children sum exactly to the parent. Ask for that roll-up check. Tier:
  estimates. Source: standard downscaling of gridded data.

### Cost surfaces and raster paths

- **G22. Least-cost travel time on a friction raster.** Claim: "travel time in minutes on a 1 km
  friction surface". Code: `skimage.graph.MCP` or `MCP_Geometric`, `route_through_array`, GRASS
  `r.cost`, or a desktop GIS run (G34). Check: the step cost must combine friction with pixel size,
  or every time is off by a constant that preserves the ranking. Plain `MCP` charges a diagonal step
  as one step and `MCP_Geometric` as the square root of two, so diagonal routes can be undercosted
  by up to about 29%. Sources must sit on traversable cells: look for the snapping step and how far
  points moved. Symmetrizing the matrix is a modeling choice to disclose. Tier: estimates. Source:
  scikit-image `MCP_Geometric` reference.
- **G23. Masks built by exact equality with a sentinel.** Claim: "ocean cells are barriers". Code:
  `land = (f != 0) & (f != 60)` or a hardcoded nodata constant. Check: the sentinel lives in the
  raster's metadata, and one product family can ship different data types at different resolutions,
  so a hardcoded `65535` misses a `uint32` sentinel of `4294967295`. Read `src.nodata` from the file
  and cast it to the band's type. Rank units by the summed quantity and look at the top few: an
  absurd leader settles it. An exact-equality mask survives only nearest-neighbor resampling, and
  bilinear or average resampling can empty it. Tier: estimates. Source: rasterio resampling
  documentation.
- **G24. `distance_transform_edt` returns pixels.** Claim: "observations more than 10 km from the
  coast were dropped". Code: `scipy.ndimage.distance_transform_edt(mask)` with no `sampling=`.
  Check: the result is in pixels unless `sampling=` is passed. Tier: sample and estimates. Source:
  SciPy reference, confirmed on scipy 1.13.1.
- **G25. `rowcol` plus a clip moves off-raster points to the edge.** Claim: "observations outside
  the raster are dropped". Code: `rasterio.transform.rowcol()` then `np.clip()` on the indices.
  Check: an outside point gets the edge cell's value, and N looks right. Look for a count of indices
  moved. Tier: sample and estimates. Source: rasterio `rowcol` reference.

### Input products and vintages

- **G26. Boundary vintage.** Claim: "outcomes aggregated to 2010 districts", "constant boundaries",
  a stated unit count. Code: one boundary file (for example `gadm41_XXX_2.shp`) joined to every
  year, or a crosswalk built on one release while the geometry is another, with no version in the
  name or README. Check: recover each file's vintage, compare with the years the text names, count
  polygons against the stated unit count. Tier: sample and estimates. Source: GADM release notes. A
  snapshot surface used as if time-varying (an accessibility raster for one year used for an earlier
  decade) is the same failure.
- **G27. Displaced survey coordinates used as exact points.** Claim: "each household is matched to
  the land cover at its location". Code: a DHS `*GE.shp` or other displaced cluster file fed to a
  point join or point raster read. Check: DHS displaces urban clusters up to 2 km and rural up to 5
  km (1% up to 10 km) within the second administrative level. A point read of a categorical raster
  is the sharpest case. Look for buffer means (urban 1 to 5 km, rural 1 to 10 km, the substitute the
  DHS guidance supports for smooth surfaces), and treat any "within N km" threshold below the
  displacement radius as mostly noise. Tier: estimates and sample.
  Source: DHS Spatial Analysis Reports 7 and 8.
- **G28. Gridded population: wrong product, or count and density confused.** Code: a WorldPop file
  where the text cites another product, `zonal_stats(stats="mean")` on a people-per-pixel grid,
  `stats="sum"` on a people-per-hectare grid, or a count grid resampled by nearest neighbor or
  bilinear. Check: match the path to the cited product, the statistic to the grid type, and use a
  total-preserving resampling. WorldPop's people-per-pixel files are in longitude and latitude
  (WGS84), so a pixel's ground area shrinks with latitude, while its people-per-hectare files are
  in a projected national CRS. Global products undercount rural population substantially ("Global
  Gridded Population Datasets Systematically Underrepresent Rural Population," Nature
  Communications, 2025). Tier: estimates. Source: WorldPop documentation.
- **G29. DMSP night lights as a comparable series across years.** Claim: "lights growth between two
  years" or lights at small units. Code: annual DMSP composites from several satellites summed or
  logged with no intercalibration, no top-code treatment (digital number 63), or a splice to VIIRS.
  Check: look for intercalibration, a treatment of the ceiling and a check of unit size. DMSP blur
  overstates the area of small lit places severely. Tier: estimates. Source: Gibson, Olivia and
  Boe-Gibson (2020), Gibson, Olivia, Boe-Gibson and Li (2021).
- **G30. Gridded weather product choice.** Claim: "rainfall shocks", "weather data are from X".
  Code: the product opened differs from the text, a hand-built station average over a changing set
  of stations, or a reanalysis product where the text says observed weather. Check: products agree
  on long-run means and disagree on annual deviations, the variation a fixed-effects design uses.
  Tier: estimates and inference. Source: Auffhammer, Hsiang, Schlenker and Sobel (2013).

### Spatial inference

- **G31. Conley cutoff in the wrong units.** Claim: "standard errors corrected for spatial
  correlation within 100 km". Code: a cutoff of `100` fed coordinates in meters, feet or degrees
  when the routine assumes another unit, or a defaulted cutoff under a stated distance. Check: trace
  the coordinates to their last projection and read the routine's documentation
  (`fixest::vcov_conley` takes km, `conleyreg` uses great-circle distance on longitude-latitude
  input). A 100 cutoff on meters is a 100 m neighborhood. Tier: inference. Source: fixest and
  conleyreg documentation, and Conley and Kelly, "The Standard Errors of Persistence," Journal of
  International Economics (2025).
- **G32. A copied Conley routine with the Bartlett-kernel error.** Code: a copy of an older
  `ols_spatial_HAC` (Stata) or its R and C++ descendants, dated before the 2017 correction, used
  with a time lag. Check: the defective weight reads `(1 - t_diff[j]) / (cutoff + 1)` where it
  should read `1 - t_diff[j] / (cutoff + 1)`. The direction of the error is not fixed. Tier:
  inference. Source: Christensen, "Correction to Conley Standard Errors".

### Shapefile I/O and manual GIS steps

- **G33. Shapefile field names truncated to 10 characters.** Code: `to_file()` to a `.shp` with
  column names over 10 characters, then a read and a merge on the long name. Check: names are
  truncated, and collisions get serial suffixes, with no error. The finding is a later reference to
  the untruncated name, or two columns sharing their first ten characters. Tier: sample and
  estimates. Source: GDAL shapefile driver documentation.
- **G34. A spatial step that exists only as a GIS console log.** Claim: any spatial operation
  described in words ("urban polygons are matched to districts"). Code: a `.py` of bare
  `processing.run({...})` calls with no imports, a recipe pasted in a comment, a `.model3` or `.qgz`
  with no runner, or a `.shp` the analysis opens that no script writes. Check: list every spatial
  input no script produces. Then decode the recipe's integer codes, which hold the join semantics.
  For QGIS `native:joinattributesbylocation`, `PREDICATE` 0 is intersect, 1 contain, 2 equal, 3
  touch, 4 overlap, 5 are within, 6 cross, and `METHOD` 0 creates one feature per match (a fan-out,
  as in G11), 1 takes the first match only, 2 takes the largest overlap. The codes differ across
  algorithms and versions (`native:selectbylocation` inserts `disjoint` at 2, shifting the rest), so
  decode them against the help for the version that ran (these values verified on QGIS 3.42).
  Confirm each `EXPRESSION` is an expression (a quoted literal evaluates to a constant), and that
  recorded output paths are the files the code opens. Where the recipe defines the sample, the step
  no one can rerun is itself the finding. Tier: package integrity, and sample or estimates when the
  recipe defines the sample or a treatment. Source: QGIS Processing algorithm reference.

## Habits, and checks that did not fire

- **Report a check that did not fire.** A pattern that was checked and did not fire is evidence:
  list it by name in the report ("G1, G3 and G11 checked, no hit: every geometric step runs in one
  projected equal-area CRS"), because silence reads as not checked.
- **Read a hand-rolled substitute directly.** When a package computes its own version of a library
  operation (an `argmin` over a distance matrix, a `rasterize` and `bincount` loop, a `buffer(0)`
  repair), every entry keyed to that library's call reports clean while none of them ran.
- **Confirm a default by running it.** Before a finding uses a library's default, run a
  minimal example on the version in use and record the version and date. Library behavior moves
  across versions, and a default transcribed from memory can be wrong.
- **Look on purpose for two kinds of defect.** Some are visible only against an external fact (a
  published total, a known real-world distance or travel time, a structural limit on N), and some
  present as reassurance (a correlation of 1.000, a coefficient between two alternatives, the best
  cell of a sweep). Internal checks pass both kinds.

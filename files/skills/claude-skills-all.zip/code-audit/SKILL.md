---
name: code-audit
description: >-
  Audits whether a paper, draft section, table note or memo says what its code does: every number,
  specification, fixed effect, clustering level, sample restriction, variable definition, merge and
  robustness claim is traced to a script or log line in Stata, R or Python. Two modes, chosen at the
  start of each run: an original project (a live repository, with targeted reruns and a pass over
  common data mistakes) or a replication package (the user's own before deposit, or a published one
  being reproduced or extended, read without running by default). Returns a severity-ranked list of
  text-versus-code discrepancies, each quoting the sentence and the code line, saying why they
  disagree and which side to change, then what checks out and what the files cannot settle, plus a
  separate revision list. It never edits the paper or the code during the audit. It does not review
  a paper's argument without its code, write a referee report, explain a pipeline for teaching, or
  choose a journal.
---

# code-audit

Given a piece of writing about empirical work and the code that produced it, audit whether the text
says what the code does. Return a severity-ranked list of discrepancies: each one quotes the exact
sentence with its location, cites the code location (`script:line`, or a log line), states in
explicit steps why the two disagree, and proposes a proportionate fix that names which side to
change, the text or the code. Then a short "What checks out" section that certifies only claims
traced end to end, and a list of what the files could not settle. The audit does not give a verdict
on the paper, a score or a recommendation.

The quality bar: a finding that could have been written without a close look at this particular code
and this particular draft does not ship. "Merges should use `isid`" is generic advice. "The text
says the panel is linked one-to-one on household-year (Section 3.2), but `merge m:1 hhid` at
clean_panel.do:141 has no uniqueness check on the master, and the notes report N = 12,410, which an
unchecked fan-out would inflate" is a finding.

## Reference files

- `references/checks.md`: the finding contract, the severity scale, the certification rule, the
  deposit regimes, and the check procedure for every dimension (origin of each number,
  specification, sample, variable definitions, merges, crosswalks and panels, inference,
  robustness, data sources and vintages, package integrity). Read its first part before the first
  audit in a chat. Consult the dimensions during the trace.
- `references/stack_notes.md`: command-to-claim patterns for Stata, R and Python (pandas,
  geopandas, rasters, desktop GIS steps). When a claim is implemented in a given language, run that
  language's patterns for the dimension at hand. The vector and raster spatial entries are separate
  families: a travel-time or market-access package can return zero hits on every vector pattern and
  still be unaudited, so treat a null result there as a fact about scope and run the raster block.
- `references/examples.md`: worked findings from a published replication package, before and
  after, and documented published corrections turned into checks. Use them to calibrate depth and
  register. They are not a list of bugs to hunt for.

Examples are evidence of what a deep finding looks like. They are not an answer key. A trigger
prompts a mechanical check, and only a check that was run and hit produces a finding. Never search a
new package for "the hand-typed figure" or "the many-to-many merge" because an example has one.

## First run: settings (once, before the first audit)

Settings live in `~/.claude/code-audit/settings.md`, outside the skill folder, so a newer version of
the skill keeps them. At the start of every run, read the file and state in one line what it holds
("Settings: reports go to `code_audit/` in the project, and reruns may use Stata 18 SE and
Python 3.11"). If the file does not exist, ask the questions below once, in one question card (the
`AskUserQuestion` tool when available, else a short numbered list), each with a recommendation,
then save the answers as two lines, `reports_folder: <path or "inside the audited folder">` and
`rerun_programs: <list, or none>`.

1. **Reports folder.** "Where should I save each audit report and its revision list?" Options:
   `A code_audit/ folder inside the project or package being audited` (recommended, so the audit
   sits beside what it audits) · `One fixed folder` (the user names it).
2. **Software for reruns.** Detect what is installed before asking: on a Mac,
   `ls -d /Applications/Stata*` and the `stata-mp`, `stata-se` or `stata` binary inside the app
   bundle, elsewhere `which stata-mp stata-se stata`, and in both cases `which Rscript python3` with
   the Python version and whether pandas imports. Then ask: "Which programs may I run when an audit
   allows a targeted rerun?" Options: `The ones found: <list>` (recommended) ·
   `None: every audit stays static`.

Where nothing persists between chats (the Claude apps without a file system), say so, take the
answers for this chat only, give the report and the revision list as downloadable files, and note
that a rerun there is limited to what the app's code sandbox runs (usually Python only).

## Step 0: The mode (every run, first)

Two modes, set at the start of every run. When the request does not say which applies, ask in one
question card with a recommendation inferred from the folder, and state the mode taken in the first
reply.

- **Mode 1, an original project.** A live research repository where the user works: drafts in
  progress, scripts still changing, no README or master file required. Targeted reruns are
  allowed (Step 3). The dominant risk is staleness between the draft and the code, so the audit
  weights it up, and it adds a pass over common data mistakes (the list below Step 3). Recommend it
  when the folder is a working tree with drafts, logs and intermediate files, and no deposit README.
- **Mode 2, a replication package.** Either (a) the user's own package before deposit, or (b) a
  published package being reproduced or extended. Static by default: the audit reads code, logs and
  shipped outputs and runs nothing, unless the user asks for a rerun. Package integrity counts in
  full (README, master script, exhibit-to-script map, archived code). For (b), calibrate severity to
  the deposit regime that produced the package (`references/checks.md`, deposit regimes). In (a),
  offer one targeted rerun when a disputed cell cannot be settled from the files. Recommend Mode 2
  when the folder has a README with an exhibit list, a master script, or a journal or archive DOI.

In either mode, an inspection of the shipped data without running the package (counts, key
uniqueness, missing values, ranges) is allowed, and the report labels it as data inspection.

When a check cannot be settled in the mode in force, say so and leave it uncertified.

## Step 1: The two sides and the scope

1. **Readable text.** Work from a text version with equations, labels, table contents, captions,
   footnotes and cross-reference labels intact. Convert it yourself without asking the user to.
   Prefer LaTeX source over a PDF of the same paper, since exact equations and table cells matter.
   For a PDF, use a paper-to-markdown skill if one is installed, else `pdftotext -layout` or
   PyMuPDF. A scanned PDF with no text layer needs OCR first, and the report says so. In Mode 1 with
   no draft at all, the text side is the project's own record of intent: the notes, the to-do list,
   the README, the header comments and the comments beside each step, and what the user said in the
   request.
2. **The code.** Do-files, R scripts, Python scripts and notebooks, the master file, the README,
   logs, and any shipped outputs and data. Note what is present and what is absent. A package
   missing the code that produced the published tables, or stored only on a personal server, is a
   first-order finding in Mode 2.
3. **Mode-specific setup.**
   - Mode 1: a missing README, no master script and no exhibit table are the normal state of live
     research and are not findings. Note once, in the package map, what a deposit would later need.
     Run `git status` if the folder is a git repository: in-scope scripts with uncommitted changes
     mean the exhibits are not reproducible from any committed state, worth one line. Exhibits often
     get into the draft by hand copy, so compare the numbers in the draft with the numbers in the
     producer's output, value by value. Look for stale copies of shipped tables left in the results
     tree from an earlier vintage, which a rerun can overwrite.
   - Mode 2: identify the deposit regime before scoring any package-level finding (verified before
     acceptance, documented deposit, or none), because it sets how much a "does not reproduce" or
     "missing construction code" finding weighs.
4. **A state file, if the project has one.** A single file holding the live sample counts,
   headline coefficients or canonical data paths is the strongest reference point available: check
   both the draft and the code against it. Verify it before trusting it, and say which of two
   checks passed: its generator script exists and runs, and the generated block is machine-written
   (rerun the generator into a scratch copy and diff it, or check the block against the data it
   summarizes). A marker pair such as `AUTO-BEGIN` and `AUTO-END` is a claim. An unverified state
   file is worse than none, because every later check inherits its errors.

## Step 2: The map, before any claim is traced

Code is larger than one read holds, so build four tables before checking a single claim (method in
`references/checks.md`):

1. **Script inventory.** Every code file, its language and its role: exhibit script, helper or
   program definition, data construction, randomization or inference auxiliary, or orphan.
2. **Run order.** From the master file: which script writes each generated dataset and which later
   script reads it. Note scripts the master never calls and manual steps beyond the documented
   ones. Resolve conditional calls (`if $RI == 1 { do ... }`) before calling a script an orphan.
3. **Exhibit index.** For every table, figure and in-text number, the script that produces it and
   the output file it writes. If the README has its own exhibit-to-script table, treat every row as
   a claim and verify it in both directions: a mapped script that does not write its named output,
   and an exhibit with no row, are both package-integrity findings.
4. **Claims table.** Every checkable claim in the text, with its location, the dimension it belongs
   to and the script it maps to, tagged TRACED, NOT YET TRACED, or NOT STATIC (cannot be
   settled without the data or an external document, with the reason).

Once the claims table exists, claims can be traced in any order, which lets the work run in
parallel and survive context limits.

Scope an uncurated repository before building any of the four. A deposit scopes itself through its
README. A live repository does not, and it can be two or three orders of magnitude larger than the
part the paper uses. Work backward from the draft:

1. List the exhibits the draft renders: every `\input{...}` and `\includegraphics{...}`,
   skipping commented-out lines. That list defines the audit's universe.
2. For each exhibit, search the whole code tree for its output file name. The script that writes it
   is a producer. File names are often assembled from macros and loop variables, so search
   progressively: the full stem, then the stem without generated suffixes (`_ln`, `_no_title`,
   panel and variant tags), then shorter underscore-delimited prefixes. Confirm that a matched
   script writes the file and does more than name it. An exhibit with no producer after every
   search is a lead for dimension 1, the origin of each number.
3. Search for the draft's version or date tag if it has one, to separate live producers from
   superseded ones.
4. Walk one level back from each producer: the datasets it reads and the scripts that write them.
   Stop there unless a specific claim needs more.
5. State the scope and the ratio it implied ("14 of 380 do-files are in scope") and list what was
   left out, so the reader sees the boundary.

## Step 3: The trace, claim by claim

For each claim, run the dimension procedure in `references/checks.md` and the language patterns in
`references/stack_notes.md`, and record one verdict: MATCHES, DISAGREES (with full detail), or
CANNOT VERIFY (with the reason). Trace in this priority order, and weight coverage toward the first
five:

1. **Specification against the estimating command.** Every fixed effect, control, clustering level,
   weight, estimator and sample restriction named in prose or an equation, checked against the
   regression call. Every fixed effect named in the text needs a literal counterpart in the
   command.
2. **Variable definitions and their reference sample.** Every constructed variable (log,
   winsorization, deflator, index, standardization, median split) against its construction code,
   including the sample each transformation is computed on. A z-score taken on the full sample and
   one taken on the estimation sample are different variables.
3. **Merges and duplication.** Every merge for key uniqueness, intended cardinality, unmatched-row
   handling and silent duplication, against the text's description of the link. The signal is a
   missing uniqueness check together with a text claim about uniqueness, match rate or link level.
4. **Crosswalks, panels and spatial links.** Time and geography crosswalks and panel identifiers:
   construction, split or unmatched units, who drops out of a panel and what identifying variation
   remains. Where a spatial link was made by hand in a desktop GIS, the crosswalk is absent from
   the code: find the spatial input that no script produces, then decode the recipe's parameters
   (`references/stack_notes.md`, manual GIS steps).
5. **Inference.** The named estimator or package against what runs, including package defaults
   that contradict the text, and the clustering level implemented against the one stated. Check
   identification first: if the stated fixed effects absorb the treatment, there is no standard
   error question.
6. **Origin of each number.** Every exhibit and quoted number traced to a script and an
   output. The sharpest failure is a number typed by hand into a script or read from a
   hand-maintained file that no script writes.
7. **Sample construction, robustness, data source and vintage, package integrity.** Run these
   across the claims table, and disclose everything not traced.

Where a check needs arithmetic (a t-statistic from a displayed coefficient and standard error, a
sample-flow sum, an implied p-value), do it and show it.

### Targeted reruns

Mode 1 allows a targeted rerun. Mode 2 allows one only when the user asks. Either way:

- Run the smallest thing that settles one disputed claim: one script or one block. Ask before any
  full rebuild. Use only the programs the settings allow.
- Write every output to a scratch folder inside the reports folder. If the project is a git
  repository, keep the scratch folder out of version control, and copy restricted data only where
  its use agreement allows. Leave the project's results and the raw data untouched, and do not save
  a dataset under the name it was read from. If a script writes into the project, run a copy with
  its output paths redirected, and say so.
- Read the log before trusting any number. A Stata batch run exits 0 even when the do-file stopped
  on an error, so search the log for lines starting `r(` and confirm each expected output file was
  written by this run. In a batch log, a line starting `. ` is a command echo, and an echoed
  message from an untaken `else` branch is no evidence that the branch ran: look for its output.
- Report the exact command, the log lines that settle the claim, and the result. A rerun that
  disagrees with the shipped output is a finding in its own right.

### Common data mistakes (Mode 1)

In Mode 1, also run the producers in scope against this list. A hit with a text claim behind it is
a discrepancy. A hit with no claim behind it is a code check: it goes under "Code checks" in the
report and stays out of the discrepancy count.

- **Merges.** The "one" side of a 1:1 or m:1 merge is never proved unique (`isid` in Stata,
  `validate="m:1"` in pandas, `relationship=` in dplyr). A key that is only part of the true
  identifier (`id` where the unit is `id` by year). Unmatched rows dropped with no tabulation and
  no asserted match rate (`keep if _merge == 3` with no `tab _merge`). A guard on a `_merge`
  category that the merge's own `keep()` already discarded, so it can never fire. A same-named
  variable on both sides: Stata silently keeps the master's copy and pandas adds `_x` and `_y`
  suffixes. A merge after a `collapse`, where the collapsed side is unique by construction and the
  fine side is never checked.
- **Keys and IDs.** Keys of different widths or types on the two sides (a code stored as text with
  leading zeros on one side and as a number on the other): the merge matches nothing, raises
  nothing, and reads like genuine non-overlap. Print the length and a few values of the key on both
  sides first, and pad the short key without truncating the long one. Long numeric IDs stored as
  `float` in Stata (exact only up to `16777216`) or upcast to float in pandas. A coarser key derived
  by arithmetic from a nested code (`kid = vid // 1000`) with a divisor nobody checked. Geographic
  codes reused across vintages, so a match is exact on the code and wrong on the place. In Stata,
  `set varabbrev off` at the top of the file, since `cap drop x` otherwise deletes `x_pc` when `x`
  does not exist.
- **Missing values.** A blank filled with zero (or a mean or median) where nobody can say what zero
  means for that variable: decide for each variable whether a blank means zero or unknown, and fill
  only the first kind. Sentinel codes (`-99`, `999`, `.a`) left in as real values. In Stata, missing
  counts as larger than any number, so `keep if x > 100` keeps every missing `x` unless the
  condition adds `& x < .`. In pandas, `read_csv` turns `"NA"` and `"None"` into missing by default
  and leaves `-99` as data unless told otherwise.
- **Collapse and aggregation.** `collapse (sum)` in Stata and `groupby().sum()` in pandas return 0
  for a group whose every value is missing, which then looks like a measured zero: keep a count of
  non-missing values in the same collapse and set the sum to missing where it is 0 (Stata), or pass
  `min_count=1` (pandas). `(mean)` silently changes its denominator to the non-missing rows. A
  `groupby` drops rows whose key is missing (`dropna=True` by default). A collapse grouped on part
  of the key blends distinct records into one number. A winsorization at a fine level is undone when
  a coarse level is recomputed as a ratio of sums.
- **Sample restrictions.** Any drop in N that the text does not report: a filter, a merge, a
  deduplication, a missing coordinate. Print how many rows every filter and deduplication removes.
  A `duplicates drop` keyed on value columns, where the key belongs on the unit's own identifier.
  Columns of one table estimated on samples that drift because each regression drops its own
  missing values (fix one sample with a saved indicator and reuse it).
- **Clustering.** A clustering level named in the text with no matching option in the command, or
  with a different variable (`reghdfe` with no `vce()` reports conventional standard errors).
  `robust` where the text says clustered. A clustering variable finer than the stated level.
- **Weights.** `aweight` where the text describes sampling weights (`pweight`): identical
  coefficients, wrong standard errors. Integer expansion weights of census microdata applied as
  arithmetic, where `[fweight=]` belongs. A weight that the text calls inverse variance coded as the
  standard deviation itself.

## Step 4: Each finding (the contract)

Every finding meets the contract in `references/checks.md`. In brief:

- **Title**: the failure and its location ("Clustering level in Table 4 does not match the text").
- **Both ends**: the verbatim text claim with its location (equation, table and column, footnote,
  section) and the code location as `script:line`. A code-text finding is a relation between two
  places, so cite both. Quote enough of the passage to show the claim is not qualified elsewhere in
  the same sentence, footnote or note block.
- **Argument**: two to four explicit steps from the quoted text and the quoted code to the exact
  point of disagreement. Every number is quoted from the paper or the output, or derived in front
  of the reader.
- **Every site**: when the same mismatch recurs (a control set overstated in several table notes,
  one merge pattern in several scripts), cite every site in one finding.
- **Which side to fix**: name the text or the code, and offer the benign explanation when one
  exists (a stale comment, a note that compresses a two-stage construction). Voice a
  code-versus-writeup uncertainty as a verification request. Never impute intent.
- **Fix**: minimal, concrete and proportionate, keyed to whichever explanation turns out true.
  Supply the corrected note, varlist or option when that is cheap.
- **Length tracks depth**: two sentences for a pure number mismatch, up to about 250 words for a
  merge or specification finding with a mechanism chain.

Write the confirmation half as well: where a claim was traced end to end and the code matches the
text, say so in "What checks out". A verified match is a finding, and it makes the discrepancies
credible.

## Step 5: Severity

Decide severity before choosing words, with three questions:

1. Does the discrepancy break the paper's central claim as written (a specification the code does
   not run, a merge that inflates the estimation sample, a headline number no script produces)?
2. Can it be corrected within one revision, with the code and data as they stand?
3. Is the uncertainty about the code, or only about the writeup (a table note that under-describes
   a control set the code gets right)?

Breaks the headline and cannot be corrected: [Blocking]. Breaks the headline and can be corrected:
[Major]. Local, or writeup only: [Minor] or a verification request. Match the register inside the
finding to the tag: a stale comment and a corrupted merge must not arrive in the same voice. When a
static read cannot decide between a bad branch (blocking) and a benign one (a one-word text fix),
default to [Major] and frame it as a verification request.

## Step 6: The gate before the report

Run every finding and every line of "What checks out" through these tests:

1. **Transplant test.** Delete the specifics (the `script:line`, the varlist, the coefficient, the
   N). If a sensible remark remains, the finding is generic: rewrite it around the specifics or
   drop it.
2. **Number origins.** Every number and code line comes from this code or this paper, or from a
   derivation shown to the reader.
3. **Trigger discipline.** The check was run against the code, and the finding reports its result.
   A bare package default is a finding only when a text claim contradicts it.
4. **One home.** Each discrepancy sits under one dimension, with a cross-reference at each other
   site.
5. **Cost and benefit.** The requested change can move a conclusion or correct the record, and the
   request asks for the cheapest sufficient version.
6. **Disclosure sweep.** Before any finding that rests on something being undisclosed, read past
   the quote: the rest of the sentence, its footnote, the rest of the note block, the next
   paragraph, and the appendix section on the same object. Quote the disclosure if it exists and
   drop or refile the finding. If it does not exist, say that the sweep was done.
7. **Certification parity.** Anything in "What checks out" was traced end to end. Anything that a
   static read cannot settle (a construction that ships only as cleaned data, a value in a file not
   on hand) is scoped as such and left out of the certification. A false endorsement costs more
   than a miss, because it tells the author the code is fine.

Then rank: [Blocking], then [Major], then [Minor], and within a tier by closeness to the central
claim. Honest coverage of the priority dimensions beats a long list. If a dimension is clean, say so
once.

Keep three kinds of item apart, so the hard findings are not diluted:

- A **discrepancy** is a genuine contradiction: the text says one thing and the code does another.
  It goes in the ranked list.
- A **disclosure note** is real and weaker: the code is consistent with every stated claim and
  under-documents something, or the question cannot be settled statically (a merge with no
  reported match rate, a control set the note compresses).
- A **code check** has no text claim behind it at all: a code-quality or robustness concern (a macro
  that expands to nothing, an unguarded default, a hit on the Mode 1 data-mistakes list).

Before filing an item as a discrepancy, name the sibling it breaks symmetry with: the other column,
merge, transformation or passage that the code and the paper agree about. Internal asymmetry (one
column, merge or transformation that differs from its siblings while the text and every sibling
agree) is the workhorse pattern of real discrepancies. With no sibling, the item is a disclosure
note or a code check, whatever its severity. Spatial code is where this slips most, since irregular
geometry produces many oddities with no text claim behind them.

The falsified-sentence gate runs on every candidate discrepancy before it is written: quote the one
sentence the code makes false, verbatim, and complete this line about it: "this sentence is untrue
as written, because the code does X." If the audit cannot quote one, there is no discrepancy,
however real the gap between text and code. Three common failures:

- The paper never made the claim. The code does something surprising and the draft is silent about
  it. That is a disclosure note.
- The paper made a weaker claim than the one tested. The text says "controls for baseline
  characteristics" and the audit checked it against a specific list it supplied itself. The
  sentence is not false. The paraphrase is.
- The sentence is true elsewhere in the draft. If another passage states the code's behavior
  correctly, the finding is an inconsistency between two passages, filed and worded that way with
  both locations.

Quote the falsified sentence inside the finding, so the reader can check that the gate held. In
practice the most common error is a real text-versus-code difference filed as a contradiction
without checking that any sentence was falsified.

One kind of sentence goes in the ranked list without being falsified: a claim that evidence exists
("the results are robust to X", "we also estimate Y") when the code does not include a script or an
output for it. The sentence promises evidence the files do not hold, so it is filed as an existence
gap (`references/checks.md`, 6.1), usually [Minor], with the two-sided fix: narrow the sentence or
add the exercise. List it under "Not Verified" as well, with the reason (no code or output for it).

## Step 7: The revision list (the audit never edits)

The audit does not touch the paper or the code, and that includes the obvious one-word fixes and a
single stale number. A text-versus-code audit sees one end of the paper at a time. Each finding says
"this sentence does not describe the code", and the local fix is to rewrite the sentence, but the
sentence sits inside an argument. Rewriting thirty of them one by one, each locally correct, can
move the paper's framing, weaken a claim the introduction and abstract still make, or leave two
sections describing one object differently. And some text fixes are the wrong fix: when making the
sentence true would damage the argument, the code may need to change, and a text edit would bury the
signal the author needed.

So the audit writes a second file, the revision list, for a later pass that reads the whole draft.
Save it beside the audit report in the reports folder, named
`YYYY_MM_DD_code_audit_<slug>_revisions.md`, and name it in the report's first line. It holds:

1. **A standing instruction to read the draft first**, end to end, and to keep the central claim,
   the pitch and the abstract in view while judging each edit.
2. **One entry per proposed change**: the exact location, the current wording quoted verbatim, the
   proposed replacement written out in full, a one-line reason keyed to the finding, and the
   `script:line` the correction comes from. Where another passage of the same paper already states
   the fact correctly, propose reusing its wording, which keeps the paper's own voice.
3. **An argument-risk tag on every entry**:
   - **Safe.** Purely local: a stale source name, a control the equation omits that the table
     shows, a mislabeled figure note.
   - **Check the argument.** Locally correct, but the claim it supports is repeated in the
     abstract, the introduction or the conclusion. List those sites, so they are updated together.
   - **Decide first: text or code.** Making the sentence true would weaken or change a claim the
     paper makes. Do not propose prose here. State the choice (accept the weaker claim, or change
     the code and rerun) and what a rerun would cost. Order these entries first.
4. **Grouping by object.** Entries on the same variable, table or section sit together: a treatment
   definition that appears in an equation, two prose glosses and a figure note is one task with
   four sites.
5. **A "do not change" list**: what the audit checked and found correct, so a reviser does not
   "fix" it in passing.

For a published package that the user is reproducing or extending (Mode 2b), there is no draft to
revise: skip this file, and the "which side to fix" line in each finding is the proposal to the
original authors.

If the user later asks for fixes to be applied, work one object group at a time, with all its
sites together. First read the whole draft. Show the current and proposed wording of every site
side by side, apply only what the user approves, update in the same pass the repeated sites that a
"Check the argument" entry lists, and keep every item on the "do not change" list as it is. Never
apply a "Decide first" entry as a text edit until the user has chosen text or code. After a code
change, rerun the affected producer under the rerun rules and recheck every text entry that quotes
its numbers. Mark each applied entry in the revision list.

## Output format

Save the report as `YYYY_MM_DD_code_audit_<slug>.md` in the reports folder, and give the user its
path. In the reply, lead with the counts by tier and the top findings.

```
# Code-Text Audit: <paper or project short name>

<One line: what was audited (draft version, code source or date), the mode (1, 2a or 2b), the
deposit regime for 2b, whether anything was run, and where the revision list is.>

## Package Map
<Script inventory size, run order, how the exhibit index was verified, the scope and its ratio,
what could not be traced and why.>

## Overall Themes            <- only when a synthesis across findings is earned
<Three to six located facts assembled into one structural judgment.>

## Discrepancies
1. [Blocking] <failure and location>
   <Finding per the contract: text claim (location), code (script:line), mechanism, fix.>
2. [Major] ...
N. [Minor] ...

## Disclosure Notes           <- omit if none
<Disclosure gaps and verification requests, each labeled as such.>

## Code Checks                <- mostly Mode 1; omit if none
<Hits with no text claim behind them, each with script:line, what goes wrong, and the fix.>

## What Checks Out
<The specifications, reference samples, merges and exhibit sources traced end to end and found
to match, each at the tier it earned.>

## Not Verified
<Each claim the audit could not settle, and why (data not shipped, value in a file not on hand,
construction earlier than the shipped data, no rerun allowed).>

## Reruns                     <- only if something was run
<Each command, the log lines that settle the claim, and the result.>
```

A short request (one section against one script) can take a compact form: a numbered table with
the sentence and its line, the code or log line, the verdict (MATCHES, DISAGREES, CANNOT VERIFY),
the side to change, and a one-line fix, followed by "What checks out" and "Not verified". The
contract, the severity tags and the gate still apply.

## Conduct

- **Courtesy.** The audit exists to protect the paper before a referee or a data editor finds the
  same thing. A code-versus-writeup uncertainty is phrased as a verification request, and a benign
  explanation is offered whenever one exists.
- **Names for the level of treatment.** Name the level the code assigns (treated districts, treated
  schools, treated individuals), so the finding and the code use the same unit.
- **What a static read can prove.** State it precisely: "the note is not enough to certify the
  controls as stated", "the code is not enough to verify a unique-key claim", "provable from the
  printed page".
- **Scope.** This skill audits text against code. For a rigor review of a paper's argument with no
  code, a referee report with a recommendation, a teaching walkthrough of a pipeline, or a journal
  choice, use a skill or a request made for that job. If the user has skills for Stata, R, Python or
  LaTeX work, load them before any rerun or edit they cover.

# The citation-key convention

This file applies when the settings choose `author_year_shorthand`, the convention the first-run
question recommends. Earlier forms of it were tried and dropped: a capitalized `_EtAl`, full-word
camelCase descriptions, no marker for three or more authors, and the year fused to the surname.

```
<AuthorBlock>_<Year>_<shorthand>[_<TAG>]
```

The underscore immediately before the four-digit year is always the year separator. Every
underscore inside the author block is an author boundary. So a key can be split by a machine, and it
states its own author count.

## 1. The author block

| Case | Form | Example |
|------------------------|----------------------------------------|----------------------------------------------|
| One author | Surname | `Rodrik_2016_premat_deindust_JEG` |
| One institution | Name concatenated, or its acronym | `WorldBank_2013_peri_urban_bound_Report` |
| Exactly two authors | Both surnames, underscore between | `Imbert_Papp_2015_emp_guar_india_AEJ` |
| Two institutions | Both names, underscore between | `OECD_EC_2020_cities_world_Report` |
| Three or more, one shown | First surname + `_etal` | `Gollin_etal_2016_urban_wo_indus_JEG` |
| Three or more, several shown | Surnames + `_etal` | `Surname1_Surname2_etal_2024_shorthand` |

A reader can always tell the author count:

- a bare surname is a solo author
- `X_Y` is exactly two
- `_etal` means more authors than the key shows

Institutional authors follow the same count rules as people: one organization gives its name, two
give both with an underscore between, three or more give the first plus `_etal`. Where an
organization has no established acronym, coin a short recognizable one (European Commission gives
`EC`).

Never derive an institution's key fragment from the last word of its name. The surname rule for
people ("Smith, John" gives `Smith`) turns `{{World Bank}}` into `Bank` and
`{{Publications Office of the European Union}}` into `Union`. A double-braced author is one
organization: take the whole name and concatenate it or use its acronym (`WorldBank`, `EU`). One
real rename pass produced four keys named after the wrong half of an institution before the
entries were checked again.

A publisher is not an author. Check for named authors before keying anything to an institution.
Scraped agency records often put the publishing body in the `author` field and bury the real
authors. In one case, a Degree of Urbanisation report had
`author = {{Publications Office of the European Union}}`, the EU's printer, while the actual record
listed a corporate author and four personal authors, two of them academic economists. Keying it to
`EU` would have credited an academic paper to a printing office, and the `author` field itself
needed repair. Before accepting an institutional author, open the source record and look for a
personal-authors or corporate-author field. If named authors exist, the entry takes a normal
personal-author key, and the institution moves to `institution` or `publisher`.

Acronym casing in the author block: a pure acronym keeps its capitals (`OECD`, `UNDESA`). An
organization whose name is a proper name keeps its own official styling (`UN-Habitat` gives
`UNHabitat`). This casing rule covers the whole key, named entities in the shorthand included
(section 2).

Compound and double surnames are written without an internal underscore, since one would read as
two people. Keep the whole surname, concatenated:

```
Valencia Caicedo    ValenciaCaicedo      van Duijne         VanDuijne
Sanchez-Alonso      SanchezAlonso        De Ferranti        DeFerranti
Figueiredo Walter   FigueiredoWalter     von Ehrlich        VonEhrlich
Baum-Snow           BaumSnow             Goldsmith-Pinkham  GoldsmithPinkham
```

Particles (`van`, `von`, `de`, `De`) stay attached to the surname.

Diacritics are stripped in the key and kept in the entry. A key has to be plain ASCII to be safe in
BibTeX and in every citing document, so `Sánchez-Alonso` keys as `SanchezAlonso`, `Añón` as `Anon`,
`Södersten` as `Sodersten`. The `author` field keeps the accented spelling. Stripping is a safety
measure for the key and leaves the person's name as written.

How many surnames to show. For a new key: one author gives the surname, two give both, three or
more give the first plus `_etal`. For an existing key: keep the surnames already there. A user may
key a multi-author paper to the coauthor they remember presenting it, and that is deliberate. Fix
the form and keep the name set.

`_etal` is the only form of et al. Legacy keys with `_EtAl`, `_et_al_`, or `etal` fused to the year
are nonconforming.

## 2. The shorthand

An underscore, then a description of two to four words on what the paper is about: lowercase,
underscore-separated, recognizably abbreviated. Never camelCase, and never a full word where an
abbreviation is standard. The one exception is a named entity (an acronym, a dataset, a place
shorthand), which keeps its own capitals (see the casing rule below).

`premat_deindust`, `agglom_econ`, `shift_share`, `rural_econ_struct`, `climate_urban_africa`

### Abbreviation vocabulary (a starting list)

| Full word | Abbrev | | Full word | Abbrev | | Full word | Abbrev |
|-------------------|------------|---|-------------------|------------|---|-------------------|------------|
| activities | `activ` | | endowments | `endow` | | political | `polit` |
| agglomeration | `agglom` | | ethnographic | `ethno` | | population | `pop` |
| biodiversity | `biodiv` | | geography | `geog` | | pre-colonial | `precol` |
| boundaries | `bound` | | guarantee | `guar` | | premature | `premat` |
| concentration | `concent` | | harmonized | `harmon` | | sample | `samp` |
| congestion | `congest` | | importance | `import` | | selection | `sel` |
| consumption | `consum` | | industrial | `ind` | | services | `serv` |
| definition | `defn` | | industrialization | `indus` | | specialization | `special` |
| deindustrialization | `deindust` | | inequality | `ineq` | | structure, structural | `struct` |
| determinants | `determ` | | institutions | `instns` | | subnational | `subnatl` |
| development | `dev` | | manufacturing | `manuf` | | transport | `transp` |
| displacement | `displ` | | migration | `migr`, `mig` | | unemployment | `unemp` |
| distribution | `distrib` | | mobility | `mob` | | unlimited | `unlim` |
| economy, economic | `econ` | | moving | `mov` | | without | `wo` |
| employment | `emp` | | not-so | `notso` | | | |
| endogenous | `endog` | | policy | `pol` | | | |

Add the user's own abbreviations under `answers:` in the settings as they come up, so later runs
reuse them.

### Casing

One rule covers the whole key: acronyms in capitals, coined names (`DegUrban`, `LatAm`) in Title
case, ordinary descriptive words lowercase, and full place names lowercase too. The descriptive
words stay lowercase (`premat_deindust`, `agglom_econ`, never `Premat_Deindust`), and a named
entity inside the shorthand keeps its own capitals:

| Capitals (initialism) | Title case (coined name) |
|----------------------------------------------|----------------------------------------------|
| `GHS`, `GHSL`, `NTL`, `SEZ`, `LAC`, `WUP`, `SHRUG`, `HYDE32` | `DegUrban`, `Polity5`, `LatAm` |

This is the one place the convention allows capitals inside the shorthand, because a lowercased
acronym is unreadable (`ghs`, `ntl`). It does not license Title case for descriptive words, which
were tried as camelCase and dropped. A two-letter or three-letter country code that could collide
with an abbreviation in the table (`ind` for industrial against a code for India) is written in
capitals or spelled out, whichever reads at a glance. Save the choice under `answers:`.

### Words never abbreviated

Already short, proper nouns, or the word the paper is known by: access, atlas, built, central,
change, cities, climate, factor, fortune, grid, growth, hidden, history, labor, mass, middle,
mining, place, push, roads, rural, shadow, share, shift, spatial, trade, travel, urban, world,
agriculture, colonial, conflict, diffusion, giants, internal, linkages, metropolis, missing,
networks, nonfarm, nontradables, patterns, reversal, ruggedness, strategy, and all place names
(africa, chile, colombia, india, mexico), which stay lowercase.

### A word missing from the table

Strip the derivational suffix (`-ation`, `-ment`, `-ity`, `-ies`, `-ance`, `-ous`, `-ing`, `-al`,
`-ure`), then keep the shortest prefix that ends on a consonant and still reads unambiguously. That
gives 3 to 6 characters. Go longer only when a shorter cut would be ambiguous (`special`, because
`spec` reads as "specification", and `distrib`, because `dist` reads as "distance"). Leave whole a
word of six letters or fewer, a proper noun, and the distinctive word the paper is known by.

## 3. The tag

The tag applies only when the settings turn tags on. It sits at the end and shows where the
work stands.

Journal tags: the journals in the settings' `tag_journals`, by default the top five, `AER` `QJE`
`JPE` `ECTA` `REStud`, plus the field journals the user named. Keep the list short. A tag singles
out a small set of journals, and tagging a second strong journal in a field that already has one
makes every tag mean less.

Tag spellings are fixed, and the casing rule of section 2 does not apply to them. Common economics
spellings, for any journal the user adds:

| Tag | Journal | | Tag | Journal |
|----------|----------------------------------------|---|----------|----------------------------------------|
| `AER` | American Economic Review | | `JEL` | Journal of Economic Literature |
| `QJE` | Quarterly Journal of Economics | | `JEP` | Journal of Economic Perspectives |
| `JPE` | Journal of Political Economy | | `ARE` | Annual Review of Economics |
| `ECTA` | Econometrica | | `JUE` | Journal of Urban Economics |
| `REStud` | Review of Economic Studies | | `JDE` | Journal of Development Economics |
| `REStat` | Review of Economics and Statistics | | `JEG` | Journal of Economic Growth |
| `JEEA` | Journal of the European Economic Association | | `JPubE` | Journal of Public Economics |
| `EJ` | Economic Journal | | `JHR` | Journal of Human Resources |
| `AEJ` | any American Economic Journal | | `JEH` | Journal of Economic History |

Write `REStud`, `REStat` and `JPubE` exactly as shown, and never change them to all capitals. Every
American Economic Journal takes `AEJ`, without the sub-journal.

Working papers: `NBER` and `IZA` keep their series name, so a reader sees that the work is not
peer reviewed. Every other working paper takes the plain tag `WP`, with no source. `WP` stands for a
working paper in every key.

`RePEc`, for a working paper whose only findable home is RePEc. It replaces `WP`, the way `NBER` and
`IZA` do, and stacks with `JMP` (`_RePEc_JMP`). It tells a reader that the work exists but has a
thin record, so quote it with care and check it again before submission. Apply it only after a
second-source pass has come back empty everywhere else (Crossref, OpenAlex, the publisher, the
author's page) and positive on RePEc. A `url` field pointing at ideas.repec.org is no reason to tag
it, since many RePEc-listed papers are also published. If a published version turns up later, the
journal tag replaces `RePEc`.

Reports: institutional, policy and agency reports take `_Report` (World Bank, OECD, UN agencies,
regional development banks and similar). A report is not a working paper, so it never takes `WP`.

Datasets take `_Data`, capitalized to match `_Report` and so it never reads as a lowercase shorthand
word. This covers gridded data products, dataset user manuals and data packages, whatever the entry
type. A report whose purpose is to introduce a dataset takes `_Data`: the test is the document's
purpose, regardless of who published it or how it is typed. A numbered agency report titled "Data
Package" that documents how a dataset was built takes `_Data`. A report that analyzes a topic and
happens to use data keeps `_Report`.

Job market papers take `JMP`, which stacks with a series tag: `_NBER_JMP`, `_IZA_JMP`, `_WP_JMP`.
A job market paper is usually not detectable from the bib fields. If neither a `note` nor the
author's page says so, ask the user.

Books, chapters, and journals outside `tag_journals` do not take a tag.

The tag describes current status. When a working paper is later published, the entry is rewritten
and the journal tag (or no tag) replaces the working-paper tag.

Conditionally accepted papers count as accepted and say so. Put the journal in the `journal` field
with `(conditionally accepted)` after it, and give the entry the journal's tag:

```
journal = {Econometrica (conditionally accepted)},     key: ..._ECTA
```

The parenthetical stops the reference from claiming the work is already published, while the
journal name and tag record that it is effectively accepted. Use `@article`, so the journal renders,
and drop any older "revise and resubmit" note. A revise-and-resubmit is still a working paper: it
keeps `WP`, with the status in a `note`. Once volume, issue and pages exist, remove the
parenthetical and treat it as a normal article.

Legacy tags. Tags from an older scheme are mapped once, by rule:

| Legacy | Becomes | Why |
|----------------------|------------|------------------------------------------------------------------|
| `_jep`, `_wp` | `JEP`, `WP` | case corrected to the fixed spelling |
| `_Ecma` | `ECTA` | Econometrica |
| `_AnnRevEcon` | `ARE` | Annual Review of Economics |
| a series other than NBER or IZA | `WP` | only NBER and IZA keep a series name |
| a handbook tag | drop | chapters do not take a tag |
| a journal outside `tag_journals` | drop | outside the list |
| `_RES` | ask | Review of Economic Studies (`REStud`) or Review of Economics and Statistics (`REStat`): resolve per entry from the `journal` field |

## 4. Stale years

If an old key's year is the working-paper year and the entry's `year` field is the published year,
use the field's year in the new key and report the mismatch as a KEY MISMATCH. It is often a real
integrity problem: the entry may have been updated while the key kept the old year, or the key may
name someone who is not the first author at all. Typical cases, with placeholder names:

```
Smith2010          entry year 2011 (working-paper year in the key)
Lee2017abc         first author in the entry is someone else
```

## 5. Worked examples

```
Rodrik_2016_premat_deindust_JEG                  1 author, journal on the tag list
Imbert_Papp_2015_emp_guar_india_AEJ              2 authors, any AEJ is just AEJ
Ades_Glaeser_1995_urban_giants_QJE               2 authors, top five
Dell_2010_mining_mita_ECTA                       1 author, top five
Gollin_etal_2016_urban_wo_indus_JEG              3 authors, journal on the tag list
ValenciaCaicedo_2019_missions_QJE                compound surname, solo author
Morten_2019_temp_mig_india_JPE                   published version (the WP key took _NBER)
WorldBank_2013_peri_urban_bound_Report           institutional author, report
OECD_EC_2020_cities_world_Report                 two institutions, agency report
UNHabitat_2012_LAC_cities_Report                 organization keeps its own styling, LAC in capitals
Schiavina_etal_2023_GHS_pop_Data                 3 or more authors, dataset, GHS is an initialism
Surname_2024_shorthand_NBER                      NBER working paper (placeholder)
Surname_2024_shorthand_WP                        any other working paper (placeholder)
Surname1_Surname2_etal_2024_shorthand            4 authors, 2 shown in an existing key (placeholder)
```

The tags here assume `tag_journals` includes `JEG` and the top five. With tags off, drop the last
segment of every key above that has one.

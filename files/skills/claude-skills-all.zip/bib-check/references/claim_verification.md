# Claim-level citation verification

Metadata checks make entries true and keys legible. Both skip the citing sentence, so neither
can catch a real paper cited for a claim that paper does not make. References have to be valid in
two senses: the paper exists, and it says what the sentence citing it says.

This file is the method behind the CLAIM MISMATCH status in `SKILL.md` Step 3. Step 4 there is the
operational summary. The depth, the worked examples and the report template are here.

The yield to expect: a first run at scale on one paper's introduction checked 12 claim-citation
pairs over 18 cited works, with three agents checking abstracts and open-access full texts in
parallel. It found 8 of the 12 pairs imperfect, two of them hard errors, in a library where every
entry had passed full metadata verification earlier the same day. Per hour spent, it is the most
productive check in the skill.

## 1. The four verdicts

One verdict per claim-citation pair. Every verdict comes with a quoted sentence from the source's
abstract or body. A verdict without a quote is not a finding.

- SUPPORTED. The paper clearly makes or directly implies the claim. Quote the sentence that does.
- PARTIAL. Directionally right, but the prose overstates, understates, drops a qualifier the claim
  needs, or shifts the setting or scope. The most common verdict and the most useful, because it
  covers the citations that are partly right. Give the quote and a one-line rewording
  the source would support.
- NOT SUPPORTED. The paper does not make the claim, or contradicts it. Give the quote that shows the
  absence or the contradiction, and a one-line rewording, which may be "cite a different paper" with
  that paper named.
- UNVERIFIABLE. Not enough was accessible to judge. State exactly what was seen and what was not:
  abstract only, paywalled body, no repository copy. Never promote it to a verdict, and never let it
  read as NOT SUPPORTED. Missing access says nothing about support, in the same way that a missing
  database record says nothing about fabrication (`SKILL.md` Step 3, statuses 1 and 2).

PARTIAL against NOT SUPPORTED: if the source points the same way and the gap is one of degree or
scope, it is PARTIAL. If the source is silent on the claim or runs against it, it is NOT SUPPORTED.
When genuinely unsure, give the lower verdict with an honest quote.

How pair verdicts set the entry's status: a PARTIAL or NOT SUPPORTED pair makes the entry a CLAIM
MISMATCH. An UNVERIFIABLE pair leaves the entry at "metadata verified, claim not checked", and the
report asks the user for the PDF.

## 2. The six failure modes, worked

Each pattern generalizes. The examples show how each one looks in practice. Except for the second,
which is a well-known case from urban economics, their names and numbers are invented.

1. Framing sentence read as a result. An abstract often opens on the literature's hypothesis
   ("growth in large cities may drain activity from the places around them") and then reports
   estimates that show the reverse, with nearby places gaining. A citation that quotes the opening
   clause as the finding gets the paper backwards. The tell: the first half of an abstract is often
   framing drawn from earlier work, so read on to the estimates before attributing a result.

2. Mechanism attributed to the wrong paper in a family. A sentence cites Krugman (1991, Journal of
   Political Economy) for the agglomeration shadow, with new centers emerging beyond some distance
   from an existing city. Krugman (1991) is a two-region core-periphery model: it has no distance
   continuum, and its periphery is agricultural. The mechanism of new cities forming at a distance
   from existing ones as population grows belongs to Fujita, Krugman and Mori (1999, European
   Economic Review). The tell: a canonical cite for a specific mechanism is the most dangerous kind,
   because nobody checks it again. Confirm that the named mechanism is in the named paper, beyond
   being somewhere in that author's research program.

3. Direction reversal. Author A (2018) finds that cheaper broadband moved call-center jobs out of
   small towns and into large cities. A sentence saying that, "in the spirit of Author A (2018),
   small towns gained remote-service jobs from cheaper communication" implies a parallel that runs
   backwards. The literal sentence can be true while the analogy it draws is reversed, so
   metadata verification passes. The tell: for any citation asserting a parallel or an analogy
   ("in the spirit of", "similar to", "the mirror image of"), check that the two mechanisms point
   the same way.

4. Dropped scope qualifier. Author B (2020) finds that small loans raised business investment among
   households that already ran a business, with no effect on the others. Cited for "small loans
   raise business investment", the sentence drops the subsample behind the result. The same
   happens with a season (a lean-season finding cited for the whole year), a region, or a period.
   The tell: a finding conditioned on a subsample cannot be cited as if it held always, so recover
   the qualifier the prose dropped, and check whether the paper's other half runs against the claim.

5. Compound claim split across a cluster. A sentence credits three papers with showing both that a
   cash transfer raised household spending and that the gain spilled over to neighbors who received
   nothing. One paper shows the spending effect and has no data on neighbors at all, and the other
   two show neither cleanly. The fix splits the sentence and adds a paper that does show the
   spillover. The tell: check each member of a cluster against each half of a compound claim, one
   pair at a time.

6. Right number, wrong mechanism. A sentence quotes a paper's 30% pass-through exactly, but the
   paper attributes it to tariff changes, while the sentence attaches it to exchange-rate
   movements. The tell: matching the magnitude is not matching the sentence, so verify the
   mechanism the number is attached to as well as the number.

### Two recurring traps

- Working-paper magnitudes that the published version revised. When a number is quoted from a work
  that exists as a working paper and as a published article, confirm that the number is the
  published one. A revision can be large: three to five times in one case. The entry can
  correctly be the published version while the prose still quotes the working paper's number. This
  is the claim-level companion to PUBLISHED SINCE: there the fix is the entry, here it is the number
  in the sentence.
- A direction that is easy to state backwards. Proximity gradients are the usual case: whether a
  kind of employment rises or falls with distance to a town is something the intuitive sentence
  often gets wrong. Check every proximity-gradient claim against the sign in the paper.

## 3. Method

- Pairs first. One row per (claim sentence, cited work). A five-cite sentence is five pairs.
- Fan out, about 4 pairs per agent, agents in parallel. Each agent gets the claim verbatim, the full
  citation, and the specific suspicion to test. Naming the suspicion ("check the direction", "check
  the number", "is this lean-season only") sharply raises the hit rate.
- Tell agents that existence is already established and outside the question, or they check
  metadata again and drift back toward "does this exist".
- Require the quote. No quote, no finding: an agent that cannot quote will hedge.
- Prioritize. Do not run this on every citation. Target, in order: (i) claims with a number, (ii)
  claims asserting a direction or sign, (iii) newly added citations, (iv) citations to canonical or
  famous works, the least checked and most often misattributed, (v) clusters of three or more cites
  on one sentence.
- Sources, in order of strength: the full text (a PDF the user supplies, an open-access copy), the
  published abstract (Crossref or OpenAlex often hold it), the working-paper page, a publisher page
  (often closed to automated requests). Say which source each verdict used.

## 4. The report format

### The fixes table

The review surface in the chat is one markdown table of the imperfect pairs, built so the text
columns wrap evenly and the user can reply by row number:

| # | Cite · line | V | Current wording | Problem | Suggested rewording |
|---|---------------------|----|------------------------|--------------------------|--------------------------|

- `#` first: a running number opens every row, so the user can answer by reference ("2 and 5 yes,
  7 later").
- Cite · line: author surnames and year, a middle dot, then the location (`sec2:20`, or a
  paragraph tag such as `intro (4)`). Leave out the citation key, which is long and stops the text
  columns from wrapping evenly.
- V: a compact verdict code: `P` partial, `P*` partial with the supported half noted, `NS` not
  supported, `U` unverifiable, `S*` supported with a nuance or an optional enrichment.
- Current wording quotes the draft briefly, Problem states the gap in one breath (what the source
  says or lacks), and Suggested rewording gives the fix.
- Status markers lead the rewording cell once decisions exist: ✅ applied, ⏳ pending or deferred.
  While the pass is still a proposal, use none.
- Bold the key words in each cell (the number, the comparison, the changed phrase), since the table
  is for scanning.
- Keep verbatim source quotes out of the table. They go in the expanded blocks below it.
- Leave SUPPORTED rows out of the table and summarize them in one line above it.

Example row (invented):

```
| 1 | Author C '16 · sec2:20 | P | "raised enrollment by **more than 20%**" | paper reports "**about 15%**", with 20% as the upper bound of the interval | "raised enrollment by **about 15%**" |
```

The full deliverable is that table, then an expanded block for each imperfect pair (PARTIAL, NOT
SUPPORTED, UNVERIFIABLE) with the claim, the cited work, the quoted evidence, why it fails, and the
rewording:

```
P4  draft.tex:96   NOT SUPPORTED  (direction reversal)

  CLAIM AS WRITTEN:
    "...small towns gained remote-service jobs from cheaper communication, in
     the spirit of \citet{AuthorA_2018_broadband}."

  CITED WORK:
    Author A (2018), Journal Name.

  SOURCE SAYS (quoted):
    "cheaper broadband moved call-center jobs out of small towns and into
     large cities" (abstract).

  WHY IT FAILS:
    The paper's flow runs from small towns to large cities. The sentence's flow
    runs into the small towns, the mirror image. "In the spirit of" implies a
    parallel that runs the wrong way.

  SUGGESTED REWORDING (the user's call):
    "...the opposite of the pattern in \citet{AuthorA_2018_broadband}, where
     cheaper broadband pulled call-center jobs away from small towns."
```

For UNVERIFIABLE, replace SOURCE SAYS and WHY IT FAILS with a WHAT WAS ACCESSIBLE line stating
exactly what was and was not seen, and leave out the rewording.

## 5. The boundary of the check

The check asks whether the cited source supports the claim. Whether the claim is correct,
whether the identification is sound, and whether the argument holds are outside this skill.

A true claim that its citation does not support is still a citation defect, and the fix
is the citation or the sentence. So the boundary is clean: a finding of "the source does not say
this" belongs here, and a finding of "this is wrong whatever any source says" belongs to a review of
the paper. When a pass turns up the second kind, note it for the user and leave it.

## 6. Conduct

Every claim-level fix is a proposal. A fix changes what a sentence asserts, which is the author's
call, so it goes to the user as a proposed rewording and waits for the user's decision, exactly as
FABRICATED and UNVERIFIABLE entries do. Leave the draft unedited until then. When applying approved
rewordings, match any revision-marking macro the surrounding text uses (a colored-text command, for
example), and ask when it is unclear whether the section uses one.

---
name: close-chat
description: >-
  Close a Claude Code chat so nothing lives only in its context. A read-only scan measures what
  the chat changed: files written and the lines in each, handoffs and their status, git state.
  The deliverable is verified by its authoritative check at that moment, every finding, decision
  and lesson goes into the project's files, and unfinished work gets a handoff file with a
  paste-ready prompt. The reply sorts the chat's work into done, found and not fixed (each with its
  next step), and needs the user (each with a recommendation), then gives a two-line verdict:
  whether the chat is closed and whether the window is safe to close. Use when the user says "are
  we done", "close this off", "wrap up" or "can I close this chat", or asks what is still
  outstanding in a project. On first use it asks where the project's records and handoffs live,
  how git is handled at the close, and which style check to run. It does not report progress
  mid-task or review code or papers.
---

# close-chat

The end-of-chat protocol. It ends on a verdict the user can trust without reopening the work:
every finding and lesson of the chat is in a file, unfinished work has an owner, and every claim
of done was checked at the close.

**Address the user as "you"** in every line the user reads. Never use he or she for anyone, since
a name does not tell pronouns: repeat the name or recast.

## Reference files

- `references/verification.md`: the scan's options and sections, the authoritative check for each
  kind of deliverable, and the concurrency and git traps.
- `references/handoffs.md`: the handoff file, the status audit, findings routed into open
  handoffs, the paste-ready prompt, and the discharge check.
- `references/claude_md_rules.md`: a short block the user pastes into a `CLAUDE.md` so every chat
  keeps its findings in files and closes with this skill.
- `references/examples.md`: one full close-off on an invented project. Calibrate format and depth
  against it. Its names, numbers and dates are placeholders that no real close reuses.
- `scripts/close_scan.py`: the read-only scan (Python 3.9 or later, standard library only).

## First run: the settings (once)

**Where the settings live.** In Claude Code: `~/.claude/close-chat/settings.md`, outside the skill
folder, so a newer version of the skill keeps them. Where nothing persists between chats (the
Claude apps without a file system), ask the questions below in the chat, work from the answers,
and say that the scan did not run: the close then works from the conversation and from the files
the user can show.

**Settings at each close.** At the start of every close, read the settings first and state in one
line what they hold ("Settings: records in TODO.md and notes/, handoffs as
notes/YYYY_MM_DD_handoff_<topic>.md, commit and push, style check from CLAUDE.md"). A project
whose `CLAUDE.md` names its own records, handoff or git convention follows that convention, and
the same line says so. If the file does not exist, ask the questions before Step 1.

Ask with the `AskUserQuestion` tool when available (a card holds up to four questions, so
question 5 goes on a second card), else as a short numbered list, each question with a recommended
default and its reason:

1. **Records.** "Where does this project keep its records: the to-do list, notes, and lessons
   learned?" Options: `TODO.md, dated notes in notes/, lessons in CLAUDE.md` (recommended: one
   place to look for what is open, a dated note per piece of work, and the conventions file every
   chat reads) · `One running NOTES.md` · `I'll name the files`.
2. **Handoffs.** "Where does work handed to a later chat go?" Options:
   `notes/YYYY_MM_DD_handoff_<topic>.md` (recommended: dated, beside the notes, found by one
   search) · `handoffs/<topic>.md` · `I'll name a pattern`. Beside this choice, save the pattern
   the scan matches against each file's path inside the project: `handoff` for the first option,
   `^handoffs/` for the second, and for a named pattern a regular expression that matches it.
3. **Git at the close.** "What happens in git when a chat closes?" Options: `Commit this
   chat's files and push` (recommended: the record of the work then exists in more than one
   place, and only this chat's files are staged) · `Commit only, I push` · `Ask me each time` ·
   `Do nothing in git`. Say in the question that a push to a public repository publishes, so
   `Commit only` suits a public one.
4. **Style check.** "Does the close check the wording of what the chat wrote?" Options:
   `Use the writing rules in my CLAUDE.md` · `Run my script: <path>` · `No check`. Read the
   user's `CLAUDE.md` first. Recommend the writing rules when it states some (the rules every chat
   already follows, applied once more to the lines this chat wrote), and `No check` when it states
   none.
5. **Rules block.** "Add a short block of rules to your CLAUDE.md, so every chat keeps its
   findings in files and closes with this skill?" Options: `Yes, in ~/.claude/CLAUDE.md`
   (recommended: every chat then keeps its record as it goes, and the close has little left to
   rescue) · `Yes, in this project's CLAUDE.md` · `No`. Show the block from
   `references/claude_md_rules.md` with the question, and add it only after a yes.

Save the answers in this form, show the file, and record later changes with their date:

```markdown
# close-chat settings
Saved: March 3, 2027

- Records: TODO.md, notes/YYYY_MM_DD_<topic>.md, lessons in CLAUDE.md
- Handoffs: notes/YYYY_MM_DD_handoff_<topic>.md, each with a STATUS line
- Handoff pattern for the scan: handoff
- Git at the close: commit this chat's files and push
- Style check: the writing rules in CLAUDE.md
- Rules block: added to ~/.claude/CLAUDE.md on March 3, 2027
- Projects that differ: (folder: what differs)
```

## A status question

When the user asks what is still outstanding in a project and is not closing the chat, run the
first scan (Step 1), re-read the handoffs' STATUS lines and the to-do list, and list what is open
with its owner: a handoff, a scheduled task, the user, or this chat. Do not write or commit
anything, and do not give a verdict, since the verdict belongs to a close.

## Standing rules

- **Measure at the close.** Every line of the report comes from a command or a read run in the
  closing turn. A file read earlier in the chat is presumed stale, since another chat, a
  collaborator or a sync service can change it within the hour. The reply names what was re-read.
- **Close with the skill every time.** A close run by hand, or cut short to save context, leaves
  the files behind the work, and the next chat starts from the stale version.
- **Own every mistake unasked.** Anything this chat got wrong and then corrected goes in the
  report. Anything destructive or large (deleted files, pruned entries, reset commits, mass
  renames) states its undo path: the archive folder or the commit to revert.
- **Report every step.** A step with nothing to do gets one clause saying so. A step missing from
  the report reads as skipped.
- **Send nothing.** A message the user still owes someone (an email, a reply to a coauthor) is
  left as a draft with its attachments named, and the close does not send, post or submit it.
- **Nothing the user taught this chat is left for later.** Every preference, rule, correction and
  lesson the user stated is written, in this chat and before the verdict, into its permanent home
  in that home's own format (the settings name the homes). A handoff or a note is never the home
  for a lesson: a handoff may not run for weeks, and the next chat repeats the mistake meanwhile.
  The same holds for cleanup of this chat's own output (style-check hits, half-applied renames):
  do it here. When context runs short, this capture runs first.

## Step 1. Scan

The first call of the close (the skill folder is usually `~/.claude/skills/close-chat/`, or
`.claude/skills/close-chat/` inside a project):

```bash
python3 ~/.claude/skills/close-chat/scripts/close_scan.py --project <folder> [--project <folder>] --task '<names of the finished work>' --handoff-pattern '<pattern from the settings>' --user
```

Measured against the chat's start time, read from the chat's own transcript, it reports:

- the rules files, `CLAUDE.md` files and skills changed during the chat
- the files this chat wrote, created or updated, with the lines it wrote in each
- every handoff file and the status its header states, and running processes that match the
  scripts the open handoffs name
- lines in notes and trackers that mention the finished work, marked `!` beside a pending marker
- sync-conflict copies, git state, and Claude memory files changed during the chat
- the number of summaries (compactions) the chat had, and the user's messages a summary replaced

Each section is explained in `references/verification.md`.

- A rules or `CLAUDE.md` file marked CHANGED is read first, since a rule added mid-chat can
  invalidate work that looked correct. A skill marked changed is invoked again before its next use.
- A handoff is called not running only when the live-run line shows nothing for it.
- A chat that was compacted says so in the checks table, with the number of summaries the scan
  counts, and the capture step (Step 4) reads the messages the scan lists, since the summary
  dropped their wording.

## Step 2. Deliverable

- **Authoritative check, run now.** Compile twice (plus `bibtex` when it cites) and look at the
  PDF, tables included. Re-run a script and read its log for errors. Load a config file. Trigger
  a hook (a command Claude Code runs on an event) and read what it produced. A proxy (the file
  exists, the edit applied) proves nothing. Anything left unchecked gets its own line:
  `NOT verified: <why>`.
- **Re-run every producer this chat wrote or edited** (a producer is a script that writes a
  table, a figure or a number), cosmetic edits included: a rename, a
  comment rewrite or a find-and-replace changes lines nobody re-read.
- **Input vintage.** For every number quoted in the report or a document, compare the input's
  modification time with when the number was taken. Where the input changed afterward, say so in
  the document beside the number. An input another process is still rebuilding is skipped, and
  the report says which.
- **The sample.** A fall in the number of observations the user did not ask for is reported with
  what left, how much, and whether it can be recovered, the last judged by an actual search
  (another source, an id format, another vintage).
- **Rules changed mid-chat are checked against the work.** A verification that reproduces an
  earlier result shows the code still agrees with its inputs and says nothing about whether the
  specification is still the chosen one.

## Step 3. Documents and records

- **Each update is applied exactly once**, in the homes the settings or the project's `CLAUDE.md`
  name. The final scan's `--applied FILE::PHRASE` counts it: 0 means the edit never applied, 2
  means it was duplicated.
- **Stale markers.** Every line the scan prints with `!` that still describes the finished work as
  pending gets a pointer to the deliverable. A superseded entry is marked superseded with the
  reason, so its history survives.
- **The documents list.** One line per document created or updated, from the scan's file list:
  parent folder plus file name, created or updated, one clause on what it now holds. Every kind
  counts (notes, handoffs, the to-do list, `CLAUDE.md`, lessons files, memory files). A file marked
  MISSING NOW is found and reported where it lives now. A chat that wrote nothing says "no
  document written".
- **Other chats' deliverables** in the same workstream since this chat last looked (a handoff
  stamped DONE that names a new file, a section added to a shared note) get lines too, marked as
  another chat's work.

## Step 4. Capture

- **Sweep the user's messages.** Walk the user's messages in this conversation, plus any the scan
  lists because a summary replaced them, and list every fact, decision, correction, contact,
  reference and preference the user stated. Each one is already in a file (name it), stored now,
  or judged not worth recording (say why). The offhand ones get lost first: a relationship, a
  correction of the record, a named fallback person, a word the user asked to avoid, a rule
  relayed from someone else. The test: if the user abandoned this chat for good, nothing they
  said is lost.
- **Homes.** A project convention goes to the project's `CLAUDE.md`. A coding or craft lesson goes
  to the lessons home the settings name, as a one-line rule with the incident under it, plus a
  checklist line when it implies a mechanical check. A lesson tied to one dataset goes to that
  project's notes. A preference that holds across projects goes to the user-level `CLAUDE.md` or
  to memory. Name what was judged not worth recording.
- **To-do.** Name what remains, or confirm nothing new, in the project's own format. Where the home
  is unclear, ask: an invented location loses the item.
- **Memory.** When the scan lists a memory file changed during the chat, the documents list names
  it.

## Step 5. Handoffs

- **Status from the files:** a handoff's own STATUS header first, then its closing notes, then the
  to-do list. An executed handoff with no stamp gets a DONE header, written on its STATUS line.
- **Findings routed into open handoffs.** When the reader of a handoff still to run would, on a
  cold read tomorrow, do something this chat now knows is wrong, write the finding into that
  handoff in a dated section of its own, and say so.
- **Prompts.** Every deferred item (a handoff, a next step of a "found and not fixed" item, a task
  named as outstanding) gets its paste-ready prompt in the reply, one fenced block per handoff.
  When nothing is deferred and the work may have been cut short, say which part, and ask whether
  the user wants a handoff for it.
- **Discharge.** A handoff hands work over only when, in this turn, its file exists (list it and
  name its path), its prompt is printed, and the prompt is self-contained. Small, safe, already
  diagnosed work is done here.

Formats and the ways a handoff fails while looking done: `references/handoffs.md`.

## Step 6. Final scan, style check and git

After all writing:

```bash
python3 ~/.claude/skills/close-chat/scripts/close_scan.py --final --project <folder> [--touched <file written through a shell command>[:FROM-TO] ...] [--applied <file>::<phrase> ...]
```

- **Style check**, as the settings say. Run it on the lines the final scan lists for each file
  (a whole file this chat wrote, or only the lines its edits wrote in a file others share). Fix
  every hit that the wording rules of that file forbid and re-run until none is left, then report
  the count. The
  user's own quoted words stay verbatim. Older lines of a shared file belong to others.
- **Concurrent chats.** Each edit of this chat is still present exactly once. Another chat or a
  sync service can revert one, so look for a sync-conflict copy before redoing work. A commit
  another chat made of this chat's change is reported as theirs. Report every conflict, failed
  action and blocked tool call, resolved or pending.
- **Git**, as the settings say. Stage each path by name, since `git add -A` also stages files
  other chats or the user changed, and commit this chat's files in scoped, thematic commits. A
  file this chat edited that also holds another chat's lines is committed with those lines named
  in the message. Files only others changed stay out. When the settings say push, push in the
  same action and verify `HEAD` against its remote branch, and for a repository that publishes
  a website, load the live page. Ask first, whatever the settings say,
  when a path is ignored or untracked by design, when the staged diff looks destructive or
  unscoped, or when the work is not verified. A project outside git gets "no repository" and
  where the work is backed up. Report commit ids and files, and each path left out with its
  reason.

## Step 7. The reply

In this order:

0. **Answer line**, only when the closing message asked a question: the reply's first line
   answers it.
1. **Re-read line**: one sentence naming what was re-read at the close.
2. **Checks table**: one row per step (scan, deliverable, documents, capture, handoffs, style,
   git), the result in a phrase. Files are named short in the table, with full paths below it.
3. **Documents list**: this chat's documents, then other chats' deliverables.
4. **Handoffs**: those still to run, with status and their prompts. The rest appear as counts,
   naming any whose status changed during the chat.
5. **The three categories**, each a numbered list, an empty one printed as "none":
   - **Done.** What this chat finished, one outcome-first sentence per item with the number or the
     verdict in it and the check that verified it at the close. A decision Claude took without
     asking (a method, sample, threshold or specification choice) is an item here, starting
     "Decided:", with its reason, so the user can overturn it. An error found and corrected is
     an item here with its disposition (fixed here, or fixed by another chat) and, for this
     chat's own mistake, its undo path. A pattern that recurred is named once.
   - **Found and not fixed.** Each item is one sentence on the problem, then `Next step:` and who
     owns it: a handoff file (named), a scheduled task listed in this turn, or this chat. A
     problem that cannot be reproduced from its inputs (two routes to one number that disagree,
     an N that differs across regressions sharing a sample) always has a next step that names the
     cause or the search for it, and "no action required" is never its next step. An error found
     and still open is an item here.
   - **Needs you.** Each item is one question, then `Recommendation:` with what Claude would do
     and why. Mutually exclusive options are one question. Where the evidence favors no option, say
     so and recommend on what remains (reversibility, cost, what it commits the user to). A
     question about a passage quotes it, with the sentence at issue named and its place in the
     document given. A question from an earlier reply that the user has not answered yet is
     printed again here with its number. Silence is never an answer, and no step that waits on
     that answer runs.
6. **The verdict**, two lines, last.

A fall in the number of observations (Step 2) goes under Found and not fixed while it may be
recovered, and under Done once a search shows it cannot be.

Every term a reader outside software would not know is defined in the sentence that uses it.
Nothing is re-argued, and nothing in Needs you is repeated elsewhere.

## The verdict

- **Line 1** states whether the work is finished: "This chat is closed." or "This chat is NOT
  closed:" plus exactly what is outstanding. Permission phrasings ("can be closed", "should be
  fine to close") never appear.
- **Ownership decides line 1.** A handoff written to a file with its prompt printed is handed over
  and never blocks "closed", however long it waits to run. Only work this chat owns and left
  unfinished forces NOT closed:
  - an item under Found and not fixed whose next step no handoff or scheduled task owns
  - an unanswered item under Needs you
  - work started and left half-done, or claimed done with no verifying command run now
  - a handoff named but never written, or written with its prompt unprinted
  - a preference, rule or lesson the user stated that is not yet in its permanent home, or
    cleanup of this chat's own output handed to another chat
  A step that is the user's to run, or that this chat cannot run by construction, stays this
  chat's until a handoff or scheduled task takes it over.
- **Work picked up elsewhere.** When the user says a follow-up happened in another chat, find it in
  the project folders (the newer document and its STATUS header), record this chat's open items as
  superseded with a pointer there, and where the files do not show it yet, record the user's
  statement, dated, in the item. Search before asking where.
- **Line 2**, always: "Safe to close this window: yes." or "Safe to close this window: no," plus
  the reason. It is no when something needs this conversation: an unanswered question, a form
  filled in this session's browser and not yet submitted, an edit in flight, or context costly to
  rebuild elsewhere. A "NOT closed" line 1 always takes "no" on line 2. When the window ought to
  be safe to close, finish the outstanding work first, so that line 1 can read closed.
- **A chat that continues after a verdict** runs the whole protocol again at its next close, since
  other chats move files in the gap.
- The verdict goes out only with the documents list (or "no document written") and the git report.

## Background work and linked sessions

Before the verdict, name every background job, linked session and scheduled task this chat
started, with its state. Stop or detach a finished one where the app allows. One still running
that no handoff owns keeps the chat NOT closed.

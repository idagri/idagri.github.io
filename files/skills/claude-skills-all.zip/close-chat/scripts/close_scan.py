#!/usr/bin/env python3
"""close_scan.py: the evidence a chat close-off needs, gathered in one read-only call.

The close-chat skill runs it twice.

  First scan   close_scan.py [--project DIR ...] [--task REGEX ...] [--user]
               Rules files, CLAUDE.md files and skills changed during the chat; the files this
               chat wrote, with the lines it wrote in each; handoff files and the status each one
               states; running processes that match the scripts the open handoffs name; lines in
               notes and trackers that mention the finished work; sync-conflict copies; the git
               state of every repository the chat touched; Claude memory files changed during
               the chat; with --user, the user's messages that a summary replaced.

  Final scan   close_scan.py --final [--project DIR ...] [--touched FILE[:FROM-TO] ...]
                             [--applied FILE::PHRASE ...]
               The files this chat wrote and the lines it wrote in each (the input of a style
               check), applied-once counts, and the git state for the commit.

The chat's transcript is found in this order: --transcript; --session or the
CLAUDE_CODE_SESSION_ID variable Claude Code sets; otherwise the most recently active transcript
in the folder Claude Code keeps for the working directory (or for the nearest parent folder
that has one) under ~/.claude/projects/. "During the chat" is measured from that transcript's
first timestamp. A section that could not run says so in capitals, and a section that ran over
nothing says that too, so an empty result always reads differently from a clean one.

The script changes nothing: it reads files, lists processes, and runs only git commands that
read (with GIT_OPTIONAL_LOCKS=0, so even `git status` leaves the index alone).
"""

from __future__ import annotations

import argparse
import glob
import json
import os
import re
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path

HOME = Path.home()
PROJECTS_DIR = HOME / ".claude" / "projects"
GLOBAL_RULES = HOME / ".claude" / "CLAUDE.md"
RULES_DIR = HOME / ".claude" / "rules"
SKILLS_DIR = HOME / ".claude" / "skills"

# Folders that hold data or build output and never a handoff; pruning them keeps a walk of a
# large synced folder bounded
PRUNE = {"node_modules", "__pycache__", "venv", "env", ".venv", "aux", "data", "raw", "results",
         "output", "outputs", "figures", "tables", "logs", "cache", "tmp", "site-packages"}
WALK_SECONDS = 20
MAX_DEPTH = 6
WIDTH = 170

STATUS_LINE = re.compile(r"\bstatus\b\s*\**\s*[:\u2014\u2013-]", re.I)
STATUS_WORD = re.compile(r"\bSTATUS\b")
# The FIRST keyword after STATUS decides, since a header often goes on to instruct
# ("NOT STARTED. Stamp IN PROGRESS at pickup and DONE at completion")
STATUS_KINDS = [
    ("open", re.compile(r"\bNOT (?:YET )?(?:STARTED|RUN|DONE|EXECUTED|COMPLETED?)\b|PENDING|NEVER RUN"
                        r"|\bOWED\b|\bOPEN\b|\bREADY\b|QUEUED|\bTODO\b|UNSTARTED|AWAITING|BLOCKED"
                        r"|ON HOLD|POSTPONED|PAUSED|DEFERRED")),
    ("superseded", re.compile(r"SUPERSED|RETIRED|OBSOLETE|CANCEL|DROPPED|ABANDON|WITHDRAWN")),
    ("partial", re.compile(r"PARTIAL|PARTLY")),
    ("in progress", re.compile(r"IN[ -]PROGRESS|RUNNING|PICKED UP")),
    ("done", re.compile(r"\bDONE\b|EXECUTED|\bCOMPLETED?\b|FINISHED|\bCLOSED\b|\u2705|SHIPPED|DELIVERED"
                        r"|\bAPPLIED\b|\bMERGED\b")),
]
LIST_NAME = re.compile(r"outstanding_handoffs|handoffs?_(?:list|index)", re.I)
PENDING_MARK = re.compile(r"NOT RUN|NOT STARTED|\bNOT (?:\w+ ){0,2}YET\b|NOT DONE|NOT WRITTEN|NEVER RUN|\bOWED\b|OUTSTANDING|PENDING|\bTODO\b(?!\.md)"
                          r"|\[ \]|NEXT STEP|TO BE RUN|UNSTARTED", re.I)
# A line already stamped as settled is no longer a stale marker
# DONE counts as a stamp only in the form a handoff's STATUS line takes (followed by a colon, a
# parenthesis or a date), so "NOT DONE" and "DONE at completion" stay pending
STAMPED = re.compile(r"\bSUPERSEDED\b|\bRESOLVED\b|\[x\]"
                     r"|(?<!NOT )(?<!NOT YET )\bDONE\b(?=\s*[:(]|\s+[A-Z][a-z]+ \d{1,2}, \d{4}|\s+\d{4}-\d{2}-\d{2})", re.I)
UNCHECKED = re.compile(r"\[ \]")
SCRIPT_NAME = re.compile(r"[\w.\-/]+\.(?:py|do|[Rr]|jl|m|sh|ipynb|tex)\b")
RUNNER = re.compile(r"python|stata|Rscript|julia|matlab|latexmk|pdflatex|xelatex|lualatex", re.I)
VERDICT = re.compile(r"This chat is (?:NOT )?closed")
CONFLICT = re.compile(r"conflicted copy|sync-conflict", re.I)
SKIP_USER_TEXT = ("<command-", "<local-command", "Caveat:", "[Request interrupted", "<system-reminder>",
                  "<task-notification")
SCRATCH = ("/private/tmp/", "/tmp/", "/private/var/folders/", "/var/folders/")
# On macOS an unaccepted Xcode license stops the /usr/bin/git shim; this binary still runs
CLT_GIT = "/Library/Developer/CommandLineTools/usr/bin/git"


def clip(text, width=WIDTH):
    text = " ".join(str(text).split())
    return text if len(text) <= width else text[: width - 1] + "\u2026"


def clock(ts):
    moment = datetime.fromtimestamp(ts)
    fmt = "%H:%M" if moment.date() == datetime.now().date() else "%b %d %H:%M"
    return moment.strftime(fmt)


def seconds(stamp):
    """Epoch seconds of an ISO timestamp as transcripts write it, or 0 when it does not parse"""
    try:
        return datetime.fromisoformat(stamp.replace("Z", "+00:00")).timestamp()
    except (AttributeError, ValueError):
        return 0.0


def short(path, bases=()):
    path = Path(path)
    for base in bases:
        try:
            return str(path.relative_to(base.parent))
        except ValueError:
            pass
    try:
        return "~/" + str(path.relative_to(HOME))
    except ValueError:
        return str(path)


def mtime(path):
    try:
        return path.stat().st_mtime
    except OSError:
        return None


def read_lines(path, limit=None, max_bytes=3_000_000):
    try:
        if path.stat().st_size > max_bytes:
            return []
        lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
    except OSError:
        return []
    return lines[:limit] if limit else lines


def run(cmd, timeout=20, env=None):
    """Exit code, stdout and stderr; stdout keeps its leading characters (git's status columns)"""
    try:
        done = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, env=env)
        return done.returncode, done.stdout, done.stderr.strip()
    except (OSError, subprocess.TimeoutExpired) as err:
        return 1, "", str(err)


GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS="0")


def git(repo, *args):
    rc, out, err = run(["git", "-C", str(repo), *args], env=GIT_ENV)
    if rc != 0 and "Xcode license" in err and Path(CLT_GIT).exists():
        rc, out, err = run([CLT_GIT, "-C", str(repo), *args], env=GIT_ENV)
    return rc, out, err


GIT_ERRORS = []


def git_runs():
    """Whether git runs at all; the reason is kept when it does not"""
    if not hasattr(git_runs, "ok"):
        rc, out, err = git(Path.cwd(), "--version")
        git_runs.ok = rc == 0 and out.startswith("git version")
        if not git_runs.ok:
            GIT_ERRORS.append(clip(err or out or f"exit {rc}", 140))
    return git_runs.ok


def ranges(numbers):
    """Line numbers as compact ranges: 3-7, 12, 20-21"""
    spans, start, prev = [], None, None
    for n in sorted(numbers):
        if start is None:
            start = prev = n
        elif n == prev + 1:
            prev = n
        else:
            spans.append((start, prev))
            start = prev = n
    if start is not None:
        spans.append((start, prev))
    return ", ".join(str(a) if a == b else f"{a}-{b}" for a, b in spans)


# ---------------------------------------------------------------- session

def encode(folder):
    """The name Claude Code gives a working folder under ~/.claude/projects/"""
    return re.sub(r"[^A-Za-z0-9]", "-", str(folder))


def last_stamp(path, chunk=1_048_576):
    """The last timestamp in a transcript, read from its tail

    The desktop app appends undated bookkeeping lines to old chats, so the file's modification
    time does not date the chat's last use; the last timestamped entry does.
    """
    try:
        size = path.stat().st_size
        with open(path, "rb") as fh:
            fh.seek(max(0, size - chunk))
            tail = fh.read().decode("utf-8", errors="replace").splitlines()
    except OSError:
        return 0.0
    for line in reversed(tail):
        try:
            row = json.loads(line)
        except ValueError:
            continue
        if isinstance(row, dict) and row.get("timestamp"):
            return seconds(row["timestamp"])
    return 0.0


def mentions_scan(path, chunk=65_536):
    """Whether the last entries of a transcript, or of its newest subagent transcripts, run this script"""
    agents = sorted(path.with_suffix("").glob("subagents/*.jsonl"), key=lambda p: -(mtime(p) or 0))
    for source in [path] + agents[:4]:
        try:
            size = source.stat().st_size
            with open(source, "rb") as fh:
                fh.seek(max(0, size - chunk))
                if b"close_scan.py" in fh.read():
                    return True
        except OSError:
            continue
    return False


def find_transcript(args, projects):
    """The chat's transcript and how it was found"""
    if args.transcript:
        path = Path(args.transcript).expanduser()
        if path.exists():
            return path, "given with --transcript"
        return None, f"--transcript {path} does not exist"
    note = ""
    if args.session:
        hits = sorted(glob.glob(str(PROJECTS_DIR / "*" / f"{args.session}.jsonl")))
        if hits:
            return Path(hits[0]), "found by session id"
        note = f"no transcript named {args.session}.jsonl; "
    starts = []
    for raw in (os.environ.get("PWD"), os.getcwd(), *[str(p) for p in projects]):
        if raw:
            for folder in (Path(raw), Path(raw).resolve()):
                if folder not in starts:
                    starts.append(folder)
    for start in starts:
        for folder in (start, *start.parents):
            kept = PROJECTS_DIR / encode(folder)
            files = sorted(kept.glob("*.jsonl")) if kept.is_dir() else []
            if files:
                recent = sorted(files, key=lambda p: (last_stamp(p), mtime(p) or 0), reverse=True)
                # Several chats can be active in one folder; the one running this scan has just
                # written the command that started it
                calling = next((p for p in recent[:8] if mentions_scan(p)), None)
                if calling and folder != start:
                    return calling, (note + f"a guess: {short(start)} has no transcript folder, so this is the "
                                     f"most recent of {len(files)} transcript(s) kept for the parent folder "
                                     f"{short(folder)} whose last entries run close_scan.py; pass --session "
                                     "to be sure")
                if calling:
                    return calling, (note + f"the most recent of {len(files)} transcript(s) kept for "
                                     f"{short(folder)} whose last entries run close_scan.py")
                return recent[0], (note + f"the most recently active of {len(files)} transcript(s) kept for "
                                   f"{short(folder)}: a guess, so pass --session to be sure")
    return None, note + f"no transcript folder under {short(PROJECTS_DIR)} matches the working folder"


def session_start(transcript):
    with open(transcript, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            try:
                row = json.loads(line)
            except ValueError:
                continue
            if isinstance(row, dict) and seconds(row.get("timestamp") or ""):
                return seconds(row["timestamp"])
    info = transcript.stat()
    return getattr(info, "st_birthtime", info.st_mtime)


def written_by_chat(transcript):
    """Files this chat's Write and Edit tools changed, read from its transcript and its subagents'

    Returns {path: {"created": bool, "whole": bool, "edits": [new_string, ...], "last": iso time}}.
    A Write result says "File created successfully" for a new file, which is the only reliable
    creation record: an editor that saves through a temporary file and a rename (the Edit tool
    does) moves the file's creation time with every save.
    """
    files = {}
    sources = [transcript] + sorted(transcript.with_suffix("").glob("subagents/**/*.jsonl"))
    for source in sources:
        pending = {}
        with open(source, encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                try:
                    row = json.loads(raw)
                except ValueError:
                    continue
                if not isinstance(row, dict):
                    continue
                content = (row.get("message") or {}).get("content")
                if not isinstance(content, list):
                    continue
                for block in content:
                    if not isinstance(block, dict):
                        continue
                    kind = block.get("type")
                    if kind == "tool_use" and block.get("name") in ("Write", "Edit", "MultiEdit", "NotebookEdit"):
                        pending[block.get("id")] = (block.get("name"), block.get("input") or {})
                    elif kind == "tool_result" and block.get("tool_use_id") in pending:
                        name, given = pending.pop(block.get("tool_use_id"))
                        if block.get("is_error"):
                            continue
                        target = given.get("file_path") or given.get("notebook_path")
                        if not target or target.startswith(SCRATCH) or "/scratchpad/" in target:
                            continue
                        record = files.setdefault(Path(target).expanduser().resolve(),
                                                  {"created": False, "whole": False, "edits": [], "last": ""})
                        reply = block.get("content")
                        reply = reply if isinstance(reply, str) else json.dumps(reply)
                        record["last"] = row.get("timestamp") or record["last"]
                        if name == "Write":
                            record["whole"] = True
                            record["created"] = record["created"] or "created successfully" in reply
                        elif name == "Edit":
                            record["edits"].append(given.get("new_string", ""))
                        elif name == "MultiEdit":
                            record["edits"] += [e.get("new_string", "") for e in given.get("edits", [])]
                        else:
                            record["whole"] = True
    return files


def edit_lines(path, edits):
    """Line numbers where the text each Edit wrote stands in the file now"""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return set()
    lines = set()
    for new in edits:
        new = new.strip("\n")
        if not new.strip():
            continue
        start = text.find(new)
        while start != -1:
            first = text.count("\n", 0, start) + 1
            lines.update(range(first, first + new.count("\n") + 1))
            start = text.find(new, start + 1)
    return lines


# ---------------------------------------------------------------- git helpers

def repo_root(path):
    """The repository holding a path, None outside git or when git cannot run"""
    if not git_runs():
        return None
    folder = path if path.is_dir() else path.parent
    while not folder.exists() and folder != folder.parent:
        folder = folder.parent
    rc, out, err = git(folder, "rev-parse", "--show-toplevel")
    out = out.strip()
    if rc == 0 and out:
        return Path(out).resolve()
    if "not a git repository" not in err.lower():
        GIT_ERRORS.append(clip(f"{short(folder)}: {err or 'exit ' + str(rc)}", 140))
    return None


def lines_written(path, spans, record):
    """Which lines of a file this chat wrote, and how that was decided"""
    if spans:
        lines = set()
        for first, last in spans:
            lines.update(range(first, last + 1))
        return lines, "the --touched range"
    if record and record["whole"]:
        return "all", "written whole"
    if record and record["edits"]:
        lines = edit_lines(path, record["edits"])
        if lines:
            return lines, "where this chat's edits stand now"
    root = repo_root(path)
    if root:
        rc, _, _ = git(root, "ls-files", "--error-unmatch", str(path))
        if rc != 0:
            return "all", "untracked, whole file"
        _, diff, _ = git(root, "diff", "-U0", "HEAD", "--", str(path))
        added = set()
        for hunk in re.finditer(r"^@@ -\d+(?:,\d+)? \+(\d+)(?:,(\d+))? @@", diff, re.M):
            first = int(hunk.group(1))
            count = int(hunk.group(2)) if hunk.group(2) is not None else 1
            added.update(range(first, first + count))
        if added:
            return added, "uncommitted added lines, another chat's included if any"
        return None, "no uncommitted change: pass FILE:FROM-TO for lines already committed"
    if record:
        return None, "lines not located (the edited text has changed since): pass FILE:FROM-TO"
    return None, "outside git: pass FILE:FROM-TO to name this chat's block"


def parse_touched(specs):
    wanted = {}
    for spec in specs:
        match = re.match(r"^(.*?):(\d+)-(\d+)$", spec)
        path = Path(match.group(1) if match else spec).expanduser().resolve()
        span = (int(match.group(2)), int(match.group(3))) if match else None
        wanted.setdefault(path, [])
        if span:
            wanted[path].append(span)
    return wanted


def written_section(written, touched, projects, cap):
    out = [f"== files this chat wrote: {len(set(written) | set(touched))} (Write and Edit tools, subagents "
           "included; a file written through a shell command or a script counts only when passed with "
           "--touched)"]
    if not written and not touched:
        out.append("  none: this chat wrote no file with its tools, so the documents list reads "
                   "'no document written'")
        return out
    order = sorted(written, key=lambda p: written[p]["last"])
    order += sorted(p for p in touched if p not in written)
    for path in order[: cap * 3]:
        record = written.get(path)
        if not path.exists():
            state = "MISSING NOW (renamed, moved or deleted since)"
            where = ""
        else:
            state = "created" if record and record["created"] else "updated"
            lines, why = lines_written(path, touched.get(path), record)
            label = "line" if lines and lines != "all" and len(lines) == 1 else "lines"
            where = (f"[{why}]" if lines == "all" else
                     f"[{label} {clip(ranges(lines), 60)}: {why}]" if lines else f"[{why}]")
        extra = "  (from --touched)" if record is None else ""
        out.append(f"  {state:8s} {short(path, projects)}  {where}{extra}")
    if len(order) > cap * 3:
        out.append(f"  (+{len(order) - cap * 3} more; raise --max to list them)")
    return out


# ---------------------------------------------------------------- rules and skills

def dated_lines(path, start, cap=5):
    first_day = datetime.fromtimestamp(start).strftime("%Y-%m-%d")
    hits = [line for line in read_lines(path)
            if any(d >= first_day for d in re.findall(r"\d{4}-\d{2}-\d{2}", line))]
    return hits[-cap:]


def conventions_files(projects):
    """Every CLAUDE.md that applies to the project folders, from each folder up to the home folder"""
    found = []
    for proj in projects:
        folder = proj
        while True:
            for conv in (folder / "CLAUDE.md", folder / "CLAUDE.local.md", folder / ".claude" / "CLAUDE.md"):
                if conv.exists() and conv not in found:
                    found.append(conv)
            if folder == HOME or folder == folder.parent:
                break
            folder = folder.parent
    return found


def skill_folders(projects):
    roots = [SKILLS_DIR] + [p / ".claude" / "skills" for p in projects]
    folders = []
    for root in roots:
        if root.is_dir():
            folders += [s for s in sorted(root.iterdir()) if (s / "SKILL.md").exists()]
    return folders


def rules_section(start, projects, only_changes=False):
    out = ["== rules, CLAUDE.md files and skills changed since the chat started"]
    files = [("global CLAUDE.md", GLOBAL_RULES)] if GLOBAL_RULES.exists() else []
    if RULES_DIR.is_dir():
        files += [(f"rules/{p.name}", p) for p in sorted(RULES_DIR.glob("*.md"))]
    project_files = conventions_files(projects)
    files += [(short(p, projects), p) for p in project_files if p != GLOBAL_RULES]
    changed = [(label, p, mtime(p)) for label, p in files if (mtime(p) or 0) > start]
    for label, path, when in changed:
        out.append(f"  CHANGED {clock(when)}  {label}: re-read it before relying on the copy in context")
        for line in dated_lines(path, start):
            out.append("      " + clip(line, 120))
    if not changed:
        out.append(f"  unchanged: {len(files)} rules and CLAUDE.md file(s)")
    skills = []
    for skill in skill_folders(projects):
        newest = 0
        for root, _dirs, names in os.walk(skill.resolve()):
            for name in names:
                if name != ".DS_Store" and not name.endswith(".pyc"):
                    newest = max(newest, mtime(Path(root) / name) or 0)
        if newest > start:
            skills.append(f"{skill.name} ({clock(newest)})")
    if skills:
        out.append("  skills changed during the chat, invoke again before the next use: " + ", ".join(skills))
    elif not only_changes:
        out.append("  no skill changed during the chat")
    return out


# ---------------------------------------------------------------- walk

def walk(projects, handoff_rx):
    handoffs, texts, repos, conflicts = [], [], set(), []
    deadline = time.monotonic() + WALK_SECONDS
    stopped_at = None
    for proj in projects:
        depth0 = len(proj.parts)
        for dirpath, dirnames, filenames in os.walk(proj):
            if time.monotonic() > deadline:
                stopped_at = dirpath
                break
            here = Path(dirpath)
            if ".git" in dirnames or ".git" in filenames:
                repos.add(here)
            depth = len(here.parts) - depth0
            dirnames[:] = [d for d in dirnames
                           if depth < MAX_DEPTH and not d.startswith(".") and d.lower() not in PRUNE
                           and not d.lower().startswith(("_archive", "archive"))]
            for name in filenames:
                low = name.lower()
                if CONFLICT.search(low):
                    conflicts.append(here / name)
                if low.endswith((".md", ".txt")):
                    texts.append(here / name)
                    # The pattern is matched against the path inside the project, so a setting such
                    # as "^handoffs/" finds a handoff folder; a skill's references folder holds none
                    relative = (here / name).relative_to(proj).as_posix()
                    if handoff_rx.search(relative) and not LIST_NAME.search(low) and here.name != "references":
                        handoffs.append(here / name)
        if stopped_at:
            break
    return handoffs, texts, repos, conflicts, stopped_at


# ---------------------------------------------------------------- handoffs

def classify(path):
    head = read_lines(path, limit=40)
    line = next((l for l in head if STATUS_LINE.search(l)), None) \
        or next((l for l in head if STATUS_WORD.search(l)), None)
    if line is None:
        return "no header", ""
    window = line[line.lower().find("status"):][:90].upper()
    window = re.sub(r"\(WAS [^)]*\)", " ", window)  # history such as "DONE (was NOT RUN)"
    found = sorted((m.start(), kind) for kind, rx in STATUS_KINDS for m in [rx.search(window)] if m)
    if not found:
        return "unclear", clip(line.strip(" >*#"), 90)
    kind = found[0][1]
    if kind == "done" and any(k == "open" for _pos, k in found):
        kind = "partial"
    return kind, clip(line.strip(" >*#"), 90)


def handoff_section(handoffs, projects, start, cap):
    out = []
    rows = []
    for path in handoffs:
        kind, status = classify(path)
        rows.append((mtime(path) or 0, path, kind, status))
    rows.sort(key=lambda r: r[0], reverse=True)
    counts = {}
    for _m, _p, kind, _s in rows:
        counts[kind] = counts.get(kind, 0) + 1
    order = ["done", "superseded", "open", "partial", "in progress", "unclear", "no header"]
    tally = ", ".join(f"{counts[k]} {k}" for k in order if counts.get(k))
    out.append(f"== handoffs: {len(rows)} found ({tally or 'none'})")
    if not rows:
        out.append("  no handoff file under the project folder(s): say so in the report")
        return out, []
    changed = [r for r in rows if r[0] > start]
    if changed:
        out.append("  changed during this chat (by this chat or another), every status:")
        for _when, path, kind, status in changed[:cap]:
            out.append(f"    [{kind}] {short(path, projects)}  {clip(status, 70)}")
        if len(changed) > cap:
            out.append(f"    (+{len(changed) - cap} more changed during the chat; raise --max to list them)")
    live = [r for r in rows if r[2] not in ("done", "superseded")]
    older = [r for r in live if r[0] <= start]
    if older:
        out.append(f"  still to run and untouched during this chat: {len(older)}, newest first:")
        for _when, path, kind, status in older[:cap]:
            out.append(f"    [{kind}] {short(path, projects)}  {clip(status, 70)}")
        if len(older) > cap:
            out.append(f"    (+{len(older) - cap} older; raise --max to list more)")
    return out, [r[1] for r in live]


def live_runs(open_handoffs, projects):
    names = set()
    for path in open_handoffs:
        for line in read_lines(path, max_bytes=400_000):
            names.update(os.path.basename(m) for m in SCRIPT_NAME.findall(line))
    rc, listing, err = run(["ps", "-Ao", "pid=,etime=,command="])
    if rc != 0:
        return [f"  LIVE-RUN CHECK DID NOT RUN: {clip(err or 'ps is not available', 80)}"]
    hits = []
    for line in listing.splitlines():
        parts = line.split(None, 2)
        if len(parts) < 3 or "close_scan.py" in parts[2]:
            continue
        pid, elapsed, cmd = parts
        named = next((n for n in names if re.search(r"(^|[/\s'\"])" + re.escape(n) + r"($|[\s'\"])", cmd)), None)
        in_project = any(str(p) in cmd for p in projects) and RUNNER.search(cmd)
        if named or in_project:
            hits.append(f"    pid {pid}, running {elapsed}: {clip(cmd, 120)}")
    head = (f"  live runs: {len(hits)} process(es) match the {len(names)} script name(s) in those handoffs"
            " or run inside the project")
    return [head] + hits[:10]


# ---------------------------------------------------------------- task mentions

def task_section(texts, patterns, projects, cap):
    rx = re.compile("|".join(f"(?:{p})" for p in patterns), re.I)
    hits = []
    for path in texts:
        for number, line in enumerate(read_lines(path), 1):
            if rx.search(line):
                pending = PENDING_MARK.search(line) and (UNCHECKED.search(line) or not STAMPED.search(line))
                hits.append((0 if pending else 1, str(path), number, path, line))
    hits.sort(key=lambda h: h[:3])
    flagged = sum(1 for h in hits if h[0] == 0)
    out = [f"== mentions of the finished work ({' | '.join(patterns)}): {len(hits)} line(s) in "
           f"{len({h[1] for h in hits})} file(s), {flagged} beside a pending marker (marked !)"]
    if not texts:
        out.append("  NO .md OR .txt FILE WAS SEARCHED: check --project")
    for flag, _s, number, path, line in hits[:cap]:
        mark = "!" if flag == 0 else " "
        out.append(f"  {mark} {short(path, projects)}:{number}  {clip(line, 110)}")
    if len(hits) > cap:
        out.append(f"  (+{len(hits) - cap} more; narrow --task or raise --max)")
    return out


# ---------------------------------------------------------------- git

def porcelain(text):
    """(status, path) pairs from `git status --porcelain=v1 -z`, renames reported by their new name"""
    items = text.split("\0")
    pairs, i = [], 0
    while i < len(items):
        entry = items[i]
        i += 1
        if len(entry) < 4:
            continue
        code, name = entry[:2], entry[3:]
        if "R" in code or "C" in code:
            i += 1  # the original name follows a rename or a copy
        pairs.append((code, name))
    return pairs


def git_section(repos, touched, start, projects, cap, counts_only=False):
    out = ["== git (read only)"]
    if not git_runs():
        out.append(f"  GIT DID NOT RUN: {GIT_ERRORS[0] if GIT_ERRORS else 'unknown error'}; "
                   "the git state of the project is NOT checked")
        return out
    for err in GIT_ERRORS:
        out.append(f"  GIT FAILED while finding a repository: {err}")
    if not repos:
        out.append("  no git repository covers the project folder(s) or the files this chat wrote: "
                   "report no commit, and say where the work is backed up")
        return out
    since = datetime.fromtimestamp(start).strftime("%Y-%m-%d %H:%M:%S")
    quiet = []
    for number, repo in enumerate(sorted(repos), 1):
        label = repo.name if counts_only else short(repo, projects)
        rc_status, status, err_status = git(repo, "status", "--porcelain=v1", "-z")
        if rc_status != 0:
            # A failed git is never a clean repository
            out.append(f"  GIT FAILED in {label}: {clip(err_status, 140)}")
            continue
        _, branch, _ = git(repo, "rev-parse", "--abbrev-ref", "HEAD")
        _, head, _ = git(repo, "log", "-1", "--format=%h %s")
        rc, counts, _ = git(repo, "rev-list", "--left-right", "--count", "HEAD...@{u}")
        upstream = "no upstream"
        ahead = behind = 0
        if rc == 0 and counts.split():
            ahead, behind = (int(x) for x in counts.split())
            upstream = f"{ahead} unpushed, {behind} behind the upstream"
        _, log, _ = git(repo, "log", f"--since={since}", "--format=%ad %h %s", "--date=format:%H:%M")
        commits = log.splitlines()
        mine, during, older = [], [], 0
        for _code, name in porcelain(status):
            full = (repo / name).resolve()
            shown = name if full.exists() else f"{name} (deleted)"
            inside = name.endswith("/") and any(t.is_relative_to(full) for t in touched)
            if full in touched or inside:
                mine.append(shown)
            elif (mtime(full) or start + 1) > start:
                during.append(shown)
            else:
                older += 1
        if not (mine or during or commits or ahead or behind):
            quiet.append(f"{label} ({older} older uncommitted file(s), not touched)" if older else f"{label} (clean)")
            continue
        if counts_only:
            out.append(f"  {label}  ({upstream})")
            out.append(f"    commits since the chat started: {len(commits)}; this chat's files uncommitted: "
                       f"{len(mine)}; other files changed during the chat: {len(during)}; older uncommitted: {older}")
            continue
        out.append(f"  {label}  {branch.strip()} @ {clip(head, 60)}  ({upstream})")
        if commits:
            out.append(f"    commits since the chat started: {len(commits)}")
            out += [f"      {clip(c, 100)}" for c in commits[:8]]
        if mine:
            out.append(f"    this chat's files, uncommitted: {clip(', '.join(mine[:cap]), 150)}")
        if during:
            out.append("    other files changed during the chat, uncommitted (another chat's or the user's, unless "
                       f"this chat wrote them through a shell command): {clip(', '.join(during[:cap]), 120)}"
                       + (f" (+{len(during) - cap})" if len(during) > cap else ""))
        if older:
            out.append(f"    older uncommitted files, not touched: {older}")
    if quiet:
        out.append(f"  untouched during the chat: {', '.join(quiet)}")
    return out


# ---------------------------------------------------------------- memory, conflicts, the user's messages

def memory_section(transcript, start):
    memory = transcript.parent / "memory"
    out = ["== Claude memory for this project"]
    if not memory.exists():
        out.append(f"  no memory folder ({short(memory)})")
        return out
    changed = sorted(p.name for p in memory.rglob("*.md") if (mtime(p) or 0) > start)
    folder_changed = (mtime(memory) or 0) > start
    if not changed and not folder_changed:
        out.append("  no memory file changed during the chat")
    else:
        out.append(f"  changed during the chat: {clip(', '.join(changed) or 'a file was added or deleted', 150)}")
    return out


def conflict_section(conflicts, start, projects):
    if not conflicts:
        return ["== sync-conflict copies: none"]
    out = [f"== sync-conflict copies: {len(conflicts)} (a copy made during the chat can hold an edit the "
           "sync service set aside)"]
    for path in sorted(conflicts, key=lambda p: -(mtime(p) or 0))[:5]:
        tag = "  (made during this chat)" if (mtime(path) or 0) > start else ""
        out.append(f"  {short(path, projects)}{tag}")
    if len(conflicts) > 5:
        out.append(f"  (+{len(conflicts) - 5} older)")
    return out


def user_section(transcript, every, width=500):
    """The user's messages that the conversation no longer shows verbatim

    A summary replaces the messages before its boundary, and an earlier verdict means its close
    already swept the messages before it. Only messages in neither group are listed; the rest
    are counted, since they sit in the conversation itself. --user-all lists every message.
    """
    messages, boundary, verdict, verdict_at, summaries = [], 0, 0, None, 0
    with open(transcript, encoding="utf-8", errors="replace") as fh:
        for raw in fh:
            try:
                row = json.loads(raw)
            except ValueError:
                continue
            if not isinstance(row, dict):
                continue
            if row.get("subtype") == "compact_boundary":
                boundary = len(messages)
                summaries += 1
                continue
            content = (row.get("message") or {}).get("content")
            if row.get("type") == "assistant" and isinstance(content, list):
                if any(isinstance(b, dict) and b.get("type") == "text" and VERDICT.search(b.get("text", ""))
                       for b in content):
                    verdict, verdict_at = len(messages), row.get("timestamp")
                continue
            if row.get("type") != "user" or row.get("isMeta") or row.get("isCompactSummary"):
                continue
            if isinstance(content, list):
                if any(isinstance(b, dict) and b.get("type") == "tool_result" for b in content):
                    continue
                content = "\n".join(b.get("text", "") for b in content
                                    if isinstance(b, dict) and b.get("type") == "text")
            text = content.strip() if isinstance(content, str) else ""
            if text and not text.startswith(SKIP_USER_TEXT):
                messages.append((row.get("timestamp"), text))
    head = f"== the user's messages in this chat: {len(messages)}; summaries (compactions): {summaries}"
    if every:
        shown = messages
        head += ", all listed (--user-all)"
    else:
        shown = messages[verdict:boundary]
        if verdict_at:
            head += f"; {verdict} swept by the close at {clock(seconds(verdict_at))}"
        visible = len(messages) - max(verdict, boundary)
        head += f"; {visible} still in the conversation, read them there"
        head += (f"; {len(shown)} replaced by a summary, listed below" if shown
                 else "; none replaced by a summary")
    out = [head]
    for stamp, text in shown:
        when = clock(seconds(stamp)) if stamp and seconds(stamp) else "?"
        flat = " ".join(text.split())
        extra = f" (+{len(flat) - width} chars)" if len(flat) > width else ""
        out.append(f"  [{when}] {clip(text, width)}{extra}")
    return out


# ---------------------------------------------------------------- main

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--project", action="append", default=[],
                    help="a folder the chat worked in, repeatable (default: the working folder)")
    ap.add_argument("--session", default=os.environ.get("CLAUDE_CODE_SESSION_ID"),
                    help="session id (default: $CLAUDE_CODE_SESSION_ID when Claude Code sets it)")
    ap.add_argument("--transcript", help="path to the chat's .jsonl transcript, when it cannot be found")
    ap.add_argument("--since", help="chat start as 'YYYY-MM-DD HH:MM' local time, when no transcript is found")
    ap.add_argument("--task", action="append", default=[], help="regex naming the finished work, repeatable")
    ap.add_argument("--handoff-pattern", default="handoff",
                    help="regex a handoff file's path inside the project folder matches (default: 'handoff'; "
                         "for a handoffs folder, '^handoffs/')")
    ap.add_argument("--touched", action="extend", nargs="+", default=[], metavar="FILE[:FROM-TO]",
                    help="files this chat wrote through a shell command or a script; a line range names this "
                         "chat's block")
    ap.add_argument("--applied", action="append", default=[], metavar="FILE::PHRASE",
                    help="count a distinctive phrase of an edit; 1 means it was applied exactly once")
    ap.add_argument("--repo", action="append", default=[],
                    help="another git repository to read, repeatable (read only, nothing is walked)")
    ap.add_argument("--counts-only", action="store_true",
                    help="git section as counts, with no file names or commit messages")
    ap.add_argument("--user", action="store_true", help="list the user's messages a summary replaced")
    ap.add_argument("--user-all", action="store_true", help="list every message the user sent in this chat")
    ap.add_argument("--final", action="store_true", help="the closing scan: files and lines written, applied-once counts, git")
    ap.add_argument("--max", type=int, default=12, help="lines listed per section (default 12)")
    args = ap.parse_args()

    began = time.monotonic()
    projects = [Path(p).expanduser().resolve() for p in (args.project or [os.getcwd()])]
    missing = [p for p in projects if not p.is_dir()]
    if missing:
        print("PROJECT FOLDER NOT FOUND: " + ", ".join(str(p) for p in missing))
        return 2
    touched = parse_touched(args.touched)
    transcript, how = find_transcript(args, projects)
    if args.since:
        start = datetime.strptime(args.since, "%Y-%m-%d %H:%M").timestamp()
    elif transcript:
        start = session_start(transcript)
    else:
        print(f"SESSION START UNKNOWN: {how}; pass --session, --transcript or --since 'YYYY-MM-DD HH:MM'")
        return 2
    print(f"== close_scan {'final' if args.final else 'first'} scan: chat started {clock(start)}; "
          f"project folder(s): {', '.join(short(p) for p in projects)}")
    print(f"== transcript: {short(transcript) + ' (' + how + ')' if transcript else 'NOT FOUND: ' + how}")

    written = written_by_chat(transcript) if transcript else {}
    out = rules_section(start, projects, only_changes=args.final)
    out += written_section(written, touched, projects, args.max)
    repos = {r for r in (repo_root(p) for p in projects) if r}
    repos |= {r for r in (repo_root(p) for p in set(touched) | set(written)) if r}
    for extra in args.repo:
        root = repo_root(Path(extra).expanduser().resolve())
        if root:
            repos.add(root)
        elif git_runs():
            out.append(f"== --repo {extra}: NOT A GIT REPOSITORY")
    if not args.final:
        handoffs, texts, nested, conflicts, stopped_at = walk(projects, re.compile(args.handoff_pattern, re.I))
        if stopped_at:
            out.append(f"== WALK STOPPED after {WALK_SECONDS} s at {short(stopped_at)}: "
                       "results below are partial; pass a narrower --project")
        repos |= {r.resolve() for r in nested}
        section, still_open = handoff_section(handoffs, projects, start, args.max)
        out += section
        if still_open:
            out += live_runs(still_open, projects)
        lists = sorted((p for p in texts if LIST_NAME.search(p.name)), key=lambda p: -(mtime(p) or 0))
        if lists:
            out.append("  handoff list(s) the project keeps, newest first: "
                       + ", ".join(short(p, projects) for p in lists[:3]))
        if args.task:
            out += task_section(texts, args.task, projects, args.max)
        out += conflict_section(conflicts, start, projects)
    out += git_section(repos, set(touched) | set(written), start, projects, args.max, args.counts_only)
    if args.applied:
        out.append("== applied-once counts (1 = applied exactly once)")
        for spec in args.applied:
            name, _sep, phrase = spec.partition("::")
            path = Path(name).expanduser()
            text = path.read_text(encoding="utf-8", errors="replace") if path.exists() else None
            count = text.count(phrase) if text is not None and phrase else None
            verdict = "MISSING FILE" if text is None else ("ok" if count == 1 else "CHECK")
            shown = "-" if count is None else count
            out.append(f"  {verdict}  {shown}x  {phrase[:50]!r} in {short(path, projects)}")
    if transcript:
        out += memory_section(transcript, start)
        if args.user or args.user_all:
            out += user_section(transcript, args.user_all)
    elif args.user or args.user_all:
        out.append("== THE USER'S MESSAGES NOT LISTED: no transcript found")
    print("\n".join(out))
    print(f"== scan took {time.monotonic() - began:.1f} s")
    return 0


if __name__ == "__main__":
    sys.exit(main())

# Handoffs and Their Prompts

`SKILL.md` wins wherever the two differ. This file holds the formats and the failure cases behind
Step 5.

## The handoff file

A handoff is a file that lets a fresh chat finish work this chat could not. It goes where the
settings say (default `notes/YYYY_MM_DD_handoff_<topic>.md`) and opens on a STATUS line the scan
can read:

```markdown
# Handoff: <Task Name in Title Case>

STATUS: NOT STARTED (written March 3, 2027 by the chat that <what that chat did>)

## Goal
<one or two sentences: what done looks like>

## State the next chat needs
<the facts this chat learned that the files do not yet show: a rebuilt input, a trap hit, a
choice already made and why>

## Read first
- <file>: <why>

## Steps
1. <first action, concrete enough to start without asking>

## Done means
<the authoritative check that proves it, and the records to update>
```

The chat that picks it up changes the STATUS line to `IN PROGRESS since <date>` at pickup and to
`DONE <date>: <what was produced, where>` at completion, so the next audit can read it.

## Status audit

- **Sources, in order:** the handoff's own STATUS header, then its closing notes, then the to-do
  list or an index. Memory never counts. The scan reads the headers, and the report reads the text
  of any file the scan classes unclear or finds without a header.
- **What the reply lists.** Each handoff still to run, as partially done (with what remains) or
  not yet run. Done and superseded ones appear as counts, except those whose status changed during
  the chat, which are named with when and by which chat.
- **Stamp what the audit finds.** An executed handoff with no stamp gets a DONE header in its own
  file, written on the STATUS line, so the next audit can find it with one search.
- **Projects with many handoffs.** Where a project keeps a list of its handoffs (a file named like
  `handoffs_index.md`), the scan names the newest. A full list rebuilt in the middle of a close is
  stale on arrival, so audit this chat's handoffs and those changed during it, and point at the
  list for the rest.

## Routing findings into open handoffs

A lessons file is read by someone about to write code. A handoff is read by someone about to
decide what to do, which is earlier and is where a wrong plan costs least to stop. So a finding
that would change the plan of a handoff still to run goes into that handoff, in a dated section
of its own, even when it is already filed as a lesson. A finding qualifies when the handoff's
reader, on a cold read tomorrow, would do something this chat now knows is wrong. The three kinds
that keep qualifying:

- a trap this chat hit that the handoff's task will hit too, above all one that fails silently,
  since nothing in the handoff's own run would reveal it
- a convention this chat set that the handoff has to follow, such as a naming rule or an
  environment switch
- a choice this chat already settled that the handoff is about to settle again

An open question goes into the existing handoff that covers it, as a note on the item already
there. The report names each handoff that gained a section. Filing a lesson and routing it are two
acts, and the report keeps them apart.

## The paste-ready prompt

The user pastes the prompt into a fresh chat to run a handoff. Every prompt is printed in the
reply, in its own fenced block, one click to copy: a prompt that exists only in a file is one
the user cannot paste. It does not hold orientation text, since the new chat already reads the
project's folders and `CLAUDE.md`.

```text
<Project> <short task name>: Execute <path to the handoff file>. <The one state fact the new chat needs>.
```

- Two sentences after the label: what to execute (the handoff path), then the one fact the new
  chat needs and the files do not yet make obvious.
- The short task name does not contain a colon, so the label reads cleanly in a chat list.
- When the user picks a model or an effort level per task, end the prompt with the one this task
  needs.
- Several handoffs get one fenced block each, labeled with the handoff it runs.

```text
Village panel district guard in Python: Execute notes/2027_03_03_handoff_python_twin_guard.md. The Stata build already has the guard and its log shows district 17 employment missing in both years, so the Python output must match it.
```

## Sessions, task cards and scheduled tasks

Where the app can start a new session from a task card, offer one for the handoff. A session or a
scheduled task takes work over only when a command run in this turn lists it and the reply names
it (and, for a scheduled task, its next run). An offered card that the user has not started owns
nothing.

## The discharge check

A handoff hands work over only when all three hold, each shown by a command or by the reply in
this turn:

1. **Written.** The file exists now (`ls -l` it) and the reply names its full path. A handoff this
   chat means to write owns nothing.
2. **Printed.** Its prompt appears in this reply, in its own fenced block.
3. **Self-contained.** The prompt names what the next chat executes and the one state fact it
   needs. A prompt that sends the next chat back to this conversation for context hands nothing
   over, and whatever it leaves out stays an open item of this chat.

Three ways the check fails while looking passed:

- **The vague handoff.** "Continue the cleanup" does not name an item or a first action, so it
  takes over nothing. A handoff that takes over an item under Found and not fixed names the specific
  work it takes over.
- **The already-done handoff.** `ls` succeeds on a file stamped DONE. An executed handoff is
  finished work, and anything still open needs a new one.
- **The asserted scheduled task.** A scheduled task or session counts only when a command run in
  this turn lists it.

Work this chat could finish (small, safe, already diagnosed) is finished here: handing it on is
avoidance in the form of a handoff.

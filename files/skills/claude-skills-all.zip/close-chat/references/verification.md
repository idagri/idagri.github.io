# Verification: the Scan, the Checks, the Traps

`SKILL.md` wins wherever the two differ. This file explains how to read `scripts/close_scan.py`
and what "verified" means for each kind of deliverable.

## The scan

| Option | Use |
|------------------|------------------------------------------------------------------|
| `--project DIR` | a folder the chat worked in, repeatable (default: the working folder) |
| `--task REGEX` | every name the finished work goes by (task name, handoff file name, deliverable file name), repeatable |
| `--handoff-pattern REGEX` | what a handoff file's path inside the project folder matches, as the settings record it (default `handoff`, or `^handoffs/` for a handoffs folder) |
| `--user` | passed at every close: the number of summaries, and the user's messages the conversation no longer shows (those a summary replaced and no earlier close swept) |
| `--user-all` | every message the user sent in this chat |
| `--final` | the closing scan: files and lines written, applied-once counts, git |
| `--touched FILE[:FROM-TO]` | a file this chat wrote through a shell command or a script, with this chat's block as a line range |
| `--applied FILE::PHRASE` | counts a distinctive phrase of an edit (1 means it was applied exactly once) |
| `--repo DIR` | another repository to read, without walking it |
| `--counts-only` | the git section as counts, with no file names or commit messages (for sharing scan output) |
| `--session ID`, `--transcript FILE` | the chat's transcript, when it cannot be found |
| `--since 'YYYY-MM-DD HH:MM'` | the chat's start, when no transcript exists |
| `--max N` | lines listed per section (default 12) |

**The transcript.** Claude Code keeps each chat's transcript under `~/.claude/projects/`, in a
folder named after the working folder with every character other than a letter or a digit
replaced by `-`. The scan finds it in this order:

1. the file given with `--transcript`
2. the session id from `--session`, or from the `CLAUDE_CODE_SESSION_ID` variable Claude Code sets
3. in the folder kept for the working folder (or its nearest parent that has one), the most recent
   transcript whose last entries run `close_scan.py`
4. failing that, the most recently active transcript in that folder

The second line of the output says which rule picked it. A line that says "a guess" means two
chats may be active in the same folder: pass `--session`. The chat's start is that transcript's
first timestamp, so "changed during the chat" is a measurement.

A section that could not run prints its reason in capitals (`GIT DID NOT RUN`, `GIT FAILED`,
`WALK STOPPED`, `SESSION START UNKNOWN`, `LIVE-RUN CHECK DID NOT RUN`), and the report calls that
item not checked.

**Section by section:**

- **Rules, `CLAUDE.md` files and skills changed.** The user-level `CLAUDE.md` and
  `~/.claude/rules/`, every `CLAUDE.md` from each project folder up to the home folder, and the
  skills in `~/.claude/skills/` and the project's `.claude/skills/`. Under a changed file the scan
  prints its lines dated inside the chat's window (dates written `YYYY-MM-DD`). Read those, and the
  file itself wherever they leave the new rule unclear.
- **Files this chat wrote.** Read from the Write and Edit results in the transcript, subagents
  included. "created" appears only where the Write result said so, since a file saved through a
  temporary copy and a rename (the Edit tool saves that way) gets a new creation time at every
  save. Each file shows the lines this chat wrote: the whole file for one written with Write, the
  lines where each Edit's new text stands now for an edited one, the uncommitted added lines for a
  tracked file with no record, or a note when none can be located. Files written through a shell
  command or a script are absent until passed with `--touched`. MISSING NOW means renamed, moved or
  deleted since, often by another chat: find where it lives now and report that path.
- **Handoffs.** Files whose path inside the project matches the handoff pattern. Listed first:
  every handoff changed during this chat, whatever its status (a done
  one usually means another chat executed it). Then those still to run, newest first. The first
  status word after STATUS decides the class, since headers go on to instruct ("NOT STARTED.
  Stamp IN PROGRESS at pickup"), and a DONE followed by an open word counts as partial. A file
  classed unclear or without a header is listed, and the report reads its text.
- **Live runs.** Script names found in the open handoffs, matched against running processes, plus
  any Python, Stata, R, Julia, MATLAB or LaTeX process running inside the project. A match means a
  handoff may be mid-run in another chat: check it before printing a prompt that launches it.
- **Mentions of the finished work.** Lines marked `!` sit beside a pending marker (NOT RUN, OWED,
  TODO, an unchecked `[ ]` box) and are the candidates for a pointer to the deliverable. The rest
  is context.
- **Sync-conflict copies.** A file a sync service saved beside the original when two edits
  collided. One made during the chat can hold an edit the service set aside.
- **Git.** "This chat's files" come from the transcript and `--touched`. "Other files changed
  during the chat" belong to another chat or to the user, unless this chat wrote them through a
  shell command or deleted them. Older uncommitted files are counted and left as they are. Every git
  command the scan runs reads only, with `GIT_OPTIONAL_LOCKS=0` so `git status` does not refresh
  the index.
- **Claude memory.** Memory files in the project's folder under `~/.claude/projects/` changed
  during the chat.
- **The user's messages.** The header counts the summaries (compactions) the chat had. Only the
  messages a summary replaced since the last verdict are listed, since the rest are still in the
  conversation.

## Authoritative checks

The check is the thing that fails when the work is wrong. "The file exists", "the edit applied"
and "it looked right" are proxies.

| Deliverable | Check |
|--------------------|------------------------------------------------------------|
| LaTeX document | `pdflatex` twice, plus `bibtex` when it cites, then open the PDF |
| Document with tables | open the PDF and look at every table |
| Stata do-file | re-run it and read the log: a batch run can exit 0 after the do-file stopped, so search the log for lines starting `r(` and check that each output file's time moved |
| R or Python script | run it and read its output (`py_compile` proves syntax and nothing more) |
| Notebook | restart and run every cell in order |
| Config or JSON | load it with a parser (for JSON, `python3 -m json.tool` on the file) |
| Hook or automation | trigger it and read what it produced |
| A number in prose | find the file the producing script wrote it to, and compare |

A check that could not run is its own line in the report: `NOT verified: <why>`.

## Applied exactly once

`--applied FILE::PHRASE` counts matches. By hand, count with `grep -o PHRASE FILE | wc -l`, since
`grep -c` counts matching lines and under-counts two hits on one line.

## Concurrency and git traps

- **"Clean" can mean git did not run.** A failed git command prints nothing on standard output,
  and a helper that ignores the exit code reads that as a clean tree, or as a folder outside any
  repository. The scan checks `git --version` first and prints `GIT DID NOT RUN` when git cannot
  run at all, and `GIT FAILED` when one repository's command fails. On macOS, an Xcode update with its license not yet accepted stops `/usr/bin/git` (the
  scan falls back to the Command Line Tools binary) and `/usr/bin/python3` (run the scan with
  another Python 3.9 or later).
- **Files lag live chats.** Before calling a handoff not running, read the live-run line. A
  handoff being executed gets `IN PROGRESS since <date>` on its STATUS line, replaced by DONE at the
  end, so a second chat does not start it again.
- **A sync service can revert a fresh edit.** When a change has vanished, look for a
  sync-conflict copy before redoing the work, and re-read a file before believing a write was
  applied.
- **Another chat may commit this chat's change.** Report the commit as theirs.
- **Another chat's lines inside a file this chat edited.** Read the whole diff of the file before
  committing, commit the lines together, and name the other lines in the commit message and the
  report. Files only other chats changed stay unstaged.
- **A project outside git.** Say so, and say where the work is backed up. A "clean tree" report for
  a folder with no repository is false.

## Reporting

State each check in the user's terms. "Re-read the handoff headers and TODO.md at the close" tells
the user what happened. "Grepped the trackers" does not.

# Rules for Your CLAUDE.md

Paste the block below into the `CLAUDE.md` Claude reads in every chat: `~/.claude/CLAUDE.md` for
all your projects, or a project's own `CLAUDE.md` for one. The skill does the close. These rules
make every chat keep its record in files from the first message, so the close has little left to
rescue. Edit the file names to match your project.

```markdown
## Records and closing a chat

- Nothing lives only in the chat. Every finding, number, decision, cause and corrected error goes into a project file (TODO.md, a dated note in notes/, or this file) before the reply that reports it. A number quoted in a reply must be quotable from a file.
- A status is a verdict: "Done", "NOT verified: <why>", "NOT done: <what is missing>". Never "should be fine", "looks right" or "probably".
- Every decision rests on a check made at that moment: re-read the file, re-run the count. A memory or an earlier read says where to look, and the check says what is true now.
- A lesson I teach (a preference, a correction, a rule) is written into its permanent home (this file or my lessons file) in the same chat. A handoff or a note is never the home for one.
- A drop in the number of observations I did not ask for is reported, with what left, how much, and whether it can be recovered.
- Work handed to a later chat goes into notes/YYYY_MM_DD_handoff_<topic>.md with a STATUS line, and its paste-ready prompt is printed in the reply.
- When I say "are we done", "close this off", "wrap up" or "can I close this chat", use the close-chat skill, every time, however short the chat.
- A close ends on two lines: "This chat is closed." or "This chat is NOT closed:" plus what is outstanding, then "Safe to close this window: yes" or "no" plus why. A handoff written to a file with its prompt printed counts as handed over.
- Nothing is sent, posted or submitted at a close. A message I still owe someone is left as a draft.
```

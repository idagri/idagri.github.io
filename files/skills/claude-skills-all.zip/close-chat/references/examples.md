# Example: One Close-Off on an Invented Project

The project is a teaching sandbox: 500 simulated villages in 50 districts, observed in 2000 and
2010, with a Stata build that sums village population and employment to the district. The chat
being closed added a guard after the district collapse. Every name, number, commit id and date
below is a placeholder.

## First run

No settings file exists, so the close opens with two question cards (four questions, then the
rules block). The project's `CLAUDE.md` states writing rules for comments, so the style check
recommends them. The user picks the recommended answer to each question:

- Records: `TODO.md`, dated notes in `notes/`, lessons in `CLAUDE.md`
- Handoffs: `notes/YYYY_MM_DD_handoff_<topic>.md`, scan pattern `handoff`
- Git at the close: commit this chat's files and push
- Style check: the writing rules in `CLAUDE.md`
- Rules block: yes, in `~/.claude/CLAUDE.md`, added after the block was shown

Claude saves `~/.claude/close-chat/settings.md`, shows it, and goes on to Step 1.

## The scan, abridged

```text
== files this chat wrote: 4
  updated  village-panel/2_dofile_review/build_district_totals.do  [lines 31-38: where this chat's edits stand now]
  created  village-panel/notes/2027_03_03_district_guard.md  [written whole]
  updated  village-panel/TODO.md  [lines 3-7: where this chat's edits stand now]
  created  village-panel/notes/2027_03_03_handoff_python_twin_guard.md  [written whole]
== handoffs: 1 found (1 open)
    [open] village-panel/notes/2027_03_03_handoff_python_twin_guard.md  STATUS: NOT STARTED (written March 3, 2027 ...
== mentions of the finished work (guard after the district collapse): 3 line(s) in 2 file(s), 1 beside a pending marker (marked !)
  ! village-panel/notes/2027_02_10_district_totals_build.md:9  - The guard after the district collapse is not written yet (the open item in `TODO.md`)
```

The `!` line is a stale marker: an older note still lists the guard as not written. Step 3 marks
it superseded with a pointer to the new note.

## The reply

Settings: records in TODO.md and notes/, handoffs as notes/YYYY_MM_DD_handoff_topic.md, commit and
push, style check from CLAUDE.md.

Re-read at the close: TODO.md, both notes, the handoff's STATUS line, the newest log of the Stata
build, and `git status` of the project.

| Step | Result |
|-------------|----------------------------------------------------------------------|
| Scan | 4 files written by the first scan, 1 handoff not started, 1 stale line found and marked, no summary |
| Deliverable | build re-run: no `r(` line in the log, both output files rewritten at 14:52, 100 district-years |
| Documents | 8 written, each edit applied exactly once |
| Capture | 3 statements of yours: 2 already in the note, 1 added to the conventions file |
| Handoffs | 1 written, prompt printed below |
| Style | 0 hits on the lines this chat wrote |
| Git | 2 commits pushed, HEAD matches origin/main |

**Documents**

1. `2_dofile_review/build_district_totals.do`, updated: the collapse also counts employment per
   district, sets the sum to missing where that count is 0, and asserts 50 districts in each year.
2. `notes/2027_03_03_district_guard.md`, created: the guard, the run, and why district 17 is missing.
3. `TODO.md`, updated: the guard moved to Done, the Python twin added as open.
4. `notes/2027_03_03_handoff_python_twin_guard.md`, created: the same guard for the Python build,
   still to run.
5. `notes/2027_02_10_district_totals_build.md`, updated: the "not written yet" line marked
   superseded, with a pointer to the new note.
6. `CLAUDE.md`, updated: your rule that every collapse prints how many groups it returned.
7. `~/.claude/close-chat/settings.md`, created at the first run: your answers to the setup questions.
8. `~/.claude/CLAUDE.md`, updated at the first run: the records-and-closing rules block.

**Handoffs**

One still to run (STATUS: NOT STARTED):

```text
Village panel district guard in Python: Execute notes/2027_03_03_handoff_python_twin_guard.md. The Stata build already has the guard and its log shows district 17 employment missing in both years, so the Python output must match it.
```

**Done**

1. The district build now stops when a year holds other than 50 districts or when an all-missing
   district would sum to 0. Verified at the close: the do-file re-ran, its log has no `r(` line,
   and both files in `processed/` were rewritten at 14:52.
2. District 17 employment is missing in 2000 and 2010, where it was 0 before the guard, so the
   employment rate covers 98 of 100 district-years. It cannot be recovered from this data: the
   employment module was not fielded there, and none of its 10 villages has a value.
3. Corrected a mistake of this chat: the first guard asserted 50 rows over both years together
   and stopped a correct build. It now counts districts within each year. No undo is needed,
   since the corrected guard replaced the first one in the same file.
4. Decided: the guard stops the build with an `assert`, because every table is built from the
   district file, and a warning in a long log is easy to miss.
5. Lesson recorded in the Stata lessons file the settings name: after a collapse by two keys,
   count the groups within each value of the second key, since `_N` counts both together. A
   checklist line was added with it.

**Found and not fixed**

1. The Python twin `build_district_totals.py` sums with `groupby().sum()` and no `min_count=1`, so
   district 17 employment still comes out as 0 there.
   Next step: `notes/2027_03_03_handoff_python_twin_guard.md`, written, with its prompt above.

**Needs you**

1. In the employment-rate table, does district 17 appear with a dash and a note, or is it dropped?
   Recommendation: show it with a dash and the note "employment module not fielded", because the
   reader then sees the gap and the table keeps all 50 districts.

This chat is NOT closed: question 1 under Needs you is unanswered.
Safe to close this window: no, your answer decides the table, and it is quickest to apply here.

## The Second Close

The user picks the dash and the note. The chat adds the note to the table, re-runs the table
producer and reads its output, then runs the whole close again, since files can move between two
closes. The second reply is shorter, and its last lines read:

**Needs you**

none

This chat is closed.
Safe to close this window: yes, the Python guard is handed over in a written handoff with its
prompt printed, and no other item waits on this conversation.

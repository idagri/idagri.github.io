#!/usr/bin/env python3
# TEMPLATE: a parser for a static program page that holds every session in its own element. For
# another host, keep the two guards and the output fields and rewrite the patterns. Copy it into the
# conference folder as parse_<conf>_program.py

# Parses a program page laid out as below (static HTML, every abstract on the page) into one JSON list of
# sessions, each with its code, day, start, end, room, chair and talks in program order
#
# Each session is a <div id="s_NN"> holding a header "Month DD, YYYY H:MM to H:MM (Location: X)",
# the code and title in <strong>, a Chair line, and one <li> per talk with the authors, the title in
# <strong>, "Presented by NAME (AFFILIATION)", an optional "Discussed by", and the abstract inside a
# <details> block. Two guards: a block ends at its own </ul>, since the page footer otherwise parsed
# as a fifth talk in the last session, and every talk must have a title and a presenter

import html
import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "<live program copy>.html"
OUT = HERE / "<YYYY_MM_CONF>_program_parsed.json"


def clean(s):
    s = re.sub(r"<[^>]+>", "", s)
    return re.sub(r"\s+", " ", html.unescape(s)).strip()


raw = SRC.read_text(encoding="utf-8", errors="replace")
blocks = re.split(r"<div id=\"(s_\d+)\"", raw)
sessions = []
DROPPED = []
for i in range(1, len(blocks), 2):
    b = blocks[i + 1]
    head = re.search(r"<p class='underline'[^>]*>(.*?)</p>", b, re.S).group(1)
    parts = re.split(r"<br\s*/?>", head)
    when, title = clean(parts[0]), clean(parts[1]) if len(parts) > 1 else ""
    day, start, end, room = re.match(
        r"([A-Z][a-z]+ \d+), \d{4} (\d+:\d+) to (\d+:\d+) \(Location: (.*)\)", when).groups()
    chair = re.search(r"<p>Chair:(.*?)</p>", b, re.S)
    body = b.split("</ul>")[0]
    talks = []
    for li in re.split(r"<li>", body)[1:]:
        li = li.split("</li>")[0]
        t = re.search(r"<strong>(.*?)</strong>", li, re.S)
        pres = re.search(r"Presented by (.*?)(?:<br>|<details|$)", li, re.S)
        disc = re.search(r"Discussed by (.*?)(?:<br>|<details|$)", li, re.S)
        ab = re.search(r"<summary[^>]*>Abstract</summary><p[^>]*>(.*?)</p>", li, re.S)
        talk = dict(authors=clean(li.split("<br>")[0]), title=clean(t.group(1)) if t else "",
                    presenter=clean(pres.group(1)) if pres else "",
                    discussant=clean(disc.group(1)) if disc else "",
                    abstract=clean(ab.group(1)) if ab else "",
                    links=[html.unescape(u) for u in re.findall(r"href='([^']+)'", li)])
        if talk["title"] and talk["presenter"]:
            talks.append(talk)
        else:
            DROPPED.append((title, talk["authors"][:40]))
    sessions.append(dict(sid=blocks[i], day=day, start=start, end=end, room=room, code=title.split(".")[0],
                         title=title, chair=clean(chair.group(1)) if chair else "", talks=talks))

OUT.write_text(json.dumps(sessions, indent=1, ensure_ascii=False), encoding="utf-8")
print(f"sessions: {len(sessions)}   talks: {sum(len(s['talks']) for s in sessions)}")
# every dropped entry is reported; read each one before trusting the parse
for d in DROPPED:
    print("dropped an entry with no title or presenter:", d)

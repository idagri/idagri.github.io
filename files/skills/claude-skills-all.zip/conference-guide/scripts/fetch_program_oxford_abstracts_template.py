#!/usr/bin/env python3
# TEMPLATE: fetches a whole program from Oxford Abstracts (virtual.oxfordabstracts.com/event/<id>), whose page
# is drawn by script, through its public GraphQL service with the anonymous event token, with no browser and
# no sign-in. Copy it into the conference's conf_guide/ folder as fetch_<conf>_program.py and run
#   python3 fetch_<conf>_program.py <event id> [output folder]
# It writes oa_program_<event id>_<YYYY_MM_DD>.json (the raw answer, with its download date) and prints the
# number of sessions and papers. The query asks for each session's date, times, track, type, room, chairs and
# invited speakers, and its papers in display order with their authors (a presenting flag and affiliations)
# and their form answers. The title and the abstract are answers to named questions ("Paper title",
# "Abstract"), so read the question names off one record before writing the parser
# This template was checked against saved answers of the service only. If a request fails, open the
# program page in a browser and compare these two addresses with the ones the page itself calls

import datetime
import json
import sys
import urllib.request
from pathlib import Path

ORIGIN = "https://virtual.oxfordabstracts.com"
QUERY = """query full_program {
  program_sessions(order_by: [{program_date: {program_date: asc}}, {start_time: asc}]) {
    id name description start_time end_time
    program_date { program_date }
    program_track { name }
    program_type { name }
    program_sessions_program_columns { program_column { id name display_order } }
    program_sessions_chairs { session_chair { title first_name last_name } }
    speakers(order_by: [{start_time: asc_nulls_last}, {display_order: asc}]) {
      speaker { submission { speaker_affiliations { affiliation } speaker_name { first_name last_name } } }
      speaker_role { label_singular }
    }
    program_sessions_submissions(order_by: {display_order: asc}) {
      display_order start_time end_time
      submission {
        id serial_number
        authors { first_name middle_initial last_name presenting affiliations { institution } }
        responses { value question { question_name } }
      }
    }
    program_sessions_symposia {
      symposium { submissions { id serial_number symposium_order
        authors { first_name last_name presenting affiliations { institution } }
        responses { value question { question_name } } } }
    }
  }
}"""


def post(url, payload, headers):
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), method="POST",
                                 headers=dict({"content-type": "application/json", "origin": ORIGIN}, **headers))
    with urllib.request.urlopen(req, timeout=120) as r:
        return json.load(r)


def main():
    if len(sys.argv) < 2:
        sys.exit("usage: fetch_<conf>_program.py <event id> [output folder]")
    event = sys.argv[1]
    if not event.isdigit():
        sys.exit(f"the event id is the number in virtual.oxfordabstracts.com/event/<id>, not {event!r}")
    out = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(__file__).resolve().parent
    # the anonymous event token, which the public program page itself uses
    answer = post(f"https://app.oxfordabstracts.com/api/virtual/events/{event}/hasura-authenticate-event-tokens",
                  {}, {})
    token = (answer.get("publicEvent") or {}).get("token")
    if not token:
        sys.exit(f"event {event} gave no public token: the program may be private or not yet published")
    res = post("https://graphql.oxfordabstracts.com/v1/graphql",
               {"operationName": "full_program", "variables": {}, "query": QUERY},
               {"authorization": "Bearer " + token})
    if res.get("errors"):
        sys.exit("the service answered with errors: " + json.dumps(res["errors"])[:800])
    sessions = res["data"]["program_sessions"]
    papers = sum(len(s["program_sessions_submissions"]) for s in sessions)
    path = out / f"oa_program_{event}_{datetime.date.today():%Y_%m_%d}.json"
    path.write_text(json.dumps(res, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"sessions: {len(sessions)}   papers: {papers}   wrote {path}")


if __name__ == "__main__":
    main()

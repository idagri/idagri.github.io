#!/usr/bin/env python3
# TEMPLATE: gathers the per-block ranking files the agents write into agents/ (rank_block_<b>.json,
# then the re-rank's rank2_block_<b>.json, which replaces a block when it arrives) into one rank data
# file the grid and plan builders read, and the per-block abstract files, when the agents fetched
# any, into one abstracts file. It also writes the builders' copy of the program, with every
# spelling correction applied, and applies every fix file. Set the SETTINGS block and copy it into
# the conference's conf_guide/ folder as merge_<conf>_rank.py
#
# Habits it keeps, each from something that went wrong once:
#   - the block number comes from the FILE NAME, since an agent once wrote a sentence into "block"
#   - a talk the program does not have is dropped, since a page footer once parsed as a fifth talk
#   - every block must rank every talk the program lists, once, or the merge stops
#   - a presenter written with the affiliation in parentheses is cut to the name, since the builders
#     match names exactly (the user's own talk, the people tags)
#   - a spelling correction is applied to EVERY name field (authors, presenter, discussant, chair, and the
#     presenter in the rank files), since one applied only to the authors left the misspelled
#     presenter in place and the table listed the presenter as a coauthor of themselves; the parsed
#     program stays as the parser wrote it, so a rerun of the parser still reproduces it
#   - a parenthesis inside an affiliation is flattened to a comma, so both builders read the last
#     parenthesis as the affiliation ("Institute of Applied Economic Research (IPEA), Brazil" once printed
#     whole as a name)
#   - an invited session that lists several speakers and no talk times is split evenly among them
#     (SPLIT), so the path can reach a later speaker
#   - at most COFFEE_PER_DAY own-coffee windows a day survive, the ones over the least relevant
#     stretches; a BREAK stop with a label is a meeting of the user's own and is never dropped
#   - every fix from an independent check, and every ruling of the user's written as a fix file, is read
#     from its file in agents/ and applied HERE, as data, so a rebuild keeps it; a fix asserts its
#     target and its old value, and a fix the session does not take goes in DECLINED with its reason
#   - when the user's profile puts mentoring and career events first, each event in <PREFIX>_career_events.json is
#     Option 1 in its slot and the best research stop it displaces is Option 2, applied last by career_events.py,
#     since a mentoring workshop ranked as one more session was once left off the path. The user's own slots and
#     meetings are never displaced

import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# ---------------------------------------------------------------------------------------------
# SETTINGS: the only values that change per conference
# ---------------------------------------------------------------------------------------------
PREFIX = "<YYYY_MM_CONF>"
# the user's name as the program prints it: a mentoring or career event never takes the path from a talk the user
# presents, discusses or chairs, and the rank data keeps the user's own talk at its relevance tier, so the name is how
# it is found
ME = "<YOUR NAME AS THE PROGRAM PRINTS IT>"
# True when the user's clock format is the 24-hour clock, for the sentences the career override writes, as in both
# builders
CLOCK_24 = False
# spelling corrections to the program, (as printed, corrected), each recorded in the conference notes
NAME_FIX = [
    # ("<Misspelled Name>", "<Corrected Name>"),
]
# an invited session listing several speakers with no talk times, split evenly in the program's order: code to
# the speakers, each "Name (Affiliation)" (the second speaker of a lecture can be the one on the user's path)
SPLIT = {
    # "<code>": ["<Speaker One (Affiliation)>", "<Speaker Two (Affiliation)>"],
}
# True when the user asks for more break space:
# every big parallel block may keep its own coffee window, up to two a day, and a block with no talk tier 1 or
# better is marked as a lighter slot (skip_ok); False keeps one window a day
MORE_BREAKS = False
COFFEE_PER_DAY = 2 if MORE_BREAKS else 1
# fixes from the independent checks the session does not take, each with its reason, keyed
# (block, code, order, field) as in the fix file; a block-level field has code "" and order None
DECLINED = {
    # ("<b>", "<code>", <order>, "tier"): "<why the fix was not taken>",
}

AG = os.path.join(HERE, "agents")
OUT = os.path.join(HERE, f"{PREFIX}_grid_rank.json")
PROGRAM = os.path.join(HERE, f"{PREFIX}_program_parsed.json")
BUILDERS = os.path.join(HERE, f"{PREFIX}_program_builders.json")


def mins(hm):
    h, m = map(int, hm.split(":"))
    return h * 60 + m


def hm(t):
    return f"{int(t) // 60:02d}:{int(t) % 60:02d}"


def name_of(field):
    # "Name (Affiliation)" to "Name": the affiliation is the LAST parenthesis, since a name can hold
    # one of its own, as in "Ana (Nina) Ruiz (University of Example)"
    m = re.match(r"^(.*)\s\(([^()]*)\)\s*$", field.strip())
    return m.group(1).strip() if m else field.strip()


def split_last_paren(field):
    # (name, affiliation) with the affiliation the last BALANCED parenthesis, so a nickname stays in the
    # name and a parenthesis inside the affiliation stays in the affiliation
    s = field.strip()
    if not s.endswith(")"):
        return s, ""
    depth = 0
    for i in range(len(s) - 1, -1, -1):
        depth += {")": 1, "(": -1}.get(s[i], 0)
        if depth == 0:
            return s[:i].strip(), s[i + 1:-1].strip()
    return s, ""


def split_speakers(field):
    # "A (x); B (y)" into its speakers, splitting only at a semicolon outside every parenthesis
    parts, depth, cur = [], 0, ""
    for ch in field:
        depth += {"(": 1, ")": -1}.get(ch, 0)
        if ch == ";" and depth == 0:
            parts.append(cur)
            cur = ""
        else:
            cur += ch
    return [x.strip() for x in parts + [cur] if x.strip()]


def flat_presenter(field):
    # every parenthesis inside an affiliation flattened to a comma, so both builders read the last parenthesis
    # as the affiliation; several speakers "A (x); B (y)" become "A and B (x, y)"
    names, affs = [], []
    for part in split_speakers(field):
        nm, aff = split_last_paren(part)
        names.append(nm)
        aff = re.sub(r"\s*\(([^()]*)\)", r", \1", aff).replace("(", "").replace(")", "").strip()
        if aff:
            affs.append(aff)
    nm = " and ".join(names) if len(names) == 2 else ", ".join(names)
    return f"{nm} ({', '.join(affs)})" if affs else nm


# the builders' copy: the parsed program with SPLIT applied, every correction in every name field, and
# each presenter's affiliation flattened
program = json.load(open(PROGRAM))
session_title = {}
for s in program:
    if s["code"] in SPLIT:
        a, e, n = mins(s["start"]), mins(s["end"]), len(SPLIT[s["code"]])
        base = s["talks"][0] if s["talks"] else {"authors": "", "presenter": "", "title": "", "discussant": "",
                                                  "abstract": "", "links": []}
        session_title[s["code"]] = s["title"]
        s["talks"] = [dict(base, presenter=pr, authors=name_of(pr), title=f"{s['title']}: {name_of(pr)}",
                           start=hm(a + (e - a) * i // n), end=hm(a + (e - a) * (i + 1) // n))
                      for i, pr in enumerate(SPLIT[s["code"]])]
used = {wrong: 0 for wrong, _ in NAME_FIX}
for s in program:
    fields = [(s, "chair")] + [(t, k) for t in s["talks"] for k in ("authors", "presenter", "discussant")]
    for obj, k in fields:
        for wrong, right in NAME_FIX:
            if wrong in obj.get(k, ""):
                obj[k] = obj[k].replace(wrong, right)
                used[wrong] += 1
    for t in s["talks"]:
        t["presenter"] = flat_presenter(t["presenter"])
        # each author's own affiliation, when the parser records one (affils), filed under the corrected name, so
        # a coauthor the user marked is named with it
        if t.get("affils"):
            fixed = {}
            for nm, aff in t["affils"].items():
                for wrong, right in NAME_FIX:
                    nm = nm.replace(wrong, right)
                fixed[nm] = aff
            t["affils"] = fixed
for wrong, n in used.items():
    print(f"spelling fix {wrong!r}: {n} fields" if n else f"spelling fix not needed, no field holds {wrong!r}")
json.dump(program, open(BUILDERS, "w"), indent=1, ensure_ascii=False)

blocks = {}
for pattern in ["rank_block_*.json", "rank2_block_*.json"]:
    for f in sorted(glob.glob(os.path.join(AG, pattern))):
        b = os.path.basename(f).split("_")[-1][:-5]
        d = json.load(open(f))
        d["block"] = b
        blocks[b] = d
print("blocks:", sorted(blocks))

P = {s["code"]: s for s in program}
# a code is the block number plus ONE room letter; a 27th room takes a lowercase letter
BLOCK_OF = {code: code[:-1] for code in P}


def listed_in(b):
    return {(c, i) for c in P if BLOCK_OF[c] == b for i in range(len(P[c]["talks"]))}


for b, r in blocks.items():
    # a split session ranked as one talk becomes one talk per speaker, each with the session's tier and why
    for code, speakers in SPLIT.items():
        one = [t for t in r["talks"] if t["code"] == code]
        if BLOCK_OF.get(code) == b and len(one) == 1:
            r["talks"] = [t for t in r["talks"] if t["code"] != code] + [
                dict(one[0], order=i, presenter=name_of(pr), title=session_title.get(code, one[0]["title"]))
                for i, pr in enumerate(speakers)]
    for t in r["talks"]:
        t["presenter"] = re.sub(r"\s*\([^()]*\)\s*$", "", t["presenter"]).strip()
        for wrong, right in NAME_FIX:
            t["presenter"] = t["presenter"].replace(wrong, right)
    r["talks"] = [t for t in r["talks"] if t["code"] in P and t["order"] < len(P[t["code"]]["talks"])
                  and t["presenter"]]
    r["path"] = [st for st in r["path"] if st["code"] == "BREAK"
                 or (st["code"] in P and st["order"] < len(P[st["code"]]["talks"]))]
    ranked = [(t["code"], t["order"]) for t in r["talks"]]
    assert len(ranked) == len(set(ranked)), (b, "a talk ranked twice")
    assert listed_in(b) <= set(ranked), (b, sorted(listed_in(b) - set(ranked))[:5])


def talk(b, code, order):
    t = [x for x in blocks[b]["talks"] if x["code"] == code and x["order"] == order]
    assert len(t) == 1, (b, code, order)
    return t[0]


def apply(obj, name, old, new):
    # a fix already in place is skipped; any other mismatch with its old value stops the merge, since
    # the fix was written against a ranking that has since changed; a field the block lacks reads as None
    if obj.get(name) == new:
        return False
    assert obj.get(name) == old, ("stale fix, the old value is gone", name, old, obj.get(name))
    obj[name] = new
    return True


# fixes, one file per check or ruling, applied in file-name order: the checks' files (agents/review_ranking.json
# from the ranking reviewer, agents/review_path.json from the path check), then the user's rulings in later-sorting
# files (review_zz_<topic>.json, review_zzz_<topic>.json), each written by a small script from the merged state.
# Each file is {"fixes": [{block, code, order, field, old, new, reason}]}. field is a talk's tier, why or
# project (code and order name the talk); a block's plan, gives_up, coffee_note, main_room, path, rooms_to_show,
# backups or skip_ok (code "", order None); "alternative" (code and order name the stop; new is the why, or a
# dict of the fields that change, with old a dict of their old values; new None removes the alternative, old
# None adds one); or "backup" (code names the backup room; new is its note; old None adds the room)
REVIEW = []
for f in sorted(glob.glob(os.path.join(AG, "review_*.json"))):
    REVIEW += [dict(fx, file=os.path.basename(f)) for fx in json.load(open(f)).get("fixes", [])]
seen_declined, applied, in_place = set(), 0, 0
for fx in REVIEW:
    b, field = str(fx["block"]), fx["field"]
    key = (b, fx.get("code") or "", fx.get("order"), field)
    if key in DECLINED:
        seen_declined.add(key)
        continue
    r = blocks[b]
    if field in ("tier", "why", "project"):
        done = apply(talk(b, fx["code"], fx["order"]), field, fx["old"], fx["new"])
    elif field in ("plan", "gives_up", "coffee_note", "main_room", "path", "rooms_to_show", "backups", "skip_ok"):
        done = apply(r, field, fx["old"], fx["new"])
    elif field == "alternative":
        # a fix that moves an alternative to a new stop (after a path fix earlier in the list) is found by
        # its OLD stop, given in old as a dict, else by the stop the fix names (a lookup by the new stop
        # found nothing and stopped the merge)
        o, n = fx.get("old"), fx["new"]
        sc, so = (o["stop_code"], o["stop_order"]) if isinstance(o, dict) and "stop_code" in o else (fx["code"], fx["order"])
        alts = r.setdefault("alternatives", [])
        a = [x for x in alts if x["stop_code"] == sc and x["stop_order"] == so]
        if n is None:
            # the stop left the path or became a meeting: remove its alternative
            done = bool(a)
            r["alternatives"] = [x for x in alts if x not in a]
        elif o is None:
            # an alternative the agent left out, or one for a stop the path gained, added by the fix
            add = dict({"stop_code": sc, "stop_order": so}, **n)
            assert not a or a == [add], ("stale fix, the stop already has another alternative", fx)
            done = not a
            if done:
                alts.append(add)
        else:
            assert len(a) == 1, ("no alternative at that stop", fx)
            if isinstance(n, dict):
                done = any([apply(a[0], k, o.get(k), v) for k, v in n.items()])
            else:
                done = apply(a[0], "why", o, n)
    elif field == "backup":
        bk = [x for x in r.setdefault("backups", []) if x["code"] == fx["code"]]
        if not bk and fx.get("old") is None:
            r["backups"].append({"code": fx["code"], "note": fx["new"]})
            done = True
        else:
            assert len(bk) == 1, ("the block has no backup room with that code", fx)
            done = apply(bk[0], "note", fx["old"], fx["new"])
    else:
        raise SystemExit(f"fix field not handled, add it to this script: {fx}")
    applied += done
    in_place += not done
for key in DECLINED:
    if key not in seen_declined:
        print("DECLINED entry matches no fix in the fix files:", key)
print(f"review fixes: {applied} applied, {in_place} already in place, {len(seen_declined)} declined, "
      f"of {len(REVIEW)}")
for key in sorted(seen_declined, key=str):
    print("  declined:", key, DECLINED[key])

# after the fixes, every path stop and every alternative still names a talk the program has, and a meeting of
# the user's own (a BREAK stop with a label) has no alternative
for b, r in blocks.items():
    have = listed_in(b)
    for st in r["path"]:
        assert st["code"] == "BREAK" or (st["code"], st["order"]) in have, (b, "path stop not in the program", st)
    for a in r.get("alternatives", []):
        assert (a["alt_code"], a["alt_order"]) in have, (b, "alternative not in the program", a)
    meet = {st["break_start_min"] for st in r["path"] if st["code"] == "BREAK" and st.get("label")}
    for a in r.get("alternatives", []):
        if a["stop_code"] == "BREAK" and a["stop_order"] in meet:
            print(f"block {b}: the meeting at minute {a['stop_order']} has an alternative; remove it with a fix")


# at most COFFEE_PER_DAY own-coffee windows a day: keep the windows whose overlapped talks have the lowest
# summed tier on the path's own rooms, drop the others and their alternatives, and say which were dropped; a
# meeting of the user's own is never counted or dropped
def window_weight(b, st):
    r = blocks[b]
    tiers = {(t["code"], t["order"]): t["tier"] for t in r["talks"]}
    s0 = next(v for c, v in P.items() if BLOCK_OF[c] == b)
    t0, dur = mins(s0["start"]), mins(s0["end"]) - mins(s0["start"])
    total = 0
    for c in {x["code"] for x in r["path"] if x["code"] != "BREAK"}:
        n = len(P[c]["talks"])
        for i, pt in enumerate(P[c]["talks"]):
            # the talk's own times when the program prints them, else the even split
            if pt.get("start") and pt.get("end"):
                a, e = mins(pt["start"]) - t0, mins(pt["end"]) - t0
            else:
                a, e = dur * i / n, dur * (i + 1) / n
            if a < st["break_end_min"] and e > st["break_start_min"]:
                total += tiers.get((c, i), 0)
    return total


by_day = {}
for b, r in blocks.items():
    day = next(v["day"] for c, v in P.items() if BLOCK_OF[c] == b)
    for st in r["path"]:
        if st["code"] == "BREAK" and not st.get("label"):
            by_day.setdefault(day, []).append((window_weight(b, st), b, st))
for day, wins in by_day.items():
    wins.sort(key=lambda w: w[0])
    for _, b, st in wins[COFFEE_PER_DAY:]:
        r = blocks[b]
        r["path"] = [x for x in r["path"] if x is not st]
        r["alternatives"] = [a for a in r.get("alternatives", [])
                             if not (a["stop_code"] == "BREAK" and a["stop_order"] == st["break_start_min"])]
        print(f"coffee window dropped in block {b} ({day}); rewrite that block's plan and coffee_note")

# with more break space asked for, a block with no talk tier 1 or better is a lighter slot, shown on the cover as
# one to skip; a skip_ok a fix already set is kept as it is
if MORE_BREAKS:
    for b, r in sorted(blocks.items()):
        if "skip_ok" not in r and all(t["tier"] < 1 for t in r["talks"]):
            r["skip_ok"] = True
            print(f"block {b}: no talk tier 1 or better, marked as a lighter slot (skip_ok)")

# mentoring and career events are Option 1 when the user's profile puts them first: with the folder's
# <PREFIX>_career_events.json present, each event's session takes the path for its whole span, and the best research
# stop it displaces becomes its alternative, Option 2 (career_events.py, copied beside this script, does it and says
# what moved). Without that file the rank data is written exactly as before
if os.path.exists(os.path.join(HERE, f"{PREFIX}_career_events.json")):
    sys.path.insert(0, HERE)
    try:
        import career_events
    except ImportError:
        import career_events_template as career_events
    for line in career_events.apply_career_events(blocks, program, career_events.load_career(HERE, PREFIX), me=ME,
                                                  clock24=CLOCK_24):
        print(line)
    # the same checks as after the fixes: every path stop and every alternative still names a talk the program has
    for b, r in blocks.items():
        have = listed_in(b)
        for st in r["path"]:
            assert st["code"] == "BREAK" or (st["code"], st["order"]) in have, (b, "path stop not in the program", st)
        for a in r.get("alternatives", []):
            assert (a["alt_code"], a["alt_order"]) in have, (b, "alternative not in the program", a)

json.dump({"blocks": blocks}, open(OUT, "w"), indent=1, ensure_ascii=False)
print("wrote", OUT, "and", BUILDERS)

# abstracts fetched from papers (only when the program gave none): one file, the checker's verdict kept
abstracts = {}
for f in sorted(glob.glob(os.path.join(AG, "abstracts_block_*.json"))):
    abstracts.update(json.load(open(f)))
if abstracts:
    json.dump(abstracts, open(os.path.join(HERE, f"{PREFIX}_abstracts.json"), "w"), indent=1, ensure_ascii=False)
    print("abstracts:", len(abstracts), " blanked by the checker:",
          sum(a.get("verdict") == "blanked" for a in abstracts.values()))

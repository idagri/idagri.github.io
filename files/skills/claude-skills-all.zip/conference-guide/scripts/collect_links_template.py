#!/usr/bin/env python3
# TEMPLATE: the link collector. Set PREFIX and PROGRAM_URL, then pass the
# workflow records (copy each run's journal.jsonl into agents/ first, as journal_first_run.jsonl and
# journal_rerank.jsonl). Copy it into the conference folder as collect_<conf>_links.py and run
#   python3 collect_<conf>_links.py agents/journal_first_run.jsonl agents/journal_rerank.jsonl
# Run it after the merge, which writes the builders' copy of the program it reads. It takes the first
# run's "verify-links:<b>" results, then the files link agents write when they run outside a workflow
# (agents/links_block_<b>.json, {"links": [...]} in the same fields; run it with no arguments when
# there are no workflow records), fills gaps from the re-rank's "links2:<b>" results, and blanks every
# URL the independent check file (<PREFIX>_links2_check.json, a list of {key, paper_ok, site_ok,
# reason}) rejected. The output is one file keyed "code|order", read by both builders

import html
import json
import sys
import unicodedata
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREFIX = "<YYYY_MM_CONF>"
PROGRAM_URL = "<the live program URL>"
FIELDS = ["presenter", "paper_url", "paper_kind", "site_url", "site_kind", "note"]
# a trial registry page gets its own kind, so the grid labels it a trial registry entry
REGISTRY_HOSTS = ["socialscienceregistry.org", "ridie.3ieimpact.org", "clinicaltrials.gov"]

JOURNALS = [Path(a) for a in sys.argv[1:]]
PROGRAM = {s["code"]: s for s in json.loads((HERE / f"{PREFIX}_program_builders.json").read_text())}
BLOCKS = sorted({code[:-1] for code in PROGRAM if len(code) >= 2})

labels, results = {}, {}
for journal in JOURNALS:
    for line in journal.read_text().splitlines():
        d = json.loads(line)
        if d["type"] == "started":
            labels[d["agentId"]] = d["label"]
        elif d["type"] == "result":
            results[labels.get(d.get("agentId"))] = d.get("result", d.get("value"))
# link agents run outside a workflow write their own file per block
for f in sorted((HERE / "agents").glob("links_block_*.json")):
    b = f.stem.split("_")[-1]
    results.setdefault(f"verify-links:{b}", json.loads(f.read_text()))


def bare_name(name):
    # accents and case dropped, since a link agent once wrote a name without the program's accent and
    # the entry was dropped as a mismatch
    return "".join(ch for ch in unicodedata.normalize("NFKD", name) if not unicodedata.combining(ch)).casefold()


def entry(e):
    # the presenter must match the program at that position, or the link would sit on the wrong box
    prog = PROGRAM[e["code"]]["talks"][e["order"]]["presenter"]
    if not bare_name(prog).startswith(bare_name(e["presenter"].split(" (")[0])[:12]):
        print("presenter mismatch, dropped:", e["code"], e["order"], e["presenter"], "|", prog)
        return None
    x = {k: html.unescape(e.get(k, "")) for k in FIELDS}
    # the paper's coauthors, for a program that prints the presenter only; the plan builder lists them
    x["coauthors"] = [html.unescape(n) for n in e.get("coauthors", [])]
    # a link back to the program itself opens the program's own abstract
    if PROGRAM_URL.split("://")[-1] in x["paper_url"]:
        x["paper_kind"] = "program page"
    if any(h in x["paper_url"] for h in REGISTRY_HOSTS):
        x["paper_kind"] = "registry entry"
    return x


links, missing = {}, []
for b in BLOCKS:
    v = results.get(f"verify-links:{b}")
    if not v:
        missing.append(b)
        continue
    for e in v["links"]:
        x = entry(e)
        if x:
            links[f"{e['code']}|{e['order']}"] = x
# the re-rank's link agents fill gaps; they never replace an entry the first run's verifier passed
for b in BLOCKS:
    for e in (results.get(f"links2:{b}") or {}).get("links", []):
        key = f"{e['code']}|{e['order']}"
        if key in links and links[key].get("site_url"):
            continue
        x = entry(e)
        if x:
            links[key] = x
# an independent agent opened every link no verifier had passed; a rejected URL is blanked here
check = HERE / f"{PREFIX}_links2_check.json"
if check.exists():
    for c in json.loads(check.read_text()):
        e = links.get(c["key"])
        if not e:
            continue
        if c.get("paper_ok") is False:
            e["paper_url"] = ""
            e["note"] = "paper link rejected by the second check: " + c.get("reason", "")
        if c.get("site_ok") is False:
            e["site_url"] = ""
(HERE / f"{PREFIX}_grid_links.json").write_text(json.dumps(links, indent=1, ensure_ascii=False))
papers = sum(bool(x["paper_url"]) for x in links.values())
sites = sum(bool(x["site_url"]) for x in links.values())
print(f"talks with a link entry: {len(links)}   paper links: {papers}   site links: {sites}")
print("registry entries:", sum(x["paper_kind"] == "registry entry" for x in links.values()),
      "  entries with coauthors:", sum(bool(x["coauthors"]) for x in links.values()))
print("blocks with no verified links yet:", missing)

#!/usr/bin/env python3
# TEMPLATE: puts every mentoring or career event on the path as Option 1, when the user's profile says these events
# take priority (SKILL.md, Step 0 and the mentoring section). Without this step a guide once ranked a mentoring
# workshop that was both in the program and in two organizer emails below the research sessions, routed the path
# through two research rooms and a coffee window, and the user missed it. Copy this file into the conference's
# conf_guide/ folder as career_events.py, beside the merge, which imports it under that name
#
# Input, in conf_guide/, written by the session that runs the sweep (program titles and tracks searched for the
# skill's keywords, plus, when the profile allows mail, a read-only search of organizer, association and committee
# mail from about two months before the meeting), and read by the merge and both builders. Without that file every
# script behaves as before:
#   <PREFIX>_career_events.json   {"events": [...], "negatives": {<day>: "Checked the program and mail: no mentoring
#                                 or career event on <day>"}}, each event {code (the program session, or null when
#                                 the event is not a program session), day (the program's day value), start, end
#                                 ("HH:MM"), title, room, mentors [names], eligibility ("open", "application-only",
#                                 "registration form" or "unclear"), register_url, deadline, source ("program",
#                                 "email" or "program + email"), elsewhere [{name, code, role, when}], the program
#                                 sessions where a mentor presents, discusses or chairs, which find_elsewhere() below
#                                 reads off the program}
#
# apply_career_events() changes each ranked block that holds an event with a program code. The merge calls it just
# before it writes the rank data. Run alone (main below), it rewrites an already-merged rank data file, so a folder
# merged before the user turned the preference on gets it too. For each event:
#   - the path takes the event session for its whole time span, all of its talks
#   - the old path stops overlapping that span leave the path, and the best of them (highest tier, then earliest)
#     becomes the event stop's alternative, its why opening "Option 2"
#   - the old alternatives of those stops and any coffee window overlapping the span are dropped
#   - the user's own slot (the user presents, discusses or chairs) and the user's own meetings (a BREAK stop with a
#     label) are never overridden: the block keeps its path and a warning is printed. The user's name (ME in the
#     merge, --me run alone) is required, since the rank data keeps the user's own talk at its relevance tier
#   - the event's room and the Option 2 room join rooms_to_show, five rooms at most, the extra room of lowest value
#     dropped first (old path rooms before others, then the best tier, then the count of starred talks)
#   - the block is marked with career, one sentence naming Option 1 opens the plan, and one sentence naming the
#     must-sees Option 1 gives up opens gives_up

import json
import os
import re
import sys
import unicodedata

ELIGIBILITY = ("open", "application-only", "registration form", "unclear")
# the eligibility as a phrase inside the plan sentence
ELIG_PLAN = {"open": "open to all attendees", "application-only": "by application only",
             "registration form": "register on its form first", "unclear": "check access first"}
MAX_ROOMS = 5


def career_path(folder, prefix):
    return os.path.join(folder, f"{prefix}_career_events.json")


def load_career(folder, prefix):
    # the career events file, or None when the folder has none. Every event is checked for the fields the
    # builders read
    p = career_path(folder, prefix)
    if not os.path.exists(p):
        return None
    with open(p, encoding="utf-8") as fh:
        d = json.load(fh)
    for e in d.get("events", []):
        for k in ("day", "start", "end", "title"):
            assert e.get(k), ("career event without " + k, e)
        assert e.get("eligibility") in ELIGIBILITY, ("eligibility must be one of " + ", ".join(ELIGIBILITY), e)
        assert re.match(r"^\d\d:\d\d$", e["start"]) and re.match(r"^\d\d:\d\d$", e["end"]), ("times as HH:MM", e)
    return d


def mins(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def clock12(t, space=False, clock24=False):
    # 14:45 as "2:45pm", or with space "2:45 pm", the form the grid prints and the override's own sentences use, or
    # "14:45" when the user's clock format is the 24-hour clock
    h, m = divmod(int(round(t)), 60)
    if clock24:
        return f"{h:02d}:{m:02d}"
    return f"{(h - 1) % 12 + 1}:{m:02d}" + (" " if space else "") + ("am" if h < 12 else "pm")


def name_of(field):
    # "Name (Affiliation)" to "Name": the affiliation is the LAST parenthesis
    m = re.match(r"^(.*)\s\(([^()]*)\)\s*$", (field or "").strip())
    return m.group(1).strip() if m else (field or "").strip()


def plain(name):
    # a name without accents, in lower case, for matching a mentor list against the program
    s = unicodedata.normalize("NFKD", name)
    return "".join(ch for ch in s if not unicodedata.combining(ch)).lower().strip()


def talk_span(session, i):
    # a talk's start and end in minutes after midnight: its own times when the program prints them, else its share
    # of the even split of its session
    pt = session["talks"][i]
    if pt.get("start") and pt.get("end"):
        return mins(pt["start"]), mins(pt["end"])
    a, e, n = mins(session["start"]), mins(session["end"]), len(session["talks"])
    return a + (e - a) * i / n, a + (e - a) * (i + 1) / n


def drop_session(text, code, names):
    # the block's earlier gives-up text describes the research path, so a talk of the event's own session, now on the
    # path as Option 1, is taken out of its lists: "Norton (2C) at 11:35 and Gantier Mita (2B) at 11:45" keeps Norton,
    # and a sentence naming only such talks is dropped. A talk is found by its presenter's name as the program prints
    # it, any tail of it ("Gantier Mita" for "Marcelo Gantier Mita"), followed by the session's code
    forms = sorted({" ".join(n.split()[k:]) for n in names for k in range(len(n.split()))}, key=len, reverse=True)
    if not forms:
        return text.strip()
    item = (r"\b(?:" + "|".join(re.escape(x) for x in forms) + r") \(" + re.escape(code)
            + r"\)(?: at \d{1,2}:\d{2}(?:\s?[ap]m)?)?")
    text = re.sub(r",? and " + item, "", text)
    text = re.sub(item + r"(?:, | and )", "", text)
    text = re.sub(r", " + item, "", text)
    text = re.sub(r"[^.]*" + item + r"[^.]*\.\s*", "", text)
    return text.strip()


def overlap(x, y):
    return min(x[1], y[1]) - max(x[0], y[0])


def block_start(program, b):
    # the block's clock start, read from its first lettered session as both builders read it, since a BREAK stop
    # counts minutes from there
    s = next(v for v in program if v["code"][:-1] == b and v["code"][-1:].isalpha())
    return mins(s["start"])


def num_tier(t):
    return t["tier"] if isinstance(t.get("tier"), (int, float)) else 0


def find_elsewhere(program, mentors, skip_codes=(), clock24=False):
    # every program session where a mentor presents, discusses or chairs, so is in the room (a coauthor credit alone
    # says nothing about who comes), matched on the first and last word of the name with accents and case set aside,
    # for the event's elsewhere list, a second chance to meet them. One entry per mentor and session, {name, code,
    # role, when}, its roles joined in that order and its time that of the first role, as the grid prints a time
    keys = {(plain(m).split()[0], plain(m).split()[-1]): m for m in mentors if plain(m).split()}
    found = {}
    for s in program:
        if s["code"] in skip_codes:
            continue
        fields = [("chairs", s.get("chair", ""), mins(s["start"]))]
        for i, t in enumerate(s["talks"]):
            st = talk_span(s, i)[0]
            fields.append(("presents", name_of(t.get("presenter", "")), st))
            fields.append(("discusses", name_of(t.get("discussant", "")), st))
        for role, nm, st in fields:
            w = plain(name_of(nm)).split()
            if len(w) >= 2 and (w[0], w[-1]) in keys:
                found.setdefault((keys[(w[0], w[-1])], s["code"]), {}).setdefault(role, (s["day"], st))
    out = []
    for (name, code), roles in found.items():
        order = [x for x in ("presents", "discusses", "chairs") if x in roles]
        day, st = roles[order[0]]
        out.append({"name": name, "code": code, "role": " and ".join(order), "when": f"{day} {clock12(st, space=True, clock24=clock24)}"})
    return out


def apply_career_events(blocks, program, career, me="", clock24=False):
    # changes the rank data's blocks in place and returns the lines to print. me is the user's name as the program
    # prints it, since the rank data keeps the user's own talk at its relevance tier
    if not career:
        return []
    # without the name the user's own talk reads as a research stop, and in a test an override without it displaced
    # the user's talk
    if not me or me.startswith("<"):
        raise SystemExit("set ME, the user's name as the program prints it, before applying career events")
    P = {s["code"]: s for s in program}
    out = []
    for e in sorted(career.get("events", []), key=lambda x: (x["day"], x["start"])):
        code = e.get("code")
        if not code:
            out.append(f"career event {e['title']!r} ({e['day']} {e['start']}) is not a program session: "
                       "listed in the Don't miss box only")
            continue
        if code not in P:
            raise SystemExit(f"career event {e['title']!r} names session {code}, which the program does not have")
        s = P[code]
        b = code[:-1]
        if b not in blocks:
            out.append(f"career event {code} sits in block {b}, which is not ranked: listed in the Don't miss box only")
            continue
        r = blocks[b]
        if any(c["code"] == code for c in r.get("career", [])):
            out.append(f"career event {code}: already Option 1 in block {b}, left as it is")
            continue
        span = (mins(s["start"]), mins(s["end"]))
        if (e["start"], e["end"]) != (s["start"], s["end"]):
            out.append(f"WARNING career event {code}: the file says {e['start']} to {e['end']}, the program "
                       f"{s['start']} to {s['end']}, and the program's times are used")
        t0 = block_start(program, b)
        talks = {(t["code"], t["order"]): t for t in r["talks"]}

        def stop_span(st):
            if st["code"] == "BREAK":
                return t0 + st["break_start_min"], t0 + st["break_end_min"]
            return talk_span(P[st["code"]], st["order"])

        def own(st):
            # the user's meeting, or a talk the user presents, discusses or chairs
            if st["code"] == "BREAK":
                return bool(st.get("label"))
            t, pt = talks.get((st["code"], st["order"]), {}), P[st["code"]]["talks"][st["order"]]
            names = {t.get("presenter", ""), name_of(pt.get("presenter", "")), name_of(pt.get("discussant", "")),
                     name_of(P[st["code"]].get("chair", ""))}
            return t.get("tier") == "ME" or bool(me and me in names)

        over = [st for st in r["path"] if overlap(stop_span(st), span) > 0.5]
        mine = [st for st in over if own(st)]
        if mine:
            out.append(f"WARNING career event {code} ({e['title']}) overlaps your own slot or meeting in block {b} "
                       f"({mine}): the path is left as it is, so put the event to the user")
            continue
        held = [c for c in r.get("career", []) if overlap((mins(c["start"]), mins(c["end"])), span) > 0.5]
        if held:
            out.append(f"WARNING career event {code} ({e['title']}) runs at the same time as career event "
                       f"{held[0]['code']}, already Option 1 in block {b}: listed in the Don't miss box only")
            continue

        ev_stops = [{"code": code, "order": i} for i in range(len(s["talks"]))]
        research = [st for st in over if st["code"] not in ("BREAK", code)]
        old_alts = r.get("alternatives", [])
        gone = {(st["code"], st["order"] if st["code"] != "BREAK" else st["break_start_min"]) for st in over}

        def best(cands):
            return sorted(cands, key=lambda c: (-num_tier(talks[(c["code"], c["order"])]), stop_span(c)[0]))

        # Option 2 for each talk of the event: the best displaced research stop overlapping that talk, else the
        # alternative the stop already had when the path was on the event, else the best talk in another room
        new_alts = []
        for st in ev_stops:
            sp = stop_span(st)
            cands = best([c for c in research if overlap(stop_span(c), sp) > 0.5])
            if cands:
                pick = cands[0]
            else:
                kept = [a for a in old_alts if (a["stop_code"], a["stop_order"]) == (code, st["order"])]
                others = [{"code": t["code"], "order": t["order"]} for t in r["talks"]
                          if t["code"] != code and overlap(talk_span(P[t["code"]], t["order"]), sp) > 0.5]
                if kept:
                    pick = {"code": kept[0]["alt_code"], "order": kept[0]["alt_order"]}
                elif others:
                    pick = best(others)[0]
                else:
                    continue
            why = talks[(pick["code"], pick["order"])]["why"]
            new_alts.append({"stop_code": code, "stop_order": st["order"], "alt_code": pick["code"],
                             "alt_order": pick["order"], "why": "Option 2: " + why})

        # the event's talks take the place of the first displaced stop, or their place in time
        path = r["path"]
        if over:
            k = path.index(over[0])
        else:
            k = next((i for i, st in enumerate(path) if stop_span(st)[0] >= span[0]), len(path))
        r["path"] = ([st for st in path[:k] if st not in over] + ev_stops
                     + [st for st in path[k:] if st not in over and st not in ev_stops])
        dropped_alts = [a for a in old_alts if (a["stop_code"], a["stop_order"]) in gone or a["stop_code"] == code]
        r["alternatives"] = [a for a in old_alts if a not in dropped_alts] + new_alts

        # rooms: the event first, then the Option 2 rooms, then the extra rooms of highest value, five at most
        old_rooms = list(r.get("rooms_to_show", []))
        path_rooms = list(dict.fromkeys(st["code"] for st in research))
        keep = list(dict.fromkeys([code] + [a["alt_code"] for a in new_alts]))
        extras = [c for c in dict.fromkeys(path_rooms + old_rooms) if c not in keep]

        def value(c):
            ts = [num_tier(t) for t in r["talks"] if t["code"] == c]
            return (c in path_rooms, max(ts, default=0), sum(x >= 1 for x in ts))

        chosen = set(sorted(extras, key=value, reverse=True)[:max(0, MAX_ROOMS - len(keep))])
        r["rooms_to_show"] = keep + [c for c in extras if c in chosen]
        dropped_rooms = [c for c in extras if c not in chosen]

        # one sentence naming Option 1 opens the plan, so the rest of the plan reads as Option 2
        when = f"from {clock12(span[0], space=True, clock24=clock24)} to {clock12(span[1], space=True, clock24=clock24)}"
        r["plan"] = (f"Option 1 is {e['title']} in {s['room']} {when} ({ELIG_PLAN[e['eligibility']]}), and the rest "
                     f"of this plan is Option 2, the research path. " + r.get("plan", ""))
        must = sorted([t for t in r["talks"] if t["code"] != code and num_tier(t) == 2
                       and overlap(talk_span(P[t["code"]], t["order"]), span) > 0.5],
                      key=lambda t: talk_span(P[t["code"]], t["order"])[0])
        names = [f"{t['presenter'].split()[-1]} ({P[t['code']]['room']})" for t in must]
        listed = ", ".join(names[:-1]) + " and " + names[-1] if len(names) > 1 else "".join(names)
        lead = (f"Option 1 gives up every research talk {when}, the must-sees by {listed} among them."
                if names else f"Option 1 gives up every research talk {when}, with no must-see among them.")
        rest = drop_session(r.get("gives_up", ""), code, [name_of(t.get("presenter", "")) for t in s["talks"]])
        r["gives_up"] = lead + (" Option 2, the research path: " + rest if rest else "")
        old_main = r.get("main_room")
        r["main_room"] = code
        # a block holding a mentoring or career event is never a lighter slot to skip
        old_skip = r.get("skip_ok", False)
        r["skip_ok"] = False
        r.setdefault("career", []).append({
            "code": code, "title": e["title"], "day": s["day"], "start": s["start"], "end": s["end"],
            "room": s["room"], "eligibility": e["eligibility"], "option2": [{"code": a["alt_code"], "order": a["alt_order"]}
                                                                           for a in new_alts],
            "replaced_path": over, "replaced_alternatives": dropped_alts, "old_main_room": old_main,
            "old_rooms_to_show": old_rooms, "dropped_rooms": dropped_rooms, "old_skip_ok": old_skip})
        coffee = [st for st in over if st["code"] == "BREAK"]
        out.append(f"career event {code} ({e['title']}) is Option 1 in block {b}: {len(research)} research stop(s) and "
                   f"{len(coffee)} coffee window(s) left the path, Option 2 "
                   + (", ".join(f"{a['alt_code']} talk {a['alt_order']}" for a in new_alts) or "none (one room)")
                   + (f", rooms dropped to stay at {MAX_ROOMS}: {dropped_rooms}" if dropped_rooms else ""))
    return out


def check_stops(blocks, program):
    # every path stop and every alternative still names a talk the program has
    P = {s["code"]: s for s in program}
    for b, r in blocks.items():
        for st in r["path"]:
            assert st["code"] == "BREAK" or (st["code"] in P and st["order"] < len(P[st["code"]]["talks"])), (
                b, "path stop not in the program", st)
        for a in r.get("alternatives", []):
            assert a["alt_code"] in P and a["alt_order"] < len(P[a["alt_code"]]["talks"]), (
                b, "alternative not in the program", a)


def main(argv):
    # run alone on a folder whose rank data is already merged:
    #   python3 career_events.py <conf_guide folder> <PREFIX> --me "<the user's name as the program prints it>"
    # with --clock24 when the user's clock format is the 24-hour clock
    # it rewrites <PREFIX>_grid_rank.json in that folder, and an event already applied is left as it is
    import argparse
    ap = argparse.ArgumentParser(description="Make each mentoring or career event Option 1 in the rank data")
    ap.add_argument("folder")
    ap.add_argument("prefix")
    ap.add_argument("--me", required=True, help="the user's name as the program prints it")
    ap.add_argument("--clock24", action="store_true", help="write the plan sentences with the 24-hour clock")
    args = ap.parse_args(argv)
    career = load_career(args.folder, args.prefix)
    if career is None:
        print("no career events file, so the rank data is left as it is")
        return
    rank_file = os.path.join(args.folder, f"{args.prefix}_grid_rank.json")
    with open(os.path.join(args.folder, f"{args.prefix}_program_builders.json"), encoding="utf-8") as fh:
        program = json.load(fh)
    with open(rank_file, encoding="utf-8") as fh:
        data = json.load(fh)
    for line in apply_career_events(data["blocks"], program, career, me=args.me, clock24=args.clock24):
        print(line)
    check_stops(data["blocks"], program)
    with open(rank_file, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=1, ensure_ascii=False)
    print("wrote", rank_file)


if __name__ == "__main__":
    main(sys.argv[1:])

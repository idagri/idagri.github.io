#!/usr/bin/env python3
# TEMPLATE: a parser for a program posted as a Google Doc. The doc downloads as plain text from
#   https://docs.google.com/document/d/<ID>/export?format=txt   (format=html for the formatted copy)
# Save both with the download date, edit the SETTINGS block to the doc's own wording, copy this into
# the conference folder as parse_<conf>_program.py and run
#   python3 -I parse_<conf>_program.py <agenda .txt>
#
# The layout it reads, one item per line, blank lines and tabs ignored:
#   a time range "9:30—11:00" (em dash, en dash or hyphen), then either a session header ("Block 1:
#   Agriculture") or an event of the day ("Coffee Break") with an optional room line
#   under a session header: the room, a chair line, then each talk as a title line followed by a
#   "Name (Affiliation)" line, with an optional trailing mark such as "*" that a footnote explains
#   the footnote line ends the program
# The output has the same fields as the HTML parser's, so the merge and the builders read it
# unchanged: a list of sessions with code, day, start, end, room, chair, title "<code>. <theme>", the
# program's own session name in block_label, and talks in program order. The events go to a second
# file for the cover's and the table's break rows. Two guards: a session's room must be in ROOM_LETTER,
# and every title line left without a presenter line is reported, so read each one

import json
import re
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------------------------
# SETTINGS: the only values that change per conference
# ---------------------------------------------------------------------------------------------
PREFIX = "<YYYY_MM_CONF>"
SRC = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "<live program copy>.txt"
# one fixed letter per room for the whole meeting; a session code is <time slot><room letter>
ROOM_LETTER = {"<Room as the doc prints it>": "A", "<Second room>": "B"}
# a session header and its parts: the program's own number and the theme
SESSION_RE = re.compile(r"^Block (\d+):\s*(.*)$")
SESSION_WORD = "Block"
CHAIR_RE = re.compile(r"^Session Chair:\s*")
# the footnote that ends the program, e.g. "* Indicates ..."
END_RE = re.compile(r"^\* Indicates")
# a program day for a one-day meeting; a line matching DAY_RE starts a new day on a longer one
DAY = "<day key, as DAYNAME in the builders spells it>"
DAY_RE = re.compile(r"^(Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday)\b")
# the program prints a 12-hour clock with no am or pm: an hour below this is in the afternoon
PM_BEFORE = 8

TIME_RE = re.compile(r"^(\d{1,2}):(\d{2})\s*[—–-]\s*(\d{1,2}):(\d{2})$")
# the affiliation is the LAST parenthesis, since a name can hold one of its own
PERSON_RE = re.compile(r"^(.*)\s\(([^()]*)\)\s*(\*?)\s*$")


def hhmm(h, m):
    h, m = int(h), int(m)
    h += 12 if h < PM_BEFORE else 0
    return f"{h:02d}:{m:02d}"


# the export opens with a byte-order mark and indents with tabs
lines = [ln.replace("\ufeff", "").strip() for ln in SRC.read_text(encoding="utf-8").splitlines()]
lines = [ln for ln in lines if ln]

sessions, events, dropped = [], [], []
day, slot, start, end, cur, title = DAY, 0, None, None, None, None
i = 0
while i < len(lines):
    ln = lines[i]
    if END_RE.match(ln):
        break
    if DAY_RE.match(ln):
        day = ln
        i += 1
        continue
    tm = TIME_RE.match(ln)
    if tm:
        if title:
            dropped.append((cur["code"] if cur else "", title))
        cur, title = None, None
        start, end = hhmm(tm.group(1), tm.group(2)), hhmm(tm.group(3), tm.group(4))
        nxt = lines[i + 1] if i + 1 < len(lines) else ""
        if SESSION_RE.match(nxt):
            slot += 1
            i += 1
            continue
        # an event of the day: its name, then any lines before the next time range (its room)
        j = i + 2
        while j < len(lines) and not TIME_RE.match(lines[j]) and not END_RE.match(lines[j]):
            j += 1
        events.append({"day": day, "start": start, "end": end, "title": nxt, "room": " ".join(lines[i + 2:j])})
        i = j
        continue
    sm = SESSION_RE.match(ln)
    if sm:
        if title:
            dropped.append((cur["code"] if cur else "", title))
        room, chair = lines[i + 1], CHAIR_RE.sub("", lines[i + 2]).strip()
        if room not in ROOM_LETTER:
            raise SystemExit(f"room not in ROOM_LETTER: {room!r} (session {ln!r})")
        code = f"{slot}{ROOM_LETTER[room]}"
        cur = {"sid": code, "code": code, "day": day, "start": start, "end": end, "room": room,
               "block_label": f"{SESSION_WORD} {sm.group(1)}", "title": f"{code}. {sm.group(2).strip()}",
               "chair": chair, "talks": []}
        sessions.append(cur)
        title = None
        i += 3
        continue
    pm = PERSON_RE.match(ln)
    if cur is not None and pm and title:
        name, affil = pm.group(1).strip(), pm.group(2).strip()
        cur["talks"].append({"authors": name, "title": title, "presenter": f"{name} ({affil})",
                             "discussant": "", "abstract": "", "links": [], "marked": pm.group(3) == "*"})
        title = None
    elif cur is not None:
        # a title line; a second one before any presenter line means the first had none
        if title:
            dropped.append((cur["code"], title))
        title = ln
    i += 1
if title:
    dropped.append((cur["code"] if cur else "", title))

out = HERE / f"{PREFIX}_program_parsed.json"
out.write_text(json.dumps(sessions, indent=1, ensure_ascii=False), encoding="utf-8")
(HERE / f"{PREFIX}_program_events.json").write_text(json.dumps(events, indent=1, ensure_ascii=False),
                                                     encoding="utf-8")
print(f"sessions: {len(sessions)}   talks: {sum(len(s['talks']) for s in sessions)}   events: {len(events)}")
for code, t in dropped:
    print("title line with no presenter line, dropped:", code, t[:70])

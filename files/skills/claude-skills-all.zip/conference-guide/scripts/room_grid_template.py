#!/usr/bin/env python3
# TEMPLATE: the room-grid builder. Per conference, edit the SETTINGS block, and everything else reads the
# data files. Copy it into the conference's conf_guide/ folder as build_<conf>_grid.py
#
# Draws the meeting as a room grid: a cover with every day, the people pages, then one page per
# parallel session with the rooms worth comparing across the top, time running down, and the path
# drawn through it, so a room switch, a coffee window, the alternatives, and what the path gives up
# are visible at a glance
#
# Inputs, all in this folder, named <PREFIX>_...:
#   program_builders.json the live program as sessions and talks, with the merge's spelling
#                         corrections in every name field; a session's optional block_label is the
#                         program's own name for it ("Block 7"), shown in place of the code
#   grid_rank.json        tiers, reasons, rooms to show, backups, path and alternatives per block; a
#                         BREAK stop with a label is a meeting of the user's own, and skip_ok is true on a lighter slot
#   grid_links.json       checked paper and presenter-site links, keyed "code|order"
#   people.json           people the user knows or likely knows, checked against the profile, past programs
#                         and, when allowed, mail; mark, set by the user, is "♥" (pink) for anyone the user
#                         marks or "" for no mark, and close is true
#                         for someone close (the tag is the heart with no tie wording) or false for someone familiar (the
#                         heart and the short reason)
#   asked.json            optional: presenters the user asked to catch, drawn with the blue diamond
#   program_events.json   optional: the program's breaks, meals and socials, {day, start, end, title}
#   extra_rows.json       optional: cover rows the program does not hold, {day, start, kind, label}, read
#                         by both builders: "ex" an exercise option, "arr" where to go on arrival, "logi"
#                         a break or meal typed by hand, "key" a keynote that is not a ranked block (with
#                         tier, title, speaker, affiliation, room and note in place of label)
# A talk's time is its own start and end when the program gives them, else the session divided
# evenly by the talks in its room

import json
import re
import textwrap
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib import font_manager
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------------------------
# SETTINGS: the only values that change per conference
# ---------------------------------------------------------------------------------------------
PREFIX = "<YYYY_MM_CONF>"
TITLE = "<Meeting name>"
# the venue with its address and the dates; when the meeting is in another time zone, say how its clock
# compares with the user's home time zone that week
VENUE_DATES = "<Venue>, <Month D and D>"
ME = "<YOUR NAME AS THE PROGRAM PRINTS IT>"
# the program's day value to the weekday for each session page's title
DAYNAME = {"<Month D>": "<Weekday>", "<Month D+1>": "<Weekday>"}
# the program's day value to the cover's heading for that day, in the order of the days
DAY_HEADING = {"<Month D>": "<Weekday Month D>", "<Month D+1>": "<Weekday Month D+1>"}
# blocks in the order the user needs them: the next session first, a session already over last
SESSION_ORDER = ["<block>", "<block>"]
# one sentence for the foot of each session page, e.g. "Talk times are estimates: the program gives
# only session times, so each room's session is split evenly among its talks."
TIMES_NOTE = "<how talk times were set>"
# False when the people check searched no mailbox: the people page and the foot of each session page
# then say the ties come from the profile only
MAIL_SEARCHED = True
# True prints 24-hour clock times (14:30), False the 12-hour clock (2:30 pm), as the profile's clock format says
CLOCK_24 = False
# the end of the cover row for the user's own session, e.g. "YOUR TALK about 10:15 to 10:45am, second of three,
# chair <Name>"; the row itself names the session, the room and the time to be in the room
MY_SESSION_NOTE = "<YOUR TALK about <time>, <position>, chair <name>>"
# the program's events by title: an event left out of the cover (matched on the lowercase start of the
# title), and the wording for an event that needs more than "<title>: network", such as a dinner that is
# not on the user's registration
EVENT_SKIP = ("changeover",)
EVENT_NOTE = {
    # "<Conference dinner>": "Conference dinner, <venue> (regular registration only)",
}


def event_title(title):
    # an event's title as the cover shows it; Oxford Abstracts adds a tail after " - " and a "Social N: " lead
    return re.sub(r"^Social \d+: ", "", title.split(" - ")[0])


# the PDF the user reads goes in the conference folder, one level above conf_guide/, where this script and its inputs live
OUT = HERE.parent / f"{PREFIX}_room_grid.pdf"

# on a Mac, Arial for words in real regular and bold, and Arial Unicode MS for the symbols; elsewhere
# DejaVu Sans, which matplotlib ships and which has every symbol these pages print and a real bold face
MAC_FONTS = Path("/System/Library/Fonts/Supplemental")
ON_MAC = all((MAC_FONTS / f).exists() for f in ["Arial.ttf", "Arial Bold.ttf", "Arial Unicode.ttf"])
if ON_MAC:
    for f in ["Arial.ttf", "Arial Bold.ttf", "Arial Unicode.ttf"]:
        font_manager.fontManager.addfont(str(MAC_FONTS / f))
# Arial for words in real regular and bold; Arial Unicode MS fills in the star, circle, diamond,
# arrow, hot-springs, sun and heart glyphs
plt.rcParams["font.family"] = ["Arial", "Arial Unicode MS"] if ON_MAC else ["DejaVu Sans"]
# TrueType embedding keeps every word selectable and searchable
plt.rcParams["pdf.fonttype"] = 42
# every wrap width below is a count of characters sized for Arial, and DejaVu Sans sets the same words about 15% wider
# (18% in bold, measured on a full guide), so off a Mac each count is cut by WRAP and each width estimated per
# character grows by 1 / WRAP. On a Mac WRAP is 1 and every page stays as it was
WRAP = 1.0 if ON_MAC else 0.85


def ww(n):
    # a wrap width in characters, cut for a wider font
    return max(1, int(n * WRAP))


def fit_title(fig, t, max_w):
    # a one-line title wider than max_w inches shrinks until it fits, and a title that fits keeps its size
    w = t.get_window_extent(renderer=fig.canvas.get_renderer()).width / fig.dpi
    if w > max_w:
        t.set_fontsize(t.get_fontsize() * max_w / w * 0.98)


def load(name, default):
    p = HERE / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default


PROGRAM = load(f"{PREFIX}_program_builders.json", [])
RANK = load(f"{PREFIX}_grid_rank.json", {}).get("blocks", {})
LINKS = load(f"{PREFIX}_grid_links.json", {})
PEOPLE = load(f"{PREFIX}_people.json", {}).get("people", [])
ASKED = set(load(f"{PREFIX}_asked.json", []))
EVENTS = load(f"{PREFIX}_program_events.json", [])
EXTRA = load(f"{PREFIX}_extra_rows.json", [])

# session code to its program entry; room letters keep their room all conference, and a code is the
# block number plus ONE room character (a 27th room takes a lowercase letter)
SESS = {s["code"]: s for s in PROGRAM}


def minutes(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def clock(total_min, suffix=False):
    h, m = divmod(int(round(total_min)), 60)
    if CLOCK_24:
        return f"{h:02d}:{m:02d}"
    s = f"{(h - 1) % 12 + 1}:{m:02d}"
    return s + (" am" if h < 12 else " pm") if suffix else s


def first_session(b):
    return next(v for k, v in SESS.items() if k[:-1] == b and k[-1].isalpha())


def block_meta(b):
    s = first_session(b)
    a, e = minutes(s["start"]), minutes(s["end"])
    return {"day": DAYNAME[s["day"]], "start_min": a, "dur": e - a}


def talk_span(code, i):
    # a talk's start and end in minutes after midnight: its own times when the program prints them, else its
    # share of the even split of its room's session
    s = SESS[code]
    pt = s["talks"][i]
    if pt.get("start") and pt.get("end"):
        return minutes(pt["start"]), minutes(pt["end"])
    a, e, n = minutes(s["start"]), minutes(s["end"]), len(s["talks"])
    return a + (e - a) * i / n, a + (e - a) * (i + 1) / n


def theme(code):
    return SESS[code]["title"].split(". ", 1)[1]


def sess_label(code):
    # the program's own name for a session when it numbers sessions its own way, else the code
    return SESS[code].get("block_label") or code


def heading(code):
    # "Block 7: Migration" when the program names its sessions, else "2E Development"
    return f"{sess_label(code)}: {theme(code)}" if SESS[code].get("block_label") else f"{code} {theme(code)}"


def block_name(b, cap=True):
    # a block as the program names its sessions ("Blocks 3 and 4"), else "Session <b>"
    labs = [SESS[c].get("block_label", "").split(None, 1) for c in sorted(SESS) if c[:-1] == b and c[-1].isalpha()]
    if not labs or any(len(x) != 2 for x in labs) or len({x[0] for x in labs}) > 1:
        return ("Session " if cap else "session ") + b
    nums = [x[1] for x in labs]
    return labs[0][0] + ("s " + ", ".join(nums[:-1]) + " and " + nums[-1] if len(nums) > 1 else " " + nums[0])


def two_lines(text, width):
    # at most two lines, with an ellipsis when the text runs longer
    ls = textwrap.wrap(text, width)
    return ls if len(ls) <= 2 else [ls[0], textwrap.shorten(" ".join(ls[1:]), width, placeholder=" …")]


def short_affil(aff, width):
    # an affiliation in two lines at most: a long department name gives way to the institution after its last
    # comma, and anything still longer is cut with an ellipsis
    if len(textwrap.wrap(aff, width)) > 2 and "," in aff:
        aff = aff.rsplit(",", 1)[1].strip()
    return two_lines(aff, width)


def surname(full):
    return full.split()[-1]


# people the user knows, by name; a tag goes on the box of a presenter, and a discussant or chair the user
# knows is named on the box or under the room header
PEOPLE_BY = {p["name"]: p for p in PEOPLE}
HEARTS = any(p.get("mark") for p in PEOPLE)
# one pink heart for every marked person, since a smaller or paler mark is hard to notice
HEART_PINK = "#D6457A"


def mark_rank(p):
    # close people first, then the other marked people, then everyone else
    return 0 if p.get("mark") and p.get("close") else 1 if p.get("mark") else 2


def person_of(field):
    # "Name (Affiliation)" to "Name"; the affiliation is the LAST parenthesis, since a name can hold
    # one of its own, as in "Ana (Nina) Ruiz (University of Example)"
    m = re.match(r"^(.*)\s\(([^()]*)\)\s*$", field.strip())
    return m.group(1).strip() if m else field.strip()


FILL = {2: "#E3F1DE", 1: "#EAF4F3", 0: "#F4F5F6", "A": "#D3DAF0", "ME": "#CFE7E5"}
EDGE = {2: "#7FB77E", 1: "#8CC5C0", 0: "#C9CDD2", "A": "#3B528B", "ME": "#21918C"}
SYM = {2: "★★", 1: "★", 0: "○", "A": "◆", "ME": "●"}
SYMCOL = {2: "#3B7A57", 1: "#21918C", 0: "#8A9099", "A": "#3B528B", "ME": "#13716B"}
BREAK_FILL, BREAK_EDGE = "#FBE8C6", "#D9A441"
# exercise options: a light blue row with the sun
EX_FILL, EX_EDGE = "#E3ECF8", "#6F8FC4"
PATH = "#2E3440"
# room labels are a light highlight in the viridis blue family, with dark blue type
CHIP_FILL, CHIP_EDGE, CHIP_TEXT = "#DDE5F3", "#9FB2D9", "#2F4478"
ALT_EDGE = "#3B528B"
BLUE = "#1F5C99"


def lookup_url(name):
    # a Google Scholar author search, so every name in the PDF opens somewhere to look the person up
    from urllib.parse import quote_plus
    return "https://scholar.google.com/citations?view_op=search_authors&mauthors=" + quote_plus(name)


KIND_LABEL = {"paper": "paper", "working paper page": "paper page", "seminar page": "seminar abstract",
              "program page": "program abstract",
              "author page": "author’s page", "coauthor page": "coauthor’s page",
              "registry entry": "trial registry entry"}
HOTSPOTS = []


def tag_box(ax, x, y, text, guess, fs):
    if text[:1] == "♥":
        # a marked person: pink type on white with a pink edge
        ax.text(x, y, f" {text} ", fontsize=fs, fontweight="bold", color=HEART_PINK, va="top", zorder=4,
                bbox=dict(boxstyle="round,pad=0.18", fc="white", ec=HEART_PINK, lw=0.8))
        return
    ax.text(x, y, f" {text} ", fontsize=fs, fontweight="bold",
            color="#3B528B" if guess else "white", va="top", zorder=4,
            bbox=dict(boxstyle="round,pad=0.18", fc="white" if guess else "#3B528B",
                      ec="#3B528B", lw=0.8))


def people_tag(name):
    # a close person's tag is the pink heart with no tie wording, and a familiar one's is the pink heart and
    # the short reason, so the user knows why the person is flagged
    p = PEOPLE_BY.get(name)
    if not p:
        return None
    if p.get("mark") == "♥":
        return ("♥" if p.get("close") else "♥ " + p["tag"], False)
    return (("knows: " if p["tier"] == "knows" else "likely: ") + p["tag"], p["tier"] != "knows")


def known_here(b):
    # every presenter the user knows in the block, the marked ones first, and every marked coauthor with the
    # affiliation, each with room and start, for the line under each page's plan, so who is presenting shows even
    # where the path does not go
    out = []
    for c, sess in SESS.items():
        if c[:-1] != b:
            continue
        for i, t in enumerate(sess["talks"]):
            st = talk_span(c, i)[0]
            names = [x.strip() for x in re.split(r";| and |, ", re.sub(r"\s*\([^()]*\)", "", t["presenter"]))]
            for nm in names:
                p = PEOPLE_BY.get(nm)
                if p and p["tier"] == "knows":
                    mk = p.get("mark", "")
                    out.append((mark_rank(p), st, (mk + " " if mk else "") + nm
                                + f" ({sess['room']}, {clock(st, True)})"))
            for nm in [a.strip() for a in t["authors"].split(", ")]:
                p = PEOPLE_BY.get(nm)
                if p and p.get("mark") and nm not in names:
                    aff = t.get("affils", {}).get(nm, "")
                    why = "" if p.get("close") else p["tag"]
                    inside = ", ".join(x for x in (aff, why) if x)
                    out.append((mark_rank(p), st, f"{p['mark']} {nm}" + (f" ({inside})" if inside else "")
                                + f", coauthor, {sess['room']} {clock(st, True)}"))
    return [x[2] for x in sorted(out)]


def tier_of(code, t):
    # the user's own slot (the user presents or discusses) draws as the user's; a talk the user asked to catch gets the
    # diamond; anything else keeps its relevance tier, a hearted presenter's included
    pt0 = SESS[code]["talks"][t["order"]]
    if t["presenter"] == ME or person_of(pt0.get("discussant", "")) == ME:
        return "ME"
    return "A" if t["presenter"] in ASKED else t["tier"]


def draw_session(pdf, b, page_no):
    r = RANK[b]
    meta = block_meta(b)
    DUR, T0 = meta["dur"], meta["start_min"]
    talks = {}
    for t in r["talks"]:
        talks.setdefault(t["code"], []).append(t)
    for c in talks:
        talks[c].sort(key=lambda t: t["order"])
    rooms = [c for c in r["rooms_to_show"] if c in talks]
    # an alternative's room is always drawn, so no ALT box disappears (five rooms at most)
    for a in r.get("alternatives", []):
        if a["alt_code"] in talks and a["alt_code"] not in rooms and len(rooms) < 5:
            rooms.append(a["alt_code"])
    # the rooms the path visits sit first, in the order it visits them, beside the coffee lane, so no arrow
    # crosses another room (a path room drawn third once had its coffee arrow run across two rooms)
    visit = []
    for st in r["path"]:
        if st["code"] != "BREAK" and st["code"] in rooms and st["code"] not in visit:
            visit.append(st["code"])
    rooms = visit + [c for c in rooms if c not in visit]
    path = [("BREAK", st["break_start_min"], st["break_end_min"]) if st["code"] == "BREAK"
            else (st["code"], st["order"]) for st in r["path"]]
    # a box the path leaves by a MOVE keeps room at its foot for the MOVE badge, which otherwise covered
    # the last words of its reason
    move_from = {path[k] for k in range(len(path) - 1)
                 if "BREAK" not in (path[k][0], path[k + 1][0]) and path[k][0] != path[k + 1][0]}
    nroom = len(rooms)
    alts = {(x["alt_code"], x["alt_order"]) for x in r.get("alternatives", [])}

    fig = plt.figure(figsize=(8.5, 11))
    W, H = 8.5, 11.0
    left, time_w, break_w, gap = 0.35, 0.5, 0.72, 0.07
    room_w = (W - left - time_w - break_w - 0.25 - gap * (nroom + 1)) / nroom
    scale = min(1.0, room_w / 1.55)
    # the type never grows past full size, but the wrap widths follow the lane in both directions: in
    # a two-room lane about 3.3 inches wide, wraps sized for 1.55 inches left the text in a narrow
    # column inside a wide box
    wscale = room_w / 1.55 * 0.92
    bottom = 1.55

    def ymin(m):
        return top + plot_h * m / DUR

    def span(code, i):
        # the talk's own times when the program gives them, else the even split of the session
        pt = SESS[code]["talks"][i]
        if pt.get("start") and pt.get("end"):
            return minutes(pt["start"]) - T0, minutes(pt["end"]) - T0
        n = len(talks[code])
        return DUR * i / n, DUR * (i + 1) / n

    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, W)
    ax.set_ylim(H, 0)
    ax.axis("off")

    fit_title(fig, ax.text(left, 0.42, f"{meta['day']}, {block_name(b, cap=False)}   {clock(T0, True)} to "
                           f"{clock(T0 + DUR, True)}", fontsize=17, fontweight="bold", color="#1F2933", va="center"),
              W - 2 * left)
    y = 0.68
    plan = r["plan"]
    ax.text(left, y, "\n".join(textwrap.wrap(plan, ww(125))), fontsize=9.3, color="#1F2933",
            va="top", linespacing=1.3)
    y += 0.17 * len(textwrap.wrap(plan, ww(125))) + 0.06
    # the people the user knows presenting in this block, hearts first, under the plan
    kh = known_here(b)
    if kh:
        # one chip per person, each naming the person in full: every marked person pink on white with a pink edge,
        # anyone else on light blue
        rend = fig.canvas.get_renderer()
        lab = ax.text(left, y, "People you know presenting in this block:", fontsize=8.6, color="#13716B",
                      va="top", fontweight="bold")
        cx = left + lab.get_window_extent(renderer=rend).width / fig.dpi + 0.12
        cy = y
        for item in kh:
            mark = item[:1]
            fc, ec, col = (("white", HEART_PINK, HEART_PINK) if mark == "♥" else
                           ("#E3ECF8", "#6F8FC4", "#1F2933"))
            t = ax.text(cx, cy, item, fontsize=8.2, color=col, va="top", fontweight="bold", zorder=4,
                        bbox=dict(boxstyle="round,pad=0.16", fc=fc, ec=ec, lw=0.7))
            w = t.get_window_extent(renderer=rend).width / fig.dpi
            if cx + w > W - 0.3 and cx > left + 0.1:
                t.remove()
                cx, cy = left, cy + 0.24
                t = ax.text(cx, cy, item, fontsize=8.2, color=col, va="top", fontweight="bold", zorder=4,
                            bbox=dict(boxstyle="round,pad=0.16", fc=fc, ec=ec, lw=0.7))
                w = t.get_window_extent(renderer=rend).width / fig.dpi
            cx += w + 0.14
        y = cy + 0.26

    # color key, under however many lines the plan took; the grid starts below it
    kx, ky = left, max(1.32, y + 0.2)
    key = [(FILL[2], EDGE[2], 0.8, "★★ must-see"), (FILL[1], EDGE[1], 0.8, "★ strong"),
           (FILL[0], EDGE[0], 0.8, "○ less relevant")]
    shown = {tier_of(c, t) for c in rooms for t in talks[c]}
    if "ME" in shown:
        key.append((FILL["ME"], EDGE["ME"], 0.8, "● your slot"))
    if "A" in shown:
        key.append((FILL["A"], EDGE["A"], 0.8, "◆ you asked for it"))
    key += [(BREAK_FILL, BREAK_EDGE, 0.8, "♨ your coffee"), ("white", PATH, 2.4, "your path"),
            ("white", ALT_EDGE, 1.5, "alternative")]
    for fc, ec, lw, label in key:
        # a swatch that would pass the right edge starts a second row of the key
        if kx + 0.33 + 0.058 / WRAP * len(label) > W - 0.3:
            kx, ky = left, ky + 0.3
        ax.add_patch(FancyBboxPatch((kx, ky - 0.09), 0.26, 0.18, boxstyle="round,pad=0,rounding_size=0.03",
                                    fc=fc, ec=ec, lw=lw, linestyle="--" if label == "alternative" else "-"))
        ax.text(kx + 0.33, ky, label, fontsize=8, color="#1F2933", va="center")
        kx += 0.33 + 0.058 / WRAP * len(label) + 0.16
    # the grid starts below the last row of the key
    top = ky + 1.38
    plot_h = H - top - bottom

    x0 = left + time_w
    lane_x = {"BREAK": (x0, break_w)}
    x = x0 + break_w + gap
    for c in rooms:
        lane_x[c] = (x, room_w)
        x += room_w + gap

    hy = top - 0.78
    ax.text(x0 + break_w / 2, hy, "♨ coffee", ha="center", va="center",
            fontsize=9, fontweight="bold", color="#9A6B12")
    for c in rooms:
        lx, w = lane_x[c]
        room = SESS[c]["room"]
        cw = min(w - 0.1, 0.13 + 0.095 / WRAP * len(room))
        ax.add_patch(FancyBboxPatch((lx + w / 2 - cw / 2, hy - 0.15), cw, 0.3,
                                    boxstyle="round,pad=0.02,rounding_size=0.05", fc=CHIP_FILL,
                                    ec=CHIP_EDGE, lw=0.8))
        ax.text(lx + w / 2, hy, room, ha="center", va="center", fontsize=10.5,
                fontweight="bold", color=CHIP_TEXT)
        ax.text(lx + w / 2, hy + 0.19, "\n".join(two_lines(heading(c), ww(30 * wscale))), ha="center",
                va="top", fontsize=7, color="#4C566A", linespacing=1.1)
        chair = person_of(SESS[c]["chair"])
        pt = people_tag(chair)
        if pt:
            # the tie wording after "knows: ", or the heart with no tie wording
            tie = pt[0].split(": ", 1)[1] if ": " in pt[0] else pt[0]
            ax.text(lx + w / 2, top - 0.07, "\n".join(textwrap.wrap(f"chair {chair} ({tie})", ww(34 * wscale))),
                    ha="center", va="bottom", fontsize=6.3, color="#3B528B", fontweight="bold", linespacing=1.05)
        # every room the path visits is ON YOUR PATH, and BACKUP is left for a room it does not visit:
        # with the path in both rooms of a session, MAIN over one of them misled
        if c in {st["code"] for st in r["path"]}:
            ax.text(lx + w / 2, hy - 0.26, "ON YOUR PATH", ha="center", va="bottom", fontsize=7,
                    fontweight="bold", color="#13716B")
        elif c in [bk["code"] for bk in r["backups"]]:
            ax.text(lx + w / 2, hy - 0.26, "BACKUP", ha="center", va="bottom", fontsize=7,
                    fontweight="bold", color="#8A9099")

    for m in range(0, DUR + 1, 15):
        yy = ymin(m)
        half = (T0 + m) % 30 == 0
        ax.plot([x0 - 0.05, W - 0.25], [yy, yy], color="#D5DAE1" if half else "#ECEFF3",
                lw=0.7 if half else 0.5, zorder=0)
        ax.text(x0 - 0.08, yy, clock(T0 + m), ha="right", va="center", fontsize=8.5 if half else 7,
                color="#1F2933" if half else "#8A9099", fontweight="bold" if half else "normal")

    path_boxes = {}
    prog_by = {c: SESS[c]["talks"] for c in rooms}
    for c in rooms:
        lx, w = lane_x[c]
        for t in talks[c]:
            i = t["order"]
            tier = tier_of(c, t)
            a, e = span(c, i)
            y1, y2 = ymin(a) + 0.03, ymin(e) - 0.03
            on_path = (c, i) in path
            is_alt = (c, i) in alts and not on_path
            ax.add_patch(FancyBboxPatch((lx, y1), w, y2 - y1, boxstyle="round,pad=0,rounding_size=0.06",
                                        fc=FILL[tier], ec=PATH if on_path else (ALT_EDGE if is_alt else EDGE[tier]),
                                        lw=2.6 if on_path else (1.5 if is_alt else 0.8),
                                        linestyle="--" if is_alt else "-", zorder=2))
            if is_alt:
                ax.text(lx + w - 0.06, y2 - 0.06, "ALT", ha="right", va="bottom", fontsize=6.5,
                        fontweight="bold", color="white", zorder=5,
                        bbox=dict(boxstyle="round,pad=0.15", fc=ALT_EDGE, ec=ALT_EDGE))
            if on_path:
                path_boxes[(c, i)] = (lx, y1, w, y2 - y1)
            prog = prog_by[c][i]
            disc = person_of(prog["discussant"]) if prog["discussant"] else ""
            link = LINKS.get(f"{c}|{i}", {})
            site = link.get("site_url", "") or lookup_url(t["presenter"])
            paper = link.get("paper_url", "")
            pt = people_tag(t["presenter"])
            dt = people_tag(disc) if disc else None
            co = [x.strip() for x in re.split(r",| and ", prog["authors"])
                  if x.strip() and x.strip() != t["presenter"] and x.strip() in PEOPLE_BY]
            # a known discussant or coauthor, split into documented ties and likely ones; a marked coauthor is
            # named in full with the mark and the affiliation from the program's records
            parts = []
            for tier_name, label in [("knows", "known"), ("probably", "likely")]:
                ties = []
                if dt and PEOPLE_BY[disc]["tier"] == tier_name:
                    ties.append(f"disc. {surname(disc)}")
                cs = []
                for x in co:
                    if PEOPLE_BY[x]["tier"] != tier_name:
                        continue
                    mk, aff = PEOPLE_BY[x].get("mark", ""), prog.get("affils", {}).get(x, "")
                    cs.append(f"{mk} {x}" + (f" ({aff})" if aff else "") if mk else surname(x))
                if cs:
                    ties.append(("coauthor " if len(cs) == 1 else "coauthors ") + ", ".join(cs))
                if ties:
                    parts.append(f"{label}: " + " and ".join(ties))
            tie_line = ". ".join(parts)

            # shrink the type until the box content fits its height, keeping room for a MOVE badge at the foot
            for k in [1.0, 0.93, 0.86, 0.8, 0.74, 0.68]:
                f = scale * k
                nl = textwrap.wrap(t["presenter"], ww(19 * wscale / k))
                al = short_affil(t["affiliation_short"], ww(34 * wscale / k))
                tl = textwrap.wrap(t["title"], ww(30 * wscale / k))
                wl = textwrap.wrap(t["why"], ww(26 * wscale / k))
                need = (0.08 + 0.155 * f * len(nl) + 0.04
                        + (0.12 * f * len(textwrap.wrap(pt[0], ww(28 * wscale / k))) + 0.09 if pt else 0)
                        + 0.13 * f * len(al) + 0.03 + (0.16 * f if paper else 0)
                        + (0.13 * f * len(textwrap.wrap(tie_line, ww(34 * wscale / k))) + 0.03 if tie_line else 0)
                        + 0.112 * f * len(tl) + 0.07 + 0.118 * f * len(wl)
                        + (0.26 if (c, i) in move_from else 0))
                if need <= (y2 - y1):
                    break
            ty = y1 + 0.08
            ax.text(lx + 0.06, ty, SYM[tier], fontsize=8.5 * f, color=SYMCOL[tier], va="top",
                    fontweight="bold", zorder=3)
            ax.text(lx + 0.3 * f + 0.04, ty, "\n".join(nl), fontsize=8 * f, fontweight="bold",
                    color=BLUE if site else "#1F2933", va="top", linespacing=1.1, zorder=3)
            name_top = ty
            ty += 0.155 * f * len(nl) + 0.04
            if site:
                HOTSPOTS.append((page_no, (lx + 0.25, name_top - 0.03, lx + w, ty), site))
            name_bottom = ty
            if pt:
                # a long tag wraps to fit inside the box
                tg = textwrap.wrap(pt[0], ww(28 * wscale / f))
                tag_box(ax, lx + 0.06, ty + 0.01, "\n".join(tg), pt[1], 6.2 * f)
                ty += 0.12 * f * len(tg) + 0.09
            ax.text(lx + 0.06, ty, "\n".join(al), fontsize=6.6 * f, color="#4C566A", va="top",
                    linespacing=1.1, zorder=3)
            ty += 0.13 * f * len(al) + 0.03
            if tie_line:
                tl2 = textwrap.wrap(tie_line, ww(34 * wscale / f))
                ax.text(lx + 0.06, ty, "\n".join(tl2), fontsize=6.4 * f, color="#3B528B",
                        fontweight="bold", va="top", linespacing=1.1, zorder=3)
                ty += 0.13 * f * len(tl2) + 0.03
            if paper:
                ax.text(lx + 0.06, ty, f"↗ {KIND_LABEL.get(link.get('paper_kind', 'paper'), 'paper')}",
                        fontsize=6.6 * f, fontweight="bold", color=BLUE, va="top", zorder=3)
                ty += 0.16 * f
                HOTSPOTS.append((page_no, (lx, name_bottom if site else y1, lx + w, y2), paper))
            ax.text(lx + 0.06, ty, "\n".join(tl), fontsize=6.8 * f,
                    color=BLUE if paper else ("#1F2933" if tier else "#6B7280"),
                    va="top", linespacing=1.15, zorder=3)
            ty += 0.112 * f * len(tl) + 0.07
            ax.text(lx + 0.06, ty, "•", fontsize=7.2 * f, color="#1D6F6A", va="top", zorder=3)
            ax.text(lx + 0.15, ty, "\n".join(wl), fontsize=7 * f, color="#1D6F6A", va="top",
                    linespacing=1.15, zorder=3)

    # a BREAK stop with a label is a meeting of the user's own: teal, in the coffee lane, with no alternative
    # and one without is the user's coffee, in amber
    meet = {st["break_start_min"]: st.get("label", "") for st in r["path"] if st["code"] == "BREAK"}
    for st in path:
        if st[0] != "BREAK":
            continue
        _, a, e = st
        y1, y2 = ymin(a) + 0.03, ymin(e) - 0.03
        if meet.get(a):
            ax.add_patch(FancyBboxPatch((x0, y1), break_w, y2 - y1, boxstyle="round,pad=0,rounding_size=0.06",
                                        fc=FILL["ME"], ec=PATH, lw=2.6, zorder=2))
            ax.text(x0 + break_w / 2, (y1 + y2) / 2, "\n".join(textwrap.wrap(meet[a], ww(11)))
                    + f"\n{clock(T0 + a)} to\n{clock(T0 + e)}",
                    ha="center", va="center", fontsize=7.6, fontweight="bold", color="#13716B", zorder=3)
        else:
            ax.add_patch(FancyBboxPatch((x0, y1), break_w, y2 - y1, boxstyle="round,pad=0,rounding_size=0.06",
                                        fc=BREAK_FILL, ec=PATH, lw=2.6, zorder=2))
            ax.text(x0 + break_w / 2, (y1 + y2) / 2, f"♨\ncoffee\n{clock(T0 + a)} to\n{clock(T0 + e)}",
                    ha="center", va="center", fontsize=8.5, fontweight="bold", color="#9A6B12", zorder=3)
        path_boxes[st] = (x0, y1, break_w, y2 - y1)

    def mins(st):
        return (st[1], st[2]) if st[0] == "BREAK" else span(st[0], st[1])

    for k in range(len(path) - 1):
        a_st, b_st = path[k], path[k + 1]
        if a_st not in path_boxes or b_st not in path_boxes:
            continue
        (ax1, ay1, aw, ah), (bx1, by1, bw, bh) = path_boxes[a_st], path_boxes[b_st]
        if a_st[0] == b_st[0]:
            s0, s1 = (ax1 + aw / 2, ay1 + ah), (bx1 + bw / 2, by1)
        else:
            right = bx1 > ax1
            s0 = (ax1 + aw if right else ax1, ay1 + ah - 0.25)
            s1 = (bx1 if right else bx1 + bw, by1 + 0.25)
        ax.add_patch(FancyArrowPatch(s0, s1, arrowstyle="-|>", mutation_scale=15, lw=2.4,
                                     color=PATH, zorder=6))
        if a_st[0] != b_st[0] and "BREAK" not in (a_st[0], b_st[0]):
            overlap = mins(a_st)[1] - mins(b_st)[0]
            label = " MOVE " if overlap < 0.5 else f" MOVE, {round(overlap)} min overlap "
            ax.text(ax1 + aw / 2, ay1 + ah - 0.13, label, ha="center", va="center", fontsize=8,
                    fontweight="bold", color="white", zorder=7,
                    bbox=dict(boxstyle="round,pad=0.3", fc="#3B528B", ec="#3B528B"))

    ny = H - bottom + 0.18
    ax.text(left, ny, "What this path gives up", fontsize=9.5, fontweight="bold", color="#1F2933", va="top")
    ax.text(left, ny + 0.23, "\n".join(textwrap.wrap(r["gives_up"], ww(125))), fontsize=8.5,
            color="#1F2933", va="top", linespacing=1.3)
    # the note at the foot keeps its Arial wrap in every font: DejaVu sets 130 characters at 7.4 pt in about 7 inches,
    # inside the 7.8 the page gives, and a narrower wrap would push its last line toward the foot of the page
    ax.text(left, H - 0.55, "\n".join(textwrap.wrap(
        "Thick outline and arrows: the path I recommend. Tap a blue name for the presenter’s website "
        "and the rest of the box for the paper. The ↗ line says what opens. A filled tag is someone "
        f"you know from your profile (CV, website, class lists, past programs){' or your mail' if MAIL_SEARCHED else ''}, an outlined tag a likely tie"
        + (", ♥ someone close to you or familiar, with the reason for a familiar one. " if HEARTS else ". ") + TIMES_NOTE,
        130)), fontsize=7.4, color="#4C566A", va="top", linespacing=1.3)
    pdf.savefig(fig)
    plt.close(fig)


def keynote_label(x):
    # a keynote typed into the extra rows file, for a program whose keynotes are not ranked blocks
    return f"{SYM.get(x.get('tier', 1), '★')} Keynote: {x['speaker']}, {x['title']} ({x.get('room', '')})"


# the days at a glance, one list per day in time order, built from the data files. Row kinds: "logi" an
# official break, meal or social (the user's networking time), "sess" a session, "key" a block with a must-see on the
# path (a keynote included), "me" the user's own session or a meeting of the user's own, "cof" the user's own coffee, "ex" an
# exercise option, "arr" where to go on arrival. A block not yet ranked is left off the cover
def day_rows():
    def main_line(b):
        r = RANK[b]
        # the rooms in the order the path visits them, so the line never sends the user to the wrong
        # room first
        rooms = []
        for st in r["path"]:
            if st["code"] != "BREAK" and (not rooms or rooms[-1] != st["code"]):
                rooms.append(st["code"])
        here = ", then ".join(f"{heading(c)} ({SESS[c]['room']})" for c in rooms)
        # a backup room is named only when the path does not already visit it
        bk = ", ".join(f"{sess_label(x['code'])} {SESS[x['code']]['room']}" for x in r["backups"]
                       if x["code"] not in rooms)
        return f"{here}." + (f"  Backup: {bk}" if bk else "")

    def coffee(b):
        # the user's own coffee windows and meetings, read from the block's path, so the cover and the page never disagree
        out = []
        t0 = block_meta(b)["start_min"]
        for st in RANK[b]["path"]:
            if st["code"] != "BREAK":
                continue
            a, e = t0 + st["break_start_min"], t0 + st["break_end_min"]
            if st.get("label"):
                out.append((clock(a), f"YOUR MEETING, {clock(a)} to {clock(e)}: {st['label']}. " + st.get("note", ""),
                            "me"))
            else:
                out.append((clock(a), f"♨ Your own coffee, {clock(a)} to {clock(e)}: " + RANK[b].get("coffee_note", ""),
                            "cof"))
        return out

    out = {}
    for day, full in DAY_HEADING.items():
        rows = []
        for e in EVENTS:
            if e["day"] != day or e["title"].lower().startswith(EVENT_SKIP):
                continue
            title = event_title(e["title"])
            rows.append((minutes(e["start"]), clock(minutes(e["start"])), EVENT_NOTE.get(title) or f"{title}: network",
                         "logi"))
        for bb in SESSION_ORDER:
            if bb not in RANK or first_session(bb)["day"] != day:
                continue
            t0, dur = block_meta(bb)["start_min"], block_meta(bb)["dur"]
            mine = [st for st in RANK[bb]["path"] if st["code"] != "BREAK" and tier_of(st["code"], next(
                x for x in RANK[bb]["talks"] if x["code"] == st["code"] and x["order"] == st["order"])) == "ME"]
            if mine:
                c = mine[0]["code"]
                rows.append((t0, clock(t0), f"YOUR SESSION, {heading(c)} ({SESS[c]['room']}), {clock(t0, True)} to "
                             f"{clock(t0 + dur, True)}: be in the room by {clock(t0 - 10, True)}. " + MY_SESSION_NOTE, "me"))
                continue
            line = f"{block_name(bb)}: " + main_line(bb)
            if RANK[bb].get("skip_ok"):
                line += "  Lighter slot for you: a good one to skip for a break."
            on = {(st["code"], st.get("order")) for st in RANK[bb]["path"]}
            kind = "key" if any(t["tier"] == 2 for t in RANK[bb]["talks"] if (t["code"], t["order"]) in on) else "sess"
            rows.append((t0, clock(t0), line, kind))
            for cr in coffee(bb):
                rows.append((t0 + 1, cr[0], cr[1], cr[2]))
        for x in EXTRA:
            if x["day"] == day:
                # a keynote typed into the extra rows is green on the cover only when it is a must-see
                kind = "sess" if x["kind"] == "key" and x.get("tier", 1) < 2 else x["kind"]
                rows.append((minutes(x["start"]) - 0.5, clock(minutes(x["start"])),
                             x.get("label") or keynote_label(x), kind))
        rows.sort(key=lambda row: row[0])
        out[full] = [(t, lab, k) for _, t, lab, k in rows]
    return out


def cover_lines(label, kind):
    return textwrap.wrap(label, ww(92 if kind in ("me", "arr") else 100))


def new_page(pdf, fig):
    pdf.savefig(fig)
    plt.close(fig)
    fig = plt.figure(figsize=(8.5, 11))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 8.5)
    ax.set_ylim(11, 0)
    ax.axis("off")
    return fig, ax


def draw_cover(pdf):
    fig = plt.figure(figsize=(8.5, 11))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 8.5)
    ax.set_ylim(11, 0)
    ax.axis("off")
    fit_title(fig, ax.text(0.35, 0.45, TITLE, fontsize=18, fontweight="bold", color="#1F2933", va="center"), 8.5 - 0.7)
    intro = (f"{VENUE_DATES}. " + ("The pages after this one list the people to find, then one page per "
             "session" if PEOPLE else "One page per session follows") + ": rooms across the top, time running "
             "down, the path drawn through it.")
    intro_lines = textwrap.wrap(intro, ww(118))
    ax.text(0.35, 0.72, "\n".join(intro_lines),
            fontsize=9.5, color="#1F2933", va="top", linespacing=1.3)
    fill = {"logi": "#F4F5F6", "sess": "#EAF4F3", "key": "#E3F1DE", "me": "#CFE7E5", "cof": BREAK_FILL,
            "ex": EX_FILL, "arr": "#CFE7E5"}
    edge = {"logi": "#C9CDD2", "sess": "#8CC5C0", "key": "#7FB77E", "me": "#21918C", "cof": BREAK_EDGE,
            "ex": EX_EDGE, "arr": "#21918C"}
    # the first day starts below however many lines the intro took (four lines ran into the heading)
    y = max(1.35, 0.72 + 0.17 * len(intro_lines) + 0.32)
    pages = 1
    days = day_rows()
    for day, rows in days.items():
        # a day that would not fit below the previous one starts a new cover page, and the page count is
        # returned so the session pages' links go on the right pages
        need = 0.36 + sum(0.26 + 0.15 * (len(cover_lines(lab, k)) - 1) + 0.065 for _, lab, k in rows)
        if y + need > 10.6:
            fig, ax = new_page(pdf, fig)
            pages += 1
            y = 0.5
        ax.text(0.35, y, day, fontsize=12.5, fontweight="bold", color="#1F2933", va="center")
        y += 0.36
        for t, label, kind in rows:
            lines = cover_lines(label, kind)
            h = 0.26 + 0.15 * (len(lines) - 1)
            # y is the row's center: a taller row moves its center down by half its extra height, so it never
            # overlaps the row above (a three-line row of the user's own session covered the registration row)
            y += (h - 0.26) / 2
            ax.text(0.5, y, t, fontsize=10, fontweight="bold", color="#1F2933", va="center")
            ax.add_patch(FancyBboxPatch((1.15, y - h / 2), 6.95, h, boxstyle="round,pad=0,rounding_size=0.05",
                                        fc=fill[kind], ec=edge[kind], lw=1.4 if kind == "me" else 0.7))
            ax.text(1.27, y, "\n".join(lines), fontsize=8.8, color="#1F2933", va="center",
                    fontweight="bold" if kind in ("me", "arr") else "normal", linespacing=1.2)
            y += h / 2 + 0.13 + 0.065
        y += 0.12
    letters = {}
    for c, s in SESS.items():
        if c[-1].isalpha():
            letters[c[-1]] = s["room"]
    # every label as wide as the longest room name needs, wrapping to a new row at the right edge:
    # labels sized for a short name let two long room names run into each other
    cw = max(0.76, 0.2 + 0.075 / WRAP * max((len(n) for n in letters.values()), default=0))
    per_row = max(1, int((8.5 - 0.35 - 0.37 + 0.12) // (cw + 0.12)))
    if y + 0.4 + 0.62 * (-(-len(letters) // per_row)) + 0.9 > 10.8:
        fig, ax = new_page(pdf, fig)
        pages += 1
        y = 0.5
    ax.text(0.35, y, "Rooms: the session letter is the room for the whole meeting", fontsize=10.5,
            fontweight="bold", color="#1F2933", va="center")
    y += 0.4
    cx = 0.37 + cw / 2
    for L in sorted(letters):
        if cx + cw / 2 > 8.5 - 0.35:
            cx, y = 0.37 + cw / 2, y + 0.62
        ax.add_patch(FancyBboxPatch((cx - cw / 2, y - 0.15), cw, 0.3, boxstyle="round,pad=0.02,rounding_size=0.05",
                                    fc=CHIP_FILL, ec=CHIP_EDGE, lw=0.8))
        ax.text(cx, y, letters[L], ha="center", va="center", fontsize=7.6, fontweight="bold", color=CHIP_TEXT)
        ax.text(cx, y + 0.3, L, ha="center", va="center", fontsize=10, color="#4C566A")
        cx += cw + 0.12
    # the note under the key names only the row kinds this cover has
    kinds = {k for rows in days.values() for _, _, k in rows}
    teal = ([("your own session" if any(lab.startswith("YOUR SESSION") for rows in days.values() for _, lab, k in rows
                                       if k == "me") else "")]
            + ["your meetings" if any(st.get("label") for r in RANK.values() for st in r["path"]) else ""]
            + ["where to go on arrival" if "arr" in kinds else ""])
    teal = [x for x in teal if x]
    note = " ".join(x for x in [
        "Gray rows: official breaks, meals and socials, your networking time." if "logi" in kinds else "",
        "Amber rows: your own coffee windows, each over the least relevant stretch of its block." if "cof" in kinds else "",
        ("Teal rows: " + (", ".join(teal[:-1]) + " and " + teal[-1] if len(teal) > 1 else teal[0]) + ".") if teal else "",
        "Green rows: a block with a must-see on your path." if "key" in kinds else ""] if x)
    if any(r.get("skip_ok") for r in RANK.values()):
        note += " \"Lighter slot\": a plenary or invited slot with nothing strong for you, a good one to skip."
    if "ex" in kinds:
        note += " Blue rows with ☀: exercise options."
    if HEARTS:
        note += (" ♥: people close or familiar to you, with the reason for a familiar one, shown wherever they "
                 "present.")
    ax.text(0.35, y + 0.55, "\n".join(textwrap.wrap(note, ww(130))), fontsize=7.6, color="#4C566A", va="top")
    pdf.savefig(fig)
    plt.close(fig)
    return pages


def draw_people(pdf):
    pages = 1
    fig = plt.figure(figsize=(8.5, 11))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set_xlim(0, 8.5)
    ax.set_ylim(11, 0)
    ax.axis("off")
    ax.text(0.35, 0.45, "People to find", fontsize=17, fontweight="bold", color="#1F2933", va="center")
    ax.text(0.35, 0.75, "\n".join(textwrap.wrap(
        ("Filled tag: a documented tie in your profile (CV, website, class lists, past programs or people you named), "
         "or a direct mail exchange. " if MAIL_SEARCHED else
         "Filled tag: a documented tie in your profile (CV, website, class lists, past programs or people you named). ") + "Outlined tag: a likely tie, worth checking "
        "before you say hello. " + ("♥: someone close or familiar to you, with the reason for a familiar one. " if HEARTS else "")
        + ("" if MAIL_SEARCHED else "Your mail was not searched for this list. ")
        + "At the meeting: their roles there.", ww(125))),
        fontsize=8.8, color="#4C566A", va="top")
    y = 1.35
    order = {"knows": 0, "probably": 1}
    for p in sorted(PEOPLE, key=lambda q: (order[q["tier"]], q["name"])):
        if y > 10.3:
            pages += 1
            fig, ax = new_page(pdf, fig)
            ax.text(0.35, 0.45, "People to find, continued", fontsize=17, fontweight="bold",
                    color="#1F2933", va="center")
            y = 0.95
        guess = p["tier"] != "knows"
        tag_box(ax, 0.4, y - 0.08, p.get("mark") or ("knows" if not guess else "likely"), guess, 7.5)
        ax.text(1.1, y, "\n".join(textwrap.wrap(p["name"], ww(22))), fontsize=9.2, fontweight="bold",
                color="#1F2933", va="center", linespacing=1.1)
        body = f"{p['tie']}  At the meeting: {p['where']}"
        lines = textwrap.wrap(body, ww(104))
        ax.text(2.75, y, "\n".join(lines), fontsize=7.7, color="#1F2933", va="center", linespacing=1.15)
        # a little more space between rows, so each person reads as a separate entry
        y += max(0.36, 0.135 * len(lines) + 0.16)
    pdf.savefig(fig)
    plt.close(fig)
    return pages


def main():
    order = [b for b in SESSION_ORDER if b in RANK]
    with PdfPages(OUT) as pdf:
        # session pages follow however many pages the cover and the people list took; no people page
        # until the people check has a list, and the version's caption says so
        first = draw_cover(pdf)
        first += draw_people(pdf) if PEOPLE else 0
        for k, b in enumerate(order, start=first):
            draw_session(pdf, b, k)
    if HOTSPOTS:
        import fitz
        doc = fitz.open(OUT)
        for page_no, (x0, y0, x1, y1), url in HOTSPOTS:
            doc[page_no].insert_link({"kind": fitz.LINK_URI, "uri": url,
                                      "from": fitz.Rect(x0 * 72, y0 * 72, x1 * 72, y1 * 72)})
        tmp = OUT.with_suffix(".tmp.pdf")
        doc.save(tmp)
        doc.close()
        tmp.replace(OUT)
    print(f"sessions drawn: {order}   links placed: {len(HOTSPOTS)}")
    print("wrote", OUT)


if __name__ == "__main__":
    main()

// TEMPLATE: the first-run orchestration. Launch it with the Workflow tool
// in Claude Code (load the workflow-authoring skill first), and only when the user has opted in to a
// multi-agent workflow. Every input and output lives in the conference's conf_guide/ folder, agents'
// files in its agents/. The user's profile (SKILL.md, "First run") supplies owner_name, owner_line,
// dept, known_ties and the email answer.
// Pass args:
//   folder          the conference's conf_guide/ folder (absolute path), where every input and output lives
//   prefix          the file prefix used there, e.g. "2027_05_XYZ"
//   conference      the meeting's full name, dates and venue, e.g. "XYZ 2027 Meeting (Venue, May 3-4, 2027)"
//   program_url     the live program URL
//   program_format  one paragraph on how the live program is laid out and how to read it (for a
//                   two-column PDF: read each column separately with pdftotext -x -y -W -H crops)
//   times_note      how talk times are set, e.g. "the program gives only session times, so each talk's
//                   slot is the session divided evenly by the talks in its room" or "each talk has its
//                   own start and end in the parsed program"
//   owner_name      the user's name as the profile records it
//   owner_line      one line on who the user is, read from the profile, e.g. "a PhD candidate in
//                   development and urban economics"
//   profile_dir     the profile folder, e.g. "/Users/<name>/.claude/conference-guide"
//   roles           the user's roles at the meeting from the parsed program, e.g. "presents 5G talk 1;
//                   discusses 3B talk 2; chairs 6C", or "attending only"
//   blocks          [{id, codes, day, time, note}] one per block of parallel sessions, the next session
//                   first; codes lists the block's session codes, e.g. ["2A", "2B", "2C"]
//   fetch_abstracts true when the program has no abstracts: each block first fetches and checks one
//                   abstract per talk, so the ranking reads an abstract for every talk
//   local_chunks    arrays of names that matched the profile, the past programs or a folder the
//                   user named (about 30 names each)
//   gmail_chunks    arrays of presenters, discussants and chairs (about 25 names each); [] when the
//                   profile says the user's email is not searched or no mail tool is connected
//   mail_tool       the session's read-only mail search tool (ToolSearch "select:<name>")
//   mailbox         which account that tool reads, recorded before launch
//   known_ties      one paragraph of the user's documented ties, read from the profile at run time, with the
//                   classmates the inline class-list match found on this program (name, program, tag)
//   dept            the user's department as a short tag
//   clock           optional: the user's clock format, e.g. "24-hour clock times such as 14:30";
//                   12-hour clock times by default
//   more_breaks     true when the user asked for more break space: every big parallel
//                   block proposes its own coffee window and the merge keeps up to two a day; false
//                   keeps one a day
// At one large meeting this ran 49 agents: the seven reviewed blocks came back 8 to 17 minutes after
// launch, and the full run took 69 minutes, most of it one retried link check.
export const meta = {
  name: 'conference-guide-first-run',
  description: 'Rank every talk against the user portfolio, review each block, find and check links, check the live program, and find the people the user knows',
  phases: [
    { title: 'Abstracts', detail: 'only when the program has none: fetch, then check each quote' },
    { title: 'Rank', detail: 'one agent per parallel-session block' },
    { title: 'Review', detail: 'skeptic re-tiers each block and fixes the path' },
    { title: 'Links', detail: 'paper and presenter-site links for the rooms on the grid' },
    { title: 'Check', detail: 'live-program accuracy and link verification' },
    { title: 'People', detail: 'profile and past programs, optional read-only mail search, then an evidence check' },
  ],
}

const D = args.folder
const AG = `${args.folder}/agents`
const PROGRAM = `${args.folder}/${args.prefix}_program_parsed.json`
const BRIEF = `${args.folder}/${args.prefix}_portfolio_brief.md`
const BLOCKS = args.blocks
const GMAIL = args.gmail_chunks
const LOCAL = args.local_chunks

const TALK = {type:'object', properties:{
  code:{type:'string'}, order:{type:'integer'}, presenter:{type:'string'}, affiliation_short:{type:'string'},
  title:{type:'string'}, tier:{type:'integer'}, why:{type:'string'}, project:{type:'string'}},
  required:['code','order','presenter','affiliation_short','title','tier','why','project']}
const STOP = {type:'object', properties:{code:{type:'string'}, order:{type:'integer'},
  break_start_min:{type:'number'}, break_end_min:{type:'number'}}, required:['code']}
const ALT = {type:'object', properties:{stop_code:{type:'string'}, stop_order:{type:'integer'},
  alt_code:{type:'string'}, alt_order:{type:'integer'}, why:{type:'string'}},
  required:['stop_code','stop_order','alt_code','alt_order','why']}
const RANK = {type:'object', properties:{
  block:{type:'string'}, talks:{type:'array', items:TALK},
  rooms_to_show:{type:'array', items:{type:'string'}}, main_room:{type:'string'},
  backups:{type:'array', items:{type:'object', properties:{code:{type:'string'}, note:{type:'string'}}, required:['code','note']}},
  path:{type:'array', items:STOP}, alternatives:{type:'array', items:ALT},
  plan:{type:'string'}, gives_up:{type:'string'}, coffee_note:{type:'string'},
  changes:{type:'array', items:{type:'string'}}},
  required:['block','talks','rooms_to_show','main_room','backups','path','alternatives','plan','gives_up','coffee_note']}

const RULES = `Inputs (read these files first):
- ${PROGRAM} : the live ${args.conference} program, parsed from ${args.program_url}. Each session has code (e.g. "2E"), room, day, start, end, chair, and talks in program order (order 0,1,2,... is the position in the room).
- ${BRIEF} : the user's projects with short names, anything the user down-weighted or retired, and the binding ranking and writing rules.
- ${AG}/abstracts_block_<block>.json, when it exists: checked abstracts for talks the program gives none.
Talk times: ${args.times_note}. Minutes in a path are minutes after the session start.
The user's roles at the meeting: ${args.roles}. A slot where the user presents or discusses is the user's own: the path is in that room for that slot, no coffee window covers it, it gets no alternative, and its why reads "Your talk" or "You discuss" (tier 2). A session the user chairs keeps the path in that room for the whole session, with no coffee window and no alternatives.
Writing rules for every why, plan, gives_up, coffee_note, backup note and alternative why: plain words, short lines, "you" for the user (never he, she or a name), no he or she for a presenter, chair or anyone else, since names do not tell pronouns (repeat the surname or recast), ${args.clock || '12-hour clock times such as 2:30'}.`

function absPrompt(b) {
  return `Fetch abstracts for block ${b.id} of the ${args.conference} (${b.day}, ${b.time}). The program gives none. For every talk in the sessions ${b.codes.join(', ')} in ${PROGRAM}, open the paper link the program gives (else search for the paper by title and presenter), and quote its abstract verbatim: the first sentence, then the first later sentence that states a result, joined by " ... ", every run of words exactly as in the source, every omission marked " ... ". Label what the text is (paper, working paper page, registry entry, seminar page, author page) and record any caveat (retitled version, no public draft, midline results). A talk with nothing found gets text "" and a note. Recipes for Dropbox, Google Drive and working-paper pages are in the conference-guide skill's references/build_recipe.md.
Write {"<code>|<order>": {text, source_kind, source_url, caveat}} to ${AG}/abstracts_block_${b.id}.json, then return a one-line count.`
}

function absCheckPrompt(b) {
  return `Independent quote check for ${AG}/abstracts_block_${b.id}.json (${args.conference}). You did not write these quotes. For each entry, open source_url and compare word by word: every run of words between ellipses must appear verbatim and in order, every omission must be marked, and source_kind must say what the text is. Fix a quote only by re-quoting from the source; blank one you cannot verify and say why in caveat. Add "verdict": "ok", "fixed" or "blanked" to each entry, overwrite the file, and return counts.`
}

function rankPrompt(b) {
  return `You are ranking one block of parallel sessions at the ${args.conference} for ${args.owner_name}, ${args.owner_line}.
${RULES}

Your block: parallel session ${b.id} (${b.day}, ${b.time}), sessions ${b.codes.join(', ')}.
${b.note}

Do this:
1. Read every talk in every room of this block, including its abstract. Tier each talk (2 must-see, 1 strong, 0 less relevant) against the WHOLE portfolio, with a "why" of at most 90 characters naming the project short name it connects to, or saying plainly that it has no link, and "project" = the short name or "none". A talk with no abstract anywhere is ranked from its title, and its why says so. affiliation_short: a compact form of the presenter's affiliation. presenter: the presenter's NAME ONLY, without the affiliation in parentheses.
2. Pick the user's MAIN room and one or two BACKUP rooms, each backup with a one-sentence note on when the user would pick it instead (e.g. "Pick Room B at 10:00 if the transit talk matters more to you today than the history pair").
3. path: the talks the user sits in, in time order, as {code, order}; at most one or two room moves in the session, preferring rooms with the same number of talks so each move falls on a clean boundary.
4. alternatives: for EVERY talk stop on the path except the user's own slot, the single best talk in ANOTHER room that overlaps it in time (alt_code, alt_order), with a why of at most 70 characters saying what it offers. Prefer starred talks; if nothing at that time is starred, give the best one and say it is less relevant.
5. rooms_to_show: 3 to 5 rooms, main first, then backups, then every room holding an alternative, then any room holding a starred talk.
6. Own coffee: ${args.more_breaks ? 'The user asked for more break space, so propose ONE window {code:"BREAK", break_start_min, break_end_min} in this block over its least relevant stretch on the path, and when every slot holds a must-see, over the weakest must-see, which then becomes the alternative of the window. It never covers the user\'s own slots' : 'if a whole less-relevant talk slot sits on the path, you may propose ONE window {code:"BREAK", break_start_min, break_end_min} over it, provided the window covers no starred talk and none of the user\'s own slots'}. Give that window its own alternative (stop_code "BREAK", stop_order = break_start_min). The session running this workflow keeps ${args.more_breaks ? 'at most two windows a day' : 'at most one window a day'}, the weakest stretches, so say in coffee_note how weak the stretch is.
7. plan: one or two sentences (where to sit, when to move, when the coffee window is). gives_up: one or two sentences naming every must-see the path misses and the strong ones (presenter surname and room code). coffee_note: one sentence naming the starred talks the window overlaps, if any.
Return the full object. talks must list EVERY talk in every room of the block.`
}

function reviewPrompt(b, r) {
  return `You are the independent skeptic for one block of the ${args.conference} guide for ${args.owner_name}. A first agent produced the ranking below. Try to REFUTE it, then return a corrected version.
${RULES}

Block: parallel session ${b.id} (${b.day}, ${b.time}). ${b.note}

First agent's output:
${JSON.stringify(r)}

Do this:
1. For every tier-2 must-see, argue against it: is the link to the named project real, read from the abstract, or a keyword match? Demote any that does not hold. Must-see is for a direct link to a project's question, setting, method, or model. A project the user down-weighted in the brief earns nothing on its own.
2. Read ALL abstracts in the block, every room, and promote any talk tiered too low that plainly connects to one of the user's projects.
3. Check each why against the abstract and the writing rules.
4. Check the path: every stop exists, at most two moves, no coffee window over the user's own slot or over a starred talk${args.more_breaks ? ' (except the weakest must-see of a block where every slot holds one, kept as the alternative of the window)' : ''}, main room and backups still sensible, gives_up names every missed must-see.
5. Check alternatives: one per talk stop except the user's own slot, each in another room and overlapping its stop, each alternative's room listed in rooms_to_show.
6. Check every talk's presenter (name only), title, code and order against ${PROGRAM}.
Return the corrected full object with "changes" listing what you changed (empty if nothing). Before returning, ALSO write it to ${AG}/rank_block_${b.id}.json with the Write tool, so the build can start before the whole run ends.`
}

const LINKS = {type:'object', properties:{links:{type:'array', items:{type:'object', properties:{
  code:{type:'string'}, order:{type:'integer'}, presenter:{type:'string'},
  paper_url:{type:'string'}, paper_kind:{type:'string'}, site_url:{type:'string'}, site_kind:{type:'string'}, note:{type:'string'},
  coauthors:{type:'array', items:{type:'string'}}},
  required:['code','order','presenter','paper_url','paper_kind','site_url','site_kind']}}}, required:['links']}

function linkPrompt(b, r) {
  const alt = new Set((r.alternatives || []).map(a => `${a.alt_code}|${a.alt_order}`))
  const shown = r.talks.filter(t => r.rooms_to_show.includes(t.code) || alt.has(`${t.code}|${t.order}`))
  return `Find links for talks at the ${args.conference}. Load the web tools first with ToolSearch query "select:WebSearch,WebFetch" (curl via Bash also works).
For each talk below, find:
- paper_url: the paper, preferring (1) a PDF or page of this paper on the presenter's or a coauthor's own website, (2) an NBER/SSRN/arXiv/CEPR/Fed working-paper page, (3) a conference or seminar page with this abstract, (4) the presenter's own page if no paper exists. paper_kind: one of "paper", "working paper page", "seminar page", "author page", "coauthor page", or "registry entry" for a trial registry page (AEA RCT Registry and the like). A clearly retitled version of the same project counts; say so in note.
- coauthors: when the program prints the presenter only, the paper's other authors as the paper or the presenter's site lists them; [] when the program lists them or nothing is found.
- site_url: the presenter's own website, else a faculty or student page, else Google Scholar. site_kind: "personal site", "faculty page", "student page", "Google Scholar".
Use "" when nothing is found. Never guess a URL: every URL you return must be one you opened or saw in search results for THIS person. Unescape HTML entities (&amp; to &).
Talks (block ${b.id}):
${JSON.stringify(shown.map(t => ({code:t.code, order:t.order, presenter:t.presenter, affiliation:t.affiliation_short, title:t.title})))}`
}

function verifyLinkPrompt(b, found) {
  return `Independently verify links found for ${args.conference} talks (block ${b.id}); you did not find them. Load WebFetch with ToolSearch "select:WebFetch" and use curl -sL -A "Mozilla/5.0" -o /dev/null -w "%{http_code} %{url_effective}" via Bash. A site that answers curl with 403 may open through WebFetch; try it before rejecting.
For each entry: confirm paper_url resolves AND is this presenter's paper (same person, the program title or clearly the same project); confirm site_url is the SAME person (affiliation or research listed matches), and neither a directory page nor a same-name stranger. Blank any URL that fails and say why in note. A link to SSRN or to any host that blocks automated reads (403, a Cloudflare check, a sign-in wall) is KEPT: blank a link only when it belongs to another person or another paper or the page is dead (404, a parked domain). Match a blocked link another way and say so in note: the Crossref record of its DOI (SSRN is 10.2139/ssrn.<id>) or its IDEAS/RePEc record gives the title and authors. Do not wait out or work around a bot check.
Program titles are in ${PROGRAM}.
Entries:
${JSON.stringify(found.links)}
Return the verified list (same fields). note: "ok" or what was rejected and why.`
}

const PCHECK = {type:'object', properties:{errors:{type:'array', items:{type:'object', properties:{
  code:{type:'string'}, order:{type:'integer'}, field:{type:'string'}, guide_value:{type:'string'}, live_value:{type:'string'}},
  required:['code','field','guide_value','live_value']}}, talks_checked:{type:'integer'}, fetched_at_note:{type:'string'}},
  required:['errors','talks_checked']}

function programCheckPrompt(b, r) {
  return `Program-accuracy check for the ${args.conference} guide, block ${b.id}. Do NOT trust any local copy or the builder's parser: download the LIVE program yourself now from ${args.program_url} into ${AG}/live_check_${b.id} (curl -sL -A "Mozilla/5.0", and curl -sI for any last-modified header), and read it yourself. How the program is laid out: ${args.program_format}
Compare every talk in the guide's block below against the live program: session code, room, day and time, order within the room (0-based, read in true order), presenter, title (ignore case and punctuation-only differences), and that affiliation_short is a fair short form of the live affiliation. Report each mismatch.
Guide's block:
${JSON.stringify(r.talks.map(t => ({code:t.code, order:t.order, presenter:t.presenter, affiliation_short:t.affiliation_short, title:t.title})))}`
}

const LOCALP = {type:'object', properties:{people:{type:'array', items:{type:'object', properties:{
  name:{type:'string'}, tier:{type:'string', enum:['knows','probably','none']}, tie:{type:'string'},
  evidence_files:{type:'array', items:{type:'string'}}, evidence_summary:{type:'string'}},
  required:['name','tier','tie','evidence_summary']}}}, required:['people']}

function localPrompt(names) {
  return `People check for ${args.owner_name} at the ${args.conference}. For each name below, a text search found the name in the user's profile, in a past conference program, or in a folder the user named. Decide whether the sources show a real tie.
The user's profile is ${args.profile_dir}/profile.md, with one record per known person in ${args.profile_dir}/known_people.json (each with its tie and its source) and past programs as text in ${args.profile_dir}/past_programs/ (index.json names each meeting). The file list per name is in ${AG}/namehits_summary.txt (name line, then indented paths); raw matches are in ${AG}/namehits_raw.txt; the past programs the hits point to are copied to ${AG}/confpdf/; each person's roles at this meeting are in ${AG}/names.json.
Open the actual sources (grep -n -i the name with a few lines of context) and classify:
- "knows": a documented tie: a known_people.json record with tier "knows" for the same person; coauthor, advisor, committee member, reference or visit host from the CV; same department (${args.dept}) as faculty or PhD student; in the same session as the user at a past meeting (presenter, discussant or chair of that session); a discussant of the user's paper or someone whose paper the user discussed; a fellow participant in a small workshop or summer school the user attended (a cohort list under 40 people); a classmate on a class list the user supplied (a known_people.json record with tie "classmate", matched on the first name or its initial as well as the surname, allowing for accents, middle names and preferred first names, never on the surname alone); a person the user named.
- "probably": no direct evidence but a strong reason: the same session block at a past meeting without a shared session, the same small event, a coauthor of a coauthor, the same subfield plus overlapping institutions, the same school and years with no class list or other evidence. Say the reason.
- "none": only a cited author (a paper's references, literature notes, a reading list, a syllabus, a bibliography), a big program the user did not share a session with, a job posting, a same-name stranger, a known_people.json record with tier "struck", or a file a conference guide wrote (a mark a guide wrote is never a tie).
For "knows" and "probably", tie: a short tag such as "${args.dept}", "coauthor", "summer school <year>", "same session <year>", "emailed <year>". evidence_summary: one sentence naming the source and what it shows, at its true strength (describe a mailing to a list as a list mailing). Mind common names, where several people share a short surname: require the source to show the same person by affiliation.
Names: ${JSON.stringify(names)}
Return every name with a tier.`
}

const MAILP = {type:'object', properties:{searched:{type:'integer'}, hits:{type:'array', items:{type:'object', properties:{
  name:{type:'string'}, threads:{type:'integer'}, direct_exchange:{type:'boolean'}, first_date:{type:'string'}, last_date:{type:'string'}, note:{type:'string'}},
  required:['name','threads','direct_exchange','note']}}}, required:['searched','hits']}

function mailPrompt(names) {
  return `Read-only mail check for ${args.owner_name} before the ${args.conference}. The mailbox is ${args.mailbox}. Load the search tool with ToolSearch query "select:${args.mail_tool}" (and a thread reader only if needed to count participants). NEVER draft, send, label, trash, or modify anything.
For each name below, search the last two years, e.g. "First Last" newer_than:2y (try the surname plus the first name if the full string finds nothing; for very common names require the right affiliation in the thread).
Count as a real exchange ONLY a thread where the person wrote to the user or the user wrote to them, with a small recipient list (under about 10). Do NOT count: mass mailings, listservs, seminar or conference announcements, newsletters, association or working-paper digests, job-market lists, cohort threads with 30+ recipients, calendar notifications, social-network notifications, or a name mentioned inside a digest.
Report ONLY names with at least one thread mentioning them: threads (count), direct_exchange (true only for a real exchange as defined), first_date and last_date (YYYY-MM), and a note of at most 12 words on the kind of thread (e.g. "two-way thread about a discussant slot", "session assignment mail", "listserv only"). Do not quote mail content.
Names (${names.length}): ${JSON.stringify(names)}
searched = number of names you searched.`
}

const FINALP = {type:'object', properties:{people:{type:'array', items:{type:'object', properties:{
  name:{type:'string'}, tier:{type:'string', enum:['knows','probably']}, tag:{type:'string'}, tie:{type:'string'},
  evidence:{type:'string'}, where:{type:'string'}}, required:['name','tier','tag','tie','evidence','where']}},
  rejected:{type:'array', items:{type:'object', properties:{name:{type:'string'}, reason:{type:'string'}}, required:['name','reason']}}},
  required:['people','rejected']}

phase('Rank')
const blockWork = pipeline(BLOCKS,
  b => (args.fetch_abstracts
        ? agent(absPrompt(b), {label:`abstracts:${b.id}`, phase:'Abstracts'})
            .then(() => agent(absCheckPrompt(b), {label:`quote-check:${b.id}`, phase:'Abstracts'}))
        : Promise.resolve(null))
      .then(() => agent(rankPrompt(b), {label:`rank:${b.id}`, phase:'Rank', schema:RANK})),
  (r, b) => r ? agent(reviewPrompt(b, r), {label:`review:${b.id}`, phase:'Review', schema:RANK}).then(v => v || r) : null,
  (r, b) => r ? Promise.all([
      agent(linkPrompt(b, r), {label:`links:${b.id}`, phase:'Links', schema:LINKS})
        .then(f => f ? agent(verifyLinkPrompt(b, f), {label:`verify-links:${b.id}`, phase:'Check', schema:LINKS}).then(v => v || f) : null),
      agent(programCheckPrompt(b, r), {label:`program:${b.id}`, phase:'Check', schema:PCHECK}),
    ]).then(([links, pcheck]) => ({block:b.id, rank:r, links, pcheck})) : null
)

const peopleWork = (async () => {
  const local = parallel(LOCAL.map((names, i) => () => agent(localPrompt(names), {label:`people-local:${i+1}`, phase:'People', schema:LOCALP})))
  const mail = parallel(GMAIL.map((names, i) => () => agent(mailPrompt(names), {label:`people-mail:${i+1}`, phase:'People', schema:MAILP})))
  const [L, M] = await Promise.all([local, mail])
  const localPeople = L.filter(Boolean).flatMap(x => x.people).filter(p => p.tier !== 'none')
  const mailHits = M.filter(Boolean).flatMap(x => x.hits).filter(h => h.threads > 0)
  log(`people: ${localPeople.length} local candidates, ${mailHits.length} mail hits`)
  const final = await agent(`Final evidence check on the people ${args.owner_name} knows or probably knows at the ${args.conference}. You did not produce these claims; reject any that do not hold.
Candidates from the profile, past programs and any folder the user named: ${JSON.stringify(localPeople)}
Candidates from a read-only mail search of ${args.mailbox || 'no mailbox'} (counts only): ${JSON.stringify(mailHits)}
Known facts from the user's profile, including the classmates the inline class-list match found (keep each as "knows" with its tag unless a source contradicts it): ${args.known_ties}
Each person's roles at the meeting are in ${AG}/names.json and the sessions in ${PROGRAM}.
Rules: a documented tie is "knows"; a strong reason without direct evidence is "probably"; a shared institution alone is at most "probably"; a sign-up sheet shows only a booked slot; a mail thread counts only if it is a direct exchange; a listserv or digest is nothing; a file a conference guide or planning pass wrote is never evidence. Where both sources speak, merge. You may open the files to check (${AG}/namehits_summary.txt lists files per name).
For each surviving person: tag = at most 22 characters naming the tie, addressed to the user as "you" (e.g. "${args.dept}", "coauthor", "your MA classmate", "emailed <year>", "chairs your session"); tie = one sentence stating the evidence at its true strength, with no he or she for a presenter, chair or anyone else, since names do not tell pronouns (repeat the surname or recast); evidence = where it is recorded (a file's short name or "mail, N direct threads, YYYY-MM"); where = their roles at the meeting with session code, day and time (e.g. "chairs 1A Fri 9:00; discusses 1A"), or "attending, no program role".
Also list rejected claims with the reason. Before returning, ALSO write {"people": [...], "rejected": [...]} to ${AG}/people_final.json with the Write tool.`, {label:'people-final', phase:'People', schema:FINALP})
  return {final, localPeople, mailHits}
})()

const [blocks, people] = await Promise.all([blockWork, peopleWork])
return {blocks: blocks.filter(Boolean), people}

// TEMPLATE: the re-rank orchestration, run after the user corrects the ranking mid-conference. Launch it with the Workflow tool in Claude Code (workflow-authoring skill
// first), only with the user's opt-in to a multi-agent workflow. Before launching: write the
// correction into the portfolio brief in the conf_guide/ folder, and copy the first run's
// agents/rank_block_*.json into agents/v1/, which this run reads as its starting point.
// Pass args:
//   folder, prefix, conference, times_note, roles, owner_name, clock   as in workflow_rank_template.js
//   correction    the user's words, verbatim
//   retired       lists or contacts the user retired, e.g. "a contact list the user retired"
//   downweighted  projects that no longer earn a star on their own
//   keep_fixes    earlier wording fixes to keep where the text survives
//   links_file    the collected links file in the folder, e.g. "2027_05_XYZ_grid_links.json"
//   blocks        [{id, codes, day, time, note}], the next session first
//   more_breaks   true when the user asked for more break space, as in workflow_rank_template.js
// It re-tiers, re-paths, adds the per-stop alternatives, reviews each block, and fills links for talks
// newly shown. Its link agents check their own URLs, which is not the independent check: run a
// separate verifier on the links it adds (references/validation_prompts.md).
export const meta = {
  name: 'conference-rerank',
  description: 'Re-rank conference sessions after a correction from the user, add per-slot alternatives, review each block, and fill missing links',
  phases: [
    { title: 'Rerank', detail: 'one agent per block re-tiers and re-paths' },
    { title: 'Review', detail: 'skeptic checks each block' },
    { title: 'Links', detail: 'find links for talks newly shown' },
  ],
}
const D = args.folder
const AG = `${args.folder}/agents`
const PROGRAM = `${args.folder}/${args.prefix}_program_parsed.json`
const BRIEF = `${args.folder}/${args.prefix}_portfolio_brief.md`
const BLOCKS = args.blocks

const TALK = {type:'object', properties:{
  code:{type:'string'}, order:{type:'integer'}, presenter:{type:'string'}, affiliation_short:{type:'string'},
  title:{type:'string'}, tier:{type:'integer'}, why:{type:'string'}, project:{type:'string'}},
  required:['code','order','presenter','affiliation_short','title','tier','why','project']}
const STOP = {type:'object', properties:{code:{type:'string'}, order:{type:'integer'},
  break_start_min:{type:'number'}, break_end_min:{type:'number'}}, required:['code']}
const ALT = {type:'object', properties:{stop_code:{type:'string'}, stop_order:{type:'integer'},
  alt_code:{type:'string'}, alt_order:{type:'integer'}, why:{type:'string'}}, required:['stop_code','stop_order','alt_code','alt_order','why']}
const RANK = {type:'object', properties:{
  block:{type:'string'}, talks:{type:'array', items:TALK},
  rooms_to_show:{type:'array', items:{type:'string'}}, main_room:{type:'string'},
  backups:{type:'array', items:{type:'object', properties:{code:{type:'string'}, note:{type:'string'}}, required:['code','note']}},
  path:{type:'array', items:STOP}, alternatives:{type:'array', items:ALT},
  plan:{type:'string'}, gives_up:{type:'string'}, coffee_note:{type:'string'},
  changes:{type:'array', items:{type:'string'}}},
  required:['block','talks','rooms_to_show','main_room','backups','path','alternatives','plan','gives_up','coffee_note','changes']}

const COMMON = `Files:
- ${BRIEF} : the user's projects and the binding ranking and writing rules. Read its section on what the user down-weighted or retired FIRST.
- ${PROGRAM} : the live ${args.conference} program (sessions with code, room, day, start, end, talks in order with authors, discussant, abstract).
- ${AG}/abstracts_block_<block>.json, when it exists: checked abstracts for talks the program gives none.
Time rule: ${args.times_note}. Minutes in a BREAK stop are minutes after the session start.
The user's roles at the meeting: ${args.roles}. A slot where the user presents or discusses is the user's own: the path is in that room for that slot, no coffee window covers it, it gets no alternative, and its why reads "Your talk" or "You discuss" (tier 2). A session the user chairs keeps the path in that room for the whole session, with no coffee window and no alternatives.
The user's correction, verbatim: ${args.correction}
Keep these earlier wording fixes where the text survives: ${args.keep_fixes}
Writing rules for every why, plan, gives_up, coffee_note, backup note and alternative why: plain words, short lines, "you" for the user (never he, she or a name), no he or she for a presenter, chair or anyone else, since names do not tell pronouns (repeat the surname or recast). why at most 90 characters; alternative why at most 70. ${args.clock || '12-hour clock times such as 2:30'}.`

function rerankPrompt(b) {
  return `Re-rank one block of the ${args.conference} guide for ${args.owner_name} after the user's correction.
${COMMON}

Your block: parallel session ${b.id} (${b.day}, ${b.time}), sessions ${b.codes.join(', ')}. ${b.note}
The current ranking is ${AG}/v1/rank_block_${b.id}.json. Start from it.
1. Remove every mention of anything the user retired: ${args.retired}.
2. Every talk whose tier rests on a project the user down-weighted (${args.downweighted}), read from its project field or from a why that leans on that project's topics, is re-tiered using ONLY the user's other projects. Read its abstract. It stays starred only if it links to another project on its own merits; otherwise tier 0 with a why that says plainly it has no link (never "no tie to your other projects"). Re-check every other tier-2 talk too: must-see needs a direct link to a remaining project's question, setting, method or model.
3. Re-derive main_room, backups (one or two, each note one sentence on when to pick it), path (at most two moves, preferring rooms with the same number of talks), at most ONE own-coffee BREAK in the block, over a whole less-relevant slot on the path, on a stretch with no starred talk and none of the user's own slots${args.more_breaks ? ' (the user asked for more break space: when every slot holds a must-see, the window goes over the weakest must-see, kept as the alternative of the window, and the merge keeps up to two windows a day)' : ' (the merge keeps one window a day)'}, plan, gives_up (every missed must-see and the strong ones, surname and room code), and coffee_note (naming any starred talk the window overlaps).
4. alternatives: for EVERY talk stop on the path except the user's own slot, the single best talk in ANOTHER room that overlaps it (alt_code, alt_order), why at most 70 characters; a coffee BREAK stop gets one too (stop_code "BREAK", stop_order = break_start_min).
5. rooms_to_show: 3 to 5 rooms, main first, then backups, then every room holding an alternative, then any room holding a starred talk.
6. changes: one line per change you made versus the current ranking.
Write the full object to ${AG}/rank2_block_${b.id}.json with the Write tool, then return it.`
}

function reviewPrompt(b, r) {
  return `Independent skeptic for block ${b.id} of ${args.owner_name}'s ${args.conference} guide, after the user's correction. Try to refute the re-ranking below, then return a corrected version.
${COMMON}
Block: parallel session ${b.id} (${b.day}, ${b.time}). ${b.note}
Re-ranking to check:
${JSON.stringify(r)}
Check: (1) no mention anywhere of what the user retired (${args.retired}); (2) no talk keeps a star because of a down-weighted project alone (${args.downweighted}): read each such abstract yourself, and a reworded why on an unchanged tier does not count as a fix; (3) every tier-2 has a direct link to a remaining project, read from the abstract; (4) no tier-0 talk that plainly links to a remaining project (read ALL abstracts in the block); (5) path stops valid, at most two moves, no break over the user's slot or over a starred path talk${args.more_breaks ? ' (except the weakest must-see of a block where every slot holds one)' : ''}, every clock time in the text matching the time rule and the program; (6) gives_up names every missed must-see; (7) every alternative overlaps its stop, sits in another room shown in rooms_to_show, and the user's own slot has none; (8) writing rules, with no he or she for anyone.
Return the corrected full object with "changes" listing what YOU changed (empty if nothing). Also write it to ${AG}/rank2_block_${b.id}.json with the Write tool before returning (overwrite).`
}

const LINKS = {type:'object', properties:{links:{type:'array', items:{type:'object', properties:{
  code:{type:'string'}, order:{type:'integer'}, presenter:{type:'string'},
  paper_url:{type:'string'}, paper_kind:{type:'string'}, site_url:{type:'string'}, site_kind:{type:'string'}, note:{type:'string'},
  coauthors:{type:'array', items:{type:'string'}}},
  required:['code','order','presenter','paper_url','paper_kind','site_url','site_kind']}}}, required:['links']}

function linkPrompt(b, r) {
  const shown = r.talks.filter(t => r.rooms_to_show.includes(t.code) || (r.alternatives||[]).some(a => a.alt_code===t.code && a.alt_order===t.order))
  return `Find links for ${args.conference} talks (block ${b.id}). Load tools with ToolSearch "select:WebSearch,WebFetch" (curl via Bash also works).
First read ${D}/${args.links_file} (keys "code|order"). SKIP any talk that already has an entry there with a non-empty site_url. For every other talk below find:
- paper_url: the paper, preferring (1) a PDF or page of this paper on the presenter's or a coauthor's site, (2) an NBER/SSRN/arXiv/CEPR/Fed working-paper page, (3) a seminar page with this abstract, (4) the presenter's page. paper_kind: "paper", "working paper page", "seminar page", "author page", "coauthor page", or "registry entry" for a trial registry page. A retitled version of the same project counts; say so in note.
- coauthors: when the program prints the presenter only, the paper's other authors as the paper or the presenter's site lists them; [] when the program lists them or nothing is found.
- site_url: the presenter's own site, else a faculty or student page, else Google Scholar. site_kind accordingly.
Open each URL you return and confirm it is this person's paper or page (the same person, and neither a directory list nor a same-name stranger). Never guess a URL. Unescape &amp; to &.
Talks:
${JSON.stringify(shown.map(t => ({code:t.code, order:t.order, presenter:t.presenter, affiliation:t.affiliation_short, title:t.title})))}
Return only the talks you searched.`
}

const out = await pipeline(BLOCKS,
  b => agent(rerankPrompt(b), {label:`rerank:${b.id}`, phase:'Rerank', schema:RANK}),
  (r, b) => r ? agent(reviewPrompt(b, r), {label:`review2:${b.id}`, phase:'Review', schema:RANK}).then(v => v || r) : null,
  (r, b) => r ? agent(linkPrompt(b, r), {label:`links2:${b.id}`, phase:'Links', schema:LINKS}).then(l => ({block:b.id, rank:r, links:l})) : null,
)
return out.filter(Boolean)

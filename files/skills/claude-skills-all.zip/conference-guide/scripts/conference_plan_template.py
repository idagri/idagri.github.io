#!/usr/bin/env python3
# TEMPLATE: the companion-table builder. Per conference, edit the SETTINGS block. Copy it into the
# conference's conf_guide/ folder as build_<conf>_schedule.py and run
# `python3 build_<conf>_schedule.py [build folder]`, with the build folder inside the conference folder
# (default: conf_guide/latex_build/). Needs xelatex with fontspec; without it the markdown twin is still written
#
# Builds the companion plan: one landscape PDF and one markdown file from the same data the room grid
# reads, so the two can never disagree. Each day is one table with six columns: time, room, the talk
# on the path (every author linked) with the reason under it, and three alternatives: the one chosen
# for the stop, then the next two best talks running at the same time in other rooms. Session
# headers, breaks, meetings, exercise options and coffee rows span the columns they need, computed
# from the column widths so every row is the same width. The starred talks' abstracts follow each
# day, quoted from the program page or from the checked abstracts file, with cuts marked and the
# source named. With the folder's <PREFIX>_career_events.json (fields in career_events.py, written only when the
# profile puts mentoring and career events first), a "Don't miss" box of every mentoring and career event opens the
# document, each event's row is purple with its Option 1 label and its Alternative 1 is Option 2, and each day says
# when it was checked with none. Without that file the document is built as before

import json
import re
import shutil
import subprocess
import sys
import textwrap
from pathlib import Path
from urllib.parse import quote_plus

HERE = Path(__file__).resolve().parent

# ---------------------------------------------------------------------------------------------
# SETTINGS: the only values that change per conference
# ---------------------------------------------------------------------------------------------
PREFIX = "<YYYY_MM_CONF>"
TITLE = "<Meeting name>"
VENUE_DATES = "<Venue>, <Month D and D>"
ME = "<YOUR NAME AS THE PROGRAM PRINTS IT>"
# the room of a keynote row typed into the extra rows file without a room of its own
KEYNOTE_ROOM = "<room>"
# True prints 24-hour clock times (14:30), False the 12-hour clock (2:30), as the profile's clock format says
CLOCK_24 = False
# short names for the Room column, which is 1.7 cm wide: two long room names ran 10 to 18 pt past a
# narrow column until a map like this was added; the legend at the top keeps the full names
ROOM_SHORT = {
    # "<Long Room Name, Lower Level>": "<Short Name>",
}
# the program's day value to the heading of that day's table, in the order of the days
DAY_HEADING = {"<Month D>": "<Weekday>, <Month D>", "<Month D+1>": "<Weekday>, <Month D+1>"}
# the program's events by title: an event left out (matched on the lowercase start of the title), and the
# wording for an event that needs more than "<title>: network", such as a dinner not on the user's registration
EVENT_SKIP = ("changeover",)
EVENT_NOTE = {
    # "<Conference dinner>": "Conference dinner, <venue> (regular registration only)",
}


def event_title(title):
    # an event's title as the table shows it; Oxford Abstracts adds a tail after " - " and a "Social N: " lead
    return re.sub(r"^Social \d+: ", "", title.split(" - ")[0])


STEM = f"{PREFIX}_conference_plan"
# the LaTeX build folder: conf_guide/latex_build/ beside this script, inside the conference folder, or a folder passed
# on the command line. A system temporary folder can be emptied by a restart or a cleanup, so it is never the default
AUX = Path(sys.argv[1]) if len(sys.argv) > 1 else HERE / "latex_build"


def load(name, default):
    p = HERE / name
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else default


# the program with the merge's spelling corrections in every name field
PROGRAM = load(f"{PREFIX}_program_builders.json", [])
RANK = load(f"{PREFIX}_grid_rank.json", {}).get("blocks", {})
LINKS = load(f"{PREFIX}_grid_links.json", {})
PEOPLE = {p["name"]: p for p in load(f"{PREFIX}_people.json", {}).get("people", [])}
ASKED = set(load(f"{PREFIX}_asked.json", []))
# abstracts fetched from papers when the program gives none, keyed "code|order":
# {text, source_kind, source_url, caveat, verdict}; a quote the checker blanked is left out
ABSTRACTS = load(f"{PREFIX}_abstracts.json", {})
# the program's breaks, meals and socials, {day, start, end, title}, and the rows the program does not hold,
# {day, start, kind, label}, the same file the grid reads: "ex" an exercise option, "arr" where to go on
# arrival, "logi" a break or meal typed by hand, "key" a keynote that is not a ranked block (with tier, title,
# speaker, affiliation, room and note in place of label)
EVENTS = load(f"{PREFIX}_program_events.json", [])
EXTRA = load(f"{PREFIX}_extra_rows.json", [])
# mentoring and career events, Option 1 when the profile puts them first, and the days checked with none. Without that
# file in the folder it is an empty dict, and the document is built as before
CAREER = load(f"{PREFIX}_career_events.json", {})
CAREER_EVENTS = CAREER.get("events", [])
CAREER_BY_CODE = {e["code"]: e for e in CAREER_EVENTS if e.get("code")}
# an event whose eligibility is unclear is still Option 1, marked in words to check access, so every font prints it
CHECK_ACCESS = "CHECK ACCESS"
SESS = {s["code"]: s for s in PROGRAM}

# column widths in cm and the gap LaTeX puts on each side of a cell (tabcolsep 4pt = 0.1411cm);
# a cell spanning columns i..j is sum(widths) + 2 * tabcolsep * (j - i), which keeps every row the
# same total width; the six columns and their gaps, 24.4 cm, fit the 25.4 cm landscape text width
WIDTHS = [1.0, 1.7, 6.2, 4.6, 4.6, 4.6]
SEP = 0.1411
NCOL = len(WIDTHS)


def span_width(i, j):
    return sum(WIDTHS[i:j + 1]) + 2 * SEP * (j - i)


def minutes(hm):
    h, m = hm.split(":")
    return int(h) * 60 + int(m)


def clock(t):
    h, m = divmod(int(round(t)), 60)
    return f"{h:02d}:{m:02d}" if CLOCK_24 else f"{(h - 1) % 12 + 1}:{m:02d}"


def theme(code):
    return SESS[code]["title"].split(". ", 1)[1]


def names_slot(code):
    # a block_label every room of the block shares names the time slot ("Block I" over six rooms), so the label
    # names the block and the room keeps its code (a program that named its time slots once printed "Blocks I, I,
    # I, I, I and I")
    labs = [SESS[c].get("block_label", "") for c in SESS if c[:-1] == code[:-1] and c[-1:].isalpha()]
    return len(labs) > 1 and len(set(labs)) == 1 and bool(labs[0])


def sess_label(code):
    # the program's own name for a session when it numbers sessions its own way, else the code
    return SESS[code].get("block_label") if SESS[code].get("block_label") and not names_slot(code) else code


def heading(code):
    # "Block 7: Migration" when the program names its sessions, else "2E Development"
    return f"{sess_label(code)}: {theme(code)}" if sess_label(code) != code else f"{code} {theme(code)}"


def block_name(b):
    # a block as the program names its sessions ("Blocks 3 and 4") or its time slot ("Block I"), else "Session <b>"
    labs = [SESS[c].get("block_label", "").split(None, 1) for c in sorted(SESS) if c[:-1] == b and c[-1].isalpha()]
    if not labs or any(len(x) != 2 for x in labs) or len({x[0] for x in labs}) > 1:
        return "Session " + b
    nums = list(dict.fromkeys(x[1] for x in labs))
    return labs[0][0] + ("s " + ", ".join(nums[:-1]) + " and " + nums[-1] if len(nums) > 1 else " " + nums[0])


def room_short(code):
    return ROOM_SHORT.get(SESS[code]["room"], SESS[code]["room"])


def person_of(field):
    # the affiliation is the LAST parenthesis, since a name can hold one of its own
    m = re.match(r"^(.*)\s\(([^()]*)\)\s*$", field.strip())
    return m.group(1).strip() if m else field.strip()


def affil_of(field):
    m = re.match(r"^(.*)\s\(([^()]*)\)\s*$", field.strip())
    return m.group(2).strip() if m else ""


def talk_span(code, order):
    # the talk's own start and end when the program gives them, else its share of the even split of its session
    s = SESS[code]
    p = s["talks"][order]
    if p.get("start") and p.get("end"):
        return minutes(p["start"]), minutes(p["end"])
    a, e, n = minutes(s["start"]), minutes(s["end"]), len(s["talks"])
    return a + (e - a) * order / n, a + (e - a) * (order + 1) / n


def talk_time(code, order):
    return talk_span(code, order)[0]


def tier_of(code, x):
    # the user's own slot (the user presents or discusses), a talk the user asked to catch, else the relevance tier, a hearted
    # presenter's included
    p = SESS[code]["talks"][x["order"]]
    if x["presenter"] == ME:
        return "ME"
    if person_of(p.get("discussant", "")) == ME:
        return "DISC"
    # a mentoring or career event has a purple tier of its own
    if code in CAREER_BY_CODE:
        return "C"
    return "A" if x["presenter"] in ASKED else x["tier"]


def abstract_of(code, order):
    # (text, source label): the program's own abstract first, else the checked fetched one
    p = SESS[code]["talks"][order]
    if p.get("abstract"):
        return trim_abstract(p["abstract"]), "program page"
    a = ABSTRACTS.get(f"{code}|{order}", {})
    if a.get("text") and a.get("verdict") != "blanked":
        return a["text"], a.get("source_kind", "paper")
    return "", ""


def tag(name):
    # people's marks, set by the user in the people file: a close person's tag is the pink heart
    # with no tie wording, and a familiar one's the pink heart and the short reason
    p = PEOPLE.get(name)
    if not p:
        return ""
    if p.get("mark") == "♥":
        return "♥" if p.get("close") else "♥ " + p["tag"]
    return ("knows: " if p["tier"] == "knows" else "likely: ") + p["tag"]


def mark_rank(p):
    # close people first, then the other marked people, then everyone else
    return 0 if p.get("mark") and p.get("close") else 1 if p.get("mark") else 2


def known_here(b):
    # every presenter the user knows in the block, the marked ones first, and every marked coauthor with the
    # affiliation, each with room and start, for the session header row
    out = []
    for c, sess in SESS.items():
        if c[:-1] != b:
            continue
        for i, t in enumerate(sess["talks"]):
            st = talk_time(c, i)
            names = [x.strip() for x in re.split(r";| and |, ", re.sub(r"\s*\([^()]*\)", "", t["presenter"]))]
            for nm in names:
                p = PEOPLE.get(nm)
                if p and p["tier"] == "knows":
                    mk = p.get("mark", "")
                    out.append((mark_rank(p), st, (mk + " " if mk else "") + nm
                                + f" ({sess['room']}, {clock(st)})"))
            for nm in [a.strip() for a in t["authors"].split(", ")]:
                p = PEOPLE.get(nm)
                if p and p.get("mark") and nm not in names:
                    inside = ", ".join(x for x in (t.get("affils", {}).get(nm, ""),
                                                   "" if p.get("close") else p["tag"]) if x)
                    out.append((mark_rank(p), st, f"{p['mark']} {nm}" + (f" ({inside})" if inside else "")
                                + f", coauthor, {sess['room']} {clock(st)}"))
    return [x[2] for x in sorted(out)]


def extra_alts(b, a, e, skip):
    # the next two best talks overlapping [a, e) by at least 10 minutes, each in a room other than the stop's and
    # the first alternative's, none on the path: the second and third alternative columns, so a meeting with many
    # concurrent sessions shows more than one option at each stop
    r = RANK[b]
    on = {(x["code"], x["order"]) for x in r["path"] if x["code"] != "BREAK"}
    cands = []
    for t in r["talks"]:
        if t["code"] in skip or (t["code"], t["order"]) in on or t["tier"] < 1:
            continue
        s, f = talk_span(t["code"], t["order"])
        ov = min(e, f) - max(a, s)
        if ov >= 10:
            cands.append((-t["tier"], -ov, t["code"], t))
    out, rooms = [], set()
    for _, _, c, t in sorted(cands, key=lambda z: z[:3]):
        if c in rooms:
            continue
        rooms.add(c)
        out.append({"alt_code": c, "alt_order": t["order"], "why": t["why"]})
        if len(out) == 2:
            break
    return out + [None] * (2 - len(out))


def lookup_url(name):
    return "https://scholar.google.com/citations?view_op=search_authors&mauthors=" + quote_plus(name)


def authors(code, order):
    # the presenter first, then the coauthors, as the program lists them; a program that prints the
    # presenter only leaves them to the links file, where the link agents record them from the paper
    # or the presenter's site
    p = SESS[code]["talks"][order]
    pres = person_of(p["presenter"])
    names = [a.strip() for a in re.split(r",| and ", p["authors"]) if a.strip()]
    names += LINKS.get(f"{code}|{order}", {}).get("coauthors", [])
    return pres, [n for n in dict.fromkeys(names) if n != pres]


def trim_abstract(text):
    # first sentence, then the first later sentence that states a result, joined by a marked cut;
    # every run of words is verbatim from the program page
    sents = re.split(r"(?<=[.!?])\s+(?=[A-Z])", text.strip())
    if len(sents) <= 2:
        return text.strip()
    first = sents[0]
    res = next((s for s in sents[1:] if re.search(r"\b(find|finds|found|show|shows|estimate|document|"
                                                   r"results?|increase|reduce|raise|lower)\b", s, re.I)), None)
    if res is None:
        return first + " ..."
    k = sents.index(res)
    return first + (" " if k == 1 else " ... ") + res + (" ..." if k < len(sents) - 1 else "")


def rank_of(code, order):
    return next(x for x in RANK[code[:-1]]["talks"] if x["code"] == code and x["order"] == order)


# ---------------------------------------------------------------------------------------------
# rows per day
#   ("sess", b)  ("talk", code, order, alt, [alt2, alt3])  ("cof", window, why, alt, [alt2, alt3])
#   ("meet", window, text)  ("logi", time, label)  ("ex", time, label)  ("arr", time, label)
#   ("key", tier, time, title, speaker, affiliation, note, room)
# ---------------------------------------------------------------------------------------------

def block_rows(b):
    # a block not yet ranked is left out of this version
    if b not in RANK:
        return []
    r = RANK[b]
    s0 = next(v for k, v in SESS.items() if k[:-1] == b and k[-1].isalpha())
    a = minutes(s0["start"])
    alt = {(x["stop_code"], x["stop_order"]): x for x in r.get("alternatives", [])}
    rows = [("sess", b)]
    for st in r["path"]:
        if st["code"] != "BREAK":
            s, e = talk_span(st["code"], st["order"])
            a1 = alt.get((st["code"], st["order"]))
            skip = {st["code"]} | ({a1["alt_code"]} if a1 else set())
            # a stop with no alternative (the user's own slot, a single-room block) gets no computed ones either
            ex = extra_alts(b, s, e, skip) if a1 else [None, None]
            rows.append(("talk", st["code"], st["order"], a1, ex))
        elif st.get("label"):
            # a meeting of the user's own on the path: its own teal row, with no alternative
            rows.append(("meet", f"{clock(a + st['break_start_min'])} to {clock(a + st['break_end_min'])}",
                         st["label"] + ". " + st.get("note", "")))
        else:
            a1 = alt.get(("BREAK", st["break_start_min"]))
            rows.append(("cof", f"{clock(a + st['break_start_min'])} to {clock(a + st['break_end_min'])}",
                         r["coffee_note"], a1,
                         extra_alts(b, a + st["break_start_min"], a + st["break_end_min"],
                                    {a1["alt_code"]} if a1 else set())))
    return rows


def day_of(day):
    # the program's breaks, meals and socials as gray rows, each block's rows at its start, and the extra rows,
    # in time order
    items = []
    for e in EVENTS:
        if e["day"] != day or e["title"].lower().startswith(EVENT_SKIP):
            continue
        title = event_title(e["title"])
        items.append((minutes(e["start"]), [("logi", clock(minutes(e["start"])), EVENT_NOTE.get(title) or f"{title}: network")]))
    for b in RANK:
        s0 = next(v for k, v in SESS.items() if k[:-1] == b and k[-1].isalpha())
        if s0["day"] == day:
            items.append((minutes(s0["start"]), block_rows(b)))
    for x in EXTRA:
        if x["day"] != day:
            continue
        t = clock(minutes(x["start"]))
        row = (("key", x.get("tier", 1), t, x["title"], x["speaker"], x.get("affiliation", ""), x.get("note", ""),
                x.get("room") or KEYNOTE_ROOM) if x["kind"] == "key" else (x["kind"], t, x["label"]))
        items.append((minutes(x["start"]) - 0.5, [row]))
    items.sort(key=lambda z: z[0])
    return [r for _, rows in items for r in rows]


DAYS = [(heading_, (lambda d=day: day_of(d))) for day, heading_ in DAY_HEADING.items()]
# a day's heading back to the program's day value, for that day's line on mentoring and career events
HEADING_DAY = {heading_: day for day, heading_ in DAY_HEADING.items()}


def esc(s):
    s = s.replace("\\", "\\textbackslash{}")
    for a, b in [("&", "\\&"), ("%", "\\%"), ("$", "\\$"), ("#", "\\#"), ("_", "\\_"),
                 ("{", "\\{"), ("}", "\\}"), ("~", "\\textasciitilde{}"), ("^", "\\textasciicircum{}")]:
        s = s.replace(a, b)
    return s.replace("\\textbackslash\\{\\}", "\\textbackslash{}")


def url(u):
    # inside a table cell the URL is read as ordinary text, so & must be escaped or it splits the cell
    return u.replace("\\", "").replace("%", "\\%").replace("#", "\\#").replace("&", "\\&")


def href(u, text):
    return r"\href{" + url(u) + "}{" + text + "}"


def esc_heart(t):
    # every marked person's heart prints pink, since a smaller or paler mark is hard to notice
    return t.replace("♥", r"\textcolor{heartpink}{♥}")


def clock_ap(t):
    # 14:45 as "2:45 pm", as the grid prints a time, for the Don't miss box, which stands apart from the day tables
    return clock(t) if CLOCK_24 else clock(t) + (" am" if int(round(t)) // 60 < 12 else " pm")


def career_parts(e):
    # one event as plain text: the heading line, the mentors, the action or access line, the registration link, and
    # the program sessions where its mentors also appear (a second chance to meet them)
    head = (f"{DAY_HEADING.get(e['day'], e['day'])}, {clock_ap(minutes(e['start']))} to {clock_ap(minutes(e['end']))}, "
            f"{e.get('room') or 'room not given'}: {e['title']}")
    ms = e.get("mentors", [])
    who = (("Mentors: " + (", ".join(ms[:-1]) + " and " + ms[-1] if len(ms) > 1 else ms[0]) + ". ") if ms else "")
    who += f"Found in: {e.get('source', 'program')}."
    el = e["eligibility"]
    if el == "registration form":
        act = "ACTION: register on its form" + (f", deadline {e['deadline']}" if e.get("deadline") else "") + "."
    elif el == "unclear":
        act = CHECK_ACCESS + ": who can attend is not stated."
    else:
        act = {"open": "Open to all attendees.", "application-only": "By application only."}[el]
    seen = [f"{x['name']} {x['role']} in "
            + (f"{SESS[x['code']]['room']} ({x['code']})" if x.get("code") in SESS else (x.get("code") or "the program"))
            + f", {x['when']}." for x in e.get("elsewhere", [])]
    return head, who, act, e.get("register_url", ""), ("Mentors elsewhere in the program: " + " ".join(seen)) if seen else ""


def career_order(e):
    # calendar order: the days in DAY_HEADING's order, then the start
    days = list(DAY_HEADING)
    return (days.index(e["day"]) if e["day"] in days else len(days), minutes(e["start"]))


def career_note(code):
    # under an Option 1 event's reason in its row: the mentors, and who can attend or the action to take
    _, who, act, link, _ = career_parts(CAREER_BY_CODE[code])
    flag = CAREER_BY_CODE[code]["eligibility"] in ("registration form", "unclear")
    return (r"\newline{\scriptsize " + esc(who) + r"}\newline{\scriptsize\textcolor{careerdark}{"
            + (r"\textbf{" + esc(act) + "}" if flag else esc(act)) + "}"
            + (" " + href(link, "Open the form.") if link else "") + "}")


def dont_miss_tex():
    # the Don't miss box at the top of the document: every mentoring and career event in calendar order, then each day
    # checked with none, in small gray type
    items = []
    for e in sorted(CAREER_EVENTS, key=career_order):
        head, who, act, link, seen = career_parts(e)
        flag = e["eligibility"] in ("registration form", "unclear")
        items.append(r"\careersym\ \textcolor{careerdark}{\textbf{" + esc(head) + r"}}\newline " + esc(who) + " "
                     + (r"\textcolor{careerdark}{\textbf{" + esc(act) + "}}" if flag else esc(act))
                     + (" " + href(link, "Open the form.") if link else "")
                     + (r"\newline{\scriptsize\textcolor{chiptheme}{" + esc(seen) + "}}" if seen else "") + r"\par")
    if not items:
        items.append(r"No mentoring or career event in the program or your mail.\par")
    neg = CAREER.get("negatives", {})
    days = list(DAY_HEADING) + [d for d in neg if d not in DAY_HEADING]
    negs = [esc(f"{DAY_HEADING.get(d, d)}: {neg[d]}") for d in days if neg.get(d)]
    return (r"\vspace{6pt}\noindent\fcolorbox{careerdark}{careerbg}{\parbox{\dimexpr\linewidth-2\fboxsep-2\fboxrule\relax}{"
            r"\raggedright\setlength{\parskip}{3pt}"
            r"{\normalsize\textcolor{careerdark}{\textbf{● Don't miss: mentoring and career events, always Option 1}}}\par"
            + "\n{\\footnotesize " + "\n".join(items) + "}"
            + ("\n{\\scriptsize\\textcolor{chiptheme}{" + r"\newline ".join(negs) + r"}}\par" if negs else "")
            + "}}\n")


def chip(code):
    # a light highlight label with the short room name, the session's name and theme under it, cut at 70
    # characters so a long session name does not lengthen the row
    return (r"\roomchip{" + esc(room_short(code)) + r"}\newline{\scriptsize\textcolor{chiptheme}{"
            + esc(textwrap.shorten(heading(code), 70, placeholder=" ...")) + "}}")


def sym(tier):
    return {2: r"\mustsym", 1: r"\strongsym", 0: r"\optsym", "ME": r"\mesym", "DISC": r"\mesym",
            "A": r"\askedsym", "C": r"\careersym"}[tier]


def talk_cell(code, order, tier, short=False):
    p = SESS[code]["talks"][order]
    link = LINKS.get(f"{code}|{order}", {})
    t = esc(p["title"])
    if link.get("paper_url"):
        t = href(link["paper_url"], t)
    if tier == "ME":
        t = r"\textbf{YOUR TALK.} " + t
    elif tier == "DISC":
        t = r"\textbf{YOU DISCUSS.} " + t
    elif tier == "C":
        # a mentoring or career event: Option 1 on the path, named as such in an alternative cell
        t = (r"\textcolor{careerdark}{\textbf{" + ("MENTORING/CAREER." if short else "OPTION 1, MENTORING/CAREER.")
             + r"}} " + t)
    pres, co = authors(code, order)
    site = link.get("site_url") or lookup_url(pres)
    who = href(site, r"\textbf{" + esc(pres) + "}")
    if tag(pres):
        who += r" \textcolor{askblue}{\textbf{[" + esc_heart(esc(tag(pres))) + "]}}"
    if affil_of(p["presenter"]):
        who += r", {\color{chiptheme}" + esc(affil_of(p["presenter"])) + "}"
    if co and not short:
        cos = []
        for c in co:
            s = href(lookup_url(c), esc(c))
            if tag(c):
                # a marked coauthor's tag adds the affiliation from the program's records
                af = p.get("affils", {}).get(c, "") if tag(c)[:1] == "♥" else ""
                s += r" \textcolor{askblue}{\textbf{[" + esc_heart(esc(tag(c) + (", " + af if af else ""))) + "]}}"
            cos.append(s)
        who += r"\newline{\scriptsize with " + ", ".join(cos) + "}"
    if p["discussant"] and not short:
        d = person_of(p["discussant"])
        who += (r"\newline{\scriptsize you discuss this paper}" if d == ME else
                r"\newline{\scriptsize disc. " + href(lookup_url(d), esc(d))
                + (r" \textcolor{askblue}{\textbf{[" + esc_heart(esc(tag(d))) + "]}}" if tag(d) else "") + "}")
    return sym(tier) + r"\ " + t + r"\newline " + who


def alt_cell(alt):
    if not alt:
        return ""
    code, order = alt["alt_code"], alt["alt_order"]
    x = rank_of(code, order)
    tier = tier_of(code, x)
    return (r"\roomchip{" + esc(room_short(code)) + r"}\ {\scriptsize\textcolor{chiptheme}{" + esc(sess_label(code))
            + r"}}\newline " + talk_cell(code, order, tier, short=True)
            + r"\newline{\scriptsize\textcolor{whyteal}{" + esc(alt["why"]) + "}}")


def alt_cells(row, i):
    # alternative 1 at position i of the row, then the computed alternatives 2 and 3 after it
    a1 = row[i] if len(row) > i else None
    rest = row[i + 1] if len(row) > i + 1 else [None, None]
    return " & ".join(alt_cell(y) for y in [a1] + list(rest))


def span_from(i, text):
    # a cell from column i to the last column
    return r"\multicolumn{" + str(NCOL - i) + r"}{p{" + f"{span_width(i, NCOL - 1):.3f}" + r"cm}}{" + text + "}"


def full(text, color):
    return r"\rowcolor{" + color + "}" + span_from(0, text) + r"\\"


def tex_rows(rows):
    out = []
    for r in rows:
        k = r[0]
        if k == "sess":
            b = r[1]
            R = RANK[b]
            s0 = next(v for kk, v in SESS.items() if kk[:-1] == b and kk[-1].isalpha())
            kh = known_here(b)
            head = (r"\rule{0pt}{14pt}\textbf{" + esc(block_name(b)) + r"\quad " + clock(minutes(s0["start"])) + " to "
                    + clock(minutes(s0["end"])) + r"}\quad " + esc(R["plan"])
                    + ((r"\newline\textcolor{whyteal}{\textbf{People you know presenting in this block:} "
                        + esc_heart(esc(", ".join(kh))) + "}") if kh else ""))
            out.append(full(head, "roombg"))
        elif k == "talk":
            _, code, order = r[:3]
            x = rank_of(code, order)
            tier = tier_of(code, x)
            color = {2: r"\rowcolor{mustbg}", "ME": r"\rowcolor{minebg}", "DISC": r"\rowcolor{minebg}",
                     "A": r"\rowcolor{askbg}", "C": r"\rowcolor{careerbg}"}.get(tier, "")
            # the reason sits under the talk, in the same cell, and an Option 1 event's mentors and access under that
            out.append(color + f"{clock(talk_time(code, order))} & {chip(code)} & {talk_cell(code, order, tier)}"
                       + r"\newline{\scriptsize\textcolor{whyteal}{" + esc(x["why"]) + "}}"
                       + (career_note(code) if tier == "C" else "") + " & " + alt_cells(r, 3) + r"\\")
        elif k == "cof":
            # the coffee row spans the time and talk columns' middle; its alternatives sit in the last three
            out.append(r"\rowcolor{cofbg}" + r"\CUP & \multicolumn{2}{p{" + f"{span_width(1, 2):.3f}"
                       + r"cm}}{\textbf{Your coffee, " + esc(r[1]) + r".} " + esc(r[2]) + r"} & "
                       + alt_cells(r, 3) + r"\\")
        elif k == "meet":
            out.append(r"\rowcolor{minebg}" + r[1].split(" to ")[0] + " & "
                       + span_from(1, r"\textbf{Your meeting, " + esc(r[1]) + r":} " + esc(r[2])) + r"\\")
        elif k == "logi":
            out.append(r"\rowcolor{logibg}" + r[1] + " & " + span_from(1, esc(r[2])) + r"\\")
        elif k in ("ex", "arr"):
            # an exercise option (light blue, with the sun) or where to go on arrival (teal, bold)
            out.append(r"\rowcolor{" + ("exbg" if k == "ex" else "minebg") + "}" + r[1] + " & "
                       + span_from(1, r"\textbf{" + esc(r[2]) + "}" if k == "arr" else esc(r[2])) + r"\\")
        elif k == "key":
            _, tier, t, title, who, aff, note, room = r
            out.append((r"\rowcolor{mustbg}" if tier == 2 else "") + t + r" & \roomchip{" + esc(ROOM_SHORT.get(room, room)) + "} & "
                       + sym(tier) + r"\ " + esc(title) + r"\newline " + href(lookup_url(who), r"\textbf{" + esc(who) + "}")
                       + (r", {\color{chiptheme}" + esc(aff) + "}" if aff else "")
                       + r"\newline{\scriptsize\textcolor{whyteal}{" + esc(note) + "}}" + " &" * (NCOL - 3) + r"\\")
    return "\n".join(out)


def abstract_items(rows):
    items, seen = [], set()
    for r in rows:
        if r[0] == "cof":
            # the coffee window's alternative is listed too, since it is the talk you would walk to
            if r[3]:
                items.append((r[3]["alt_code"], r[3]["alt_order"]))
            continue
        if r[0] != "talk":
            continue
        _, code, order, alt = r[:4]
        items.append((code, order))
        if alt:
            items.append((alt["alt_code"], alt["alt_order"]))
    out = []
    for code, order in items:
        x = rank_of(code, order)
        tier = tier_of(code, x)
        # the user's own slots and the mentoring or career events (described in the Don't miss box) get no abstract
        if (code, order) in seen or tier in ("ME", "DISC", "C") or (tier != "A" and tier < 1):
            continue
        seen.add((code, order))
        text, label = abstract_of(code, order)
        if text:
            out.append((code, order, tier, SESS[code]["talks"][order], text, label))
    return out


# the table's font: Arial Unicode MS on a Mac, which has the star, circle, hot-springs, sun and heart glyphs
# but no bold face, so bold is faked; elsewhere DejaVu Sans from matplotlib's own font folder, which has
# every symbol the table prints and a real bold face
MAC_FONT = Path("/System/Library/Fonts/Supplemental/Arial Unicode.ttf")


def font_line():
    if MAC_FONT.exists():
        return r"\setmainfont{Arial Unicode MS}[AutoFakeBold=2.5]"
    import matplotlib
    d = Path(matplotlib.get_data_path()) / "fonts" / "ttf"
    return r"\setmainfont{DejaVuSans.ttf}[Path=" + str(d) + r"/, BoldFont=DejaVuSans-Bold.ttf]"


PREAMBLE = r"""\documentclass[10pt]{article}
\usepackage[letterpaper,landscape,margin=0.5in,top=0.6in,bottom=0.55in]{geometry}
\usepackage{fontspec}
FONTLINE
\usepackage[table]{xcolor}
\usepackage{longtable}
\usepackage{array}
\usepackage{hyperref}
\hypersetup{colorlinks=true, urlcolor=linkblue, linkcolor=linkblue}
\definecolor{mustbg}{HTML}{E3F1DE}
\definecolor{logibg}{HTML}{F3F4F6}
\definecolor{exbg}{HTML}{E3ECF8}
\definecolor{cofbg}{HTML}{FBE8C6}
\definecolor{minebg}{HTML}{CFE7E5}
\definecolor{askbg}{HTML}{D3DAF0}
\definecolor{roombg}{HTML}{DCEEEC}
\definecolor{chipfill}{HTML}{DDE5F3}
\definecolor{chipedge}{HTML}{9FB2D9}
\definecolor{chiptext}{HTML}{2F4478}
\definecolor{chiptheme}{HTML}{5B6472}
\definecolor{headteal}{HTML}{21918C}
\definecolor{whyteal}{HTML}{1D6F6A}
\definecolor{mustgreen}{HTML}{3B7A57}
\definecolor{askblue}{HTML}{3B528B}
\definecolor{linkblue}{HTML}{1F5C99}
\definecolor{heartpink}{HTML}{D6457A}
\newcolumntype{R}[1]{>{\raggedright\arraybackslash}p{#1}}
\newcommand{\mustsym}{\textcolor{mustgreen}{\textbf{★★}}}
\newcommand{\strongsym}{\textcolor{headteal}{\textbf{★}}}
\newcommand{\optsym}{\textcolor{gray}{○}}
\newcommand{\mesym}{\textcolor{headteal}{\textbf{●}}}
\newcommand{\askedsym}{\textcolor{askblue}{\textbf{◆}}}
\newcommand{\CUP}{♨}
% a room as a light highlight label with dark blue type
\newcommand{\roomchip}[1]{{\setlength{\fboxsep}{1.8pt}\fcolorbox{chipedge}{chipfill}{\scriptsize\textcolor{chiptext}{\textbf{#1}}}}}
\setlength{\tabcolsep}{4pt}
\renewcommand{\arraystretch}{1.35}
\pagestyle{empty}
\begin{document}
"""


# the purple of the mentoring and career events, viridis dark for the dot, text and edges and a light tint for
# fills, defined only when the folder has a career events file, so a build without one writes the same .tex
CAREER_PREAMBLE = r"""\definecolor{careerbg}{HTML}{E8DDF0}
\definecolor{careerdark}{HTML}{440154}
\newcommand{\careersym}{\textcolor{careerdark}{\textbf{●}}}
"""


def build_tex():
    pre = PREAMBLE.replace("FONTLINE", font_line(), 1)
    parts = [pre.replace(r"\begin{document}", CAREER_PREAMBLE + r"\begin{document}") if CAREER else pre]
    letters = sorted({(c[-1], SESS[c]["room"]) for c in SESS if c[-1].isalpha()})
    # a real space after each label, so the key wraps: TeX swallows the space after a bare \enspace, and on a
    # program of 27 rooms the one-line key ran 303pt past the page
    legend = r"\enspace{} ".join(L + r"\," + r"\roomchip{" + esc(n) + "}" for L, n in letters)
    cols = "".join(f"R{{{w}cm}}" for w in WIDTHS)
    parts.append(r"""\noindent{\Large\textbf{TITLE}}\\[2pt]
{\large VENUE}\\[6pt]
{\footnotesize\raggedright
Companion to the room grid. \mustsym\ must-see, \strongsym\ strong, \optsym\ less relevant, \mesym\ your slot
(you present or discuss), \askedsym\ you asked for it. Green rows are must-see, teal rows your own slots and
meetings, blue rows the talks you asked for, light blue rows with ☀ exercise options, gray rows official breaks
and meals (your networking time), amber rows your own coffee. The reason for each talk sits under it.
Alternative 1 is the best talk at the same time in another room, and Alternatives 2 and 3 are the next best
talks overlapping it by at least 10 minutes in other rooms. Every name opens the person's website or a Google
Scholar lookup. Every linked title opens the paper. A bracketed tag is someone you know or likely know,
\textcolor{heartpink}{♥} someone close to you or familiar, with the reason for a familiar one. Talk times are the program's own, or each session split evenly among
its talks when the program gives only session times. Abstracts are quoted from the source named after each,
with every cut marked.\par}
\vspace{5pt}\noindent{\footnotesize\textbf{The session letter is the room for the whole meeting:}\enspace LEGEND\par}
\vspace{8pt}
""".replace("LEGEND", legend).replace("TITLE", esc(TITLE)).replace("VENUE", esc(VENUE_DATES)))
    if CAREER:
        # the Don't miss box above the first day, and what a purple row means when the file holds an event
        if CAREER_EVENTS:
            parts.append(r"\noindent{\footnotesize Purple rows with \careersym\ are a mentoring or career event, Option 1, "
                         r"and their Alternative 1 is Option 2, the best research talk at the same time.\par}")
        parts.append(dont_miss_tex())
        parts.append(r"\vspace{8pt}")
    for i, (day, fn) in enumerate(DAYS):
        rows = fn()
        if i:
            parts.append(r"\clearpage")
        parts.append(r"\noindent{\large\textbf{" + day + r"}}\\[4pt]")
        # the day checked for mentoring and career events with none found, in small gray type
        neg = CAREER.get("negatives", {}).get(HEADING_DAY.get(day, ""), "")
        if neg:
            parts.append(r"{\scriptsize\textcolor{chiptheme}{" + esc(neg) + r"}}\\[3pt]")
        parts.append(r"{\footnotesize" + "\n" + r"\begin{longtable}{" + cols + "}\n"
                     + r"\rowcolor{headteal}\textcolor{white}{\textbf{Time}} & \textcolor{white}{\textbf{Room}} & "
                     + r"\textcolor{white}{\textbf{Talk on your path, and why}} & "
                     + r"\textcolor{white}{\textbf{Alternative 1}} & \textcolor{white}{\textbf{Alternative 2}} & "
                     + r"\textcolor{white}{\textbf{Alternative 3}} \\" + "\n" + r"\endhead" + "\n")
        parts.append(tex_rows(rows))
        parts.append(r"\end{longtable}}")
        ab = abstract_items(rows)
        if ab:
            parts.append(r"\vspace{6pt}\noindent{\small\textbf{Abstracts of the starred talks on the path and the "
                         r"starred alternatives}}\par\vspace{4pt}")
            parts.append(r"{\footnotesize\raggedright\setlength{\parindent}{0pt}\setlength{\parskip}{4pt}")
            for code, order, tier, p, text, label in ab:
                parts.append(r"\textbf{" + clock(talk_time(code, order)) + " " + code + " " + sym(tier) + r"\ "
                             + esc(p["title"]) + r"} (" + esc(person_of(p["presenter"])) + r"). "
                             + esc(text) + r" \textcolor{chiptheme}{[" + esc(label) + r"]}\par")
            parts.append("}")
    parts.append(r"\end{document}")
    return "\n".join(parts)


def build_md():
    out = [f"# {TITLE}", "",
           f"{VENUE_DATES}. Companion to the room grid. The reason for each talk sits under it. Alternative 1 is",
           "the best talk at the same time in another room, and Alternatives 2 and 3 are the next best talks in other",
           "rooms. Abstracts are quoted from the source named after each, with every cut marked.", ""]
    sy = {2: "★★", 1: "★", 0: "○", "ME": "●", "DISC": "●", "A": "◆", "C": "●"}

    def md_career(e):
        # one mentoring or career event as the Don't miss list and its row print it
        head, who, act, link, seen = career_parts(e)
        return head, f"{who} **{act}**" + (f" [Open the form]({link})." if link else ""), seen

    if CAREER:
        # the Don't miss list, every event in calendar order, then each day checked with none
        out += ["## Don't miss: mentoring and career events, always Option 1", ""]
        for e in sorted(CAREER_EVENTS, key=career_order):
            head, body, seen = md_career(e)
            out.append(f"- **● {head}.** {body}" + (f" {seen}" if seen else ""))
        if not CAREER_EVENTS:
            out.append("- No mentoring or career event in the program or your mail.")
        neg = CAREER.get("negatives", {})
        out += [""] + [f"*{DAY_HEADING.get(d, d)}: {neg[d]}*" for d in list(DAY_HEADING) + [d for d in neg if d not in DAY_HEADING]
                       if neg.get(d)] + ([""] + (["Purple rows (●, OPTION 1) are a mentoring or career event, and their "
                                                  "Alternative 1 is Option 2, the best research talk at the same time."]
                                                 if CAREER_EVENTS else []) + [""])

    def md_talk(code, order, tier):
        p = SESS[code]["talks"][order]
        link = LINKS.get(f"{code}|{order}", {})
        ttl = f"[{p['title']}]({link['paper_url']})" if link.get("paper_url") else p["title"]
        pres, co = authors(code, order)
        site = link.get("site_url") or lookup_url(pres)
        tg = f" [{tag(pres)}]" if tag(pres) else ""
        return f"{sy[tier]} {ttl}, [{pres}]({site}){tg} ({affil_of(p['presenter'])})"

    def md_alt(y):
        if not y:
            return ""
        z = rank_of(y["alt_code"], y["alt_order"])
        return (f"{SESS[y['alt_code']]['room']} ({y['alt_code']}): "
                f"{md_talk(y['alt_code'], y['alt_order'], tier_of(y['alt_code'], z))}. {y['why']}")

    def md_alts(row, i):
        a1 = row[i] if len(row) > i else None
        rest = row[i + 1] if len(row) > i + 1 else [None, None]
        return " | ".join(md_alt(y) for y in [a1] + list(rest))

    for day, fn in DAYS:
        rows = fn()
        neg = CAREER.get("negatives", {}).get(HEADING_DAY.get(day, ""), "")
        out += [f"## {day}", ""] + ([f"*{neg}*", ""] if neg else []) + [
                "| Time | Room | Talk on your path, and why | Alternative 1 | Alternative 2 | Alternative 3 |",
                "|----|------|----------------------------|----------------|----------------|----------------|"]
        for r in rows:
            k = r[0]
            if k == "sess":
                b = r[1]
                kh = known_here(b)
                people = f" People you know presenting in this block: {', '.join(kh)}." if kh else ""
                out.append(f"| | | **{block_name(b)}.** {RANK[b]['plan']}{people} | | | |")
            elif k == "talk":
                _, code, order = r[:3]
                x = rank_of(code, order)
                tier = tier_of(code, x)
                # a mentoring or career event is named Option 1, with its mentors and who can attend under the reason
                cell, more = md_talk(code, order, tier), ""
                if tier == "C":
                    cell = cell.replace("● ", "● **OPTION 1, MENTORING/CAREER.** ", 1)
                    more = "<br>" + md_career(CAREER_BY_CODE[code])[1]
                out.append(f"| {clock(talk_time(code, order))} | {SESS[code]['room']} ({code}) | "
                           f"{cell}<br>{x['why']}{more} | {md_alts(r, 3)} |")
            elif k == "cof":
                out.append(f"| ♨ | | **Your coffee, {r[1]}.** {r[2]} | {md_alts(r, 3)} |")
            elif k == "meet":
                out.append(f"| {r[1].split(' to ')[0]} | | **Your meeting, {r[1]}:** {r[2]} | | | |")
            elif k == "logi":
                out.append(f"| {r[1]} | | *{r[2]}* | | | |")
            elif k in ("ex", "arr"):
                out.append(f"| {r[1]} | | {'**' + r[2] + '**' if k == 'arr' else r[2]} | | | |")
            elif k == "key":
                _, tier, t, title, who, aff, note, room = r
                out.append(f"| {t} | {room} | {sy[tier]} {title}, {who}{' (' + aff + ')' if aff else ''}<br>{note} | | | |")
        ab = abstract_items(rows)
        if ab:
            out += ["", "### Abstracts of the starred talks on the path and the starred alternatives", ""]
            for code, order, tier, p, text, label in ab:
                out.append(f"**{clock(talk_time(code, order))} {code} {sy[tier]} {p['title']}** "
                           f"({person_of(p['presenter'])}). {text} [{label}]")
                out.append("")
        out.append("")
    return "\n".join(out)


def main():
    AUX.mkdir(parents=True, exist_ok=True)
    tex = AUX / f"{STEM}.tex"
    tex.write_text(build_tex(), encoding="utf-8")
    # the markdown twin and the .tex are written first, so a machine without TeX still gets the table as text
    shutil.copy(tex, HERE / f"{STEM}.tex")
    (HERE / f"{STEM}.md").write_text(build_md(), encoding="utf-8")
    if not shutil.which("xelatex"):
        print("xelatex not found: wrote", HERE / f"{STEM}.md", "and the .tex. Install TeX Live or MacTeX for the PDF")
        return
    for _ in range(2):
        subprocess.run(["xelatex", "-interaction=nonstopmode", f"-output-directory={AUX}", str(tex)],
                       capture_output=True, text=True)
    log = (AUX / f"{STEM}.log").read_text(encoding="utf-8", errors="replace")
    pdf = AUX / f"{STEM}.pdf"
    if not pdf.exists():
        print("NO PDF. Last 40 log lines:")
        print("\n".join(log.splitlines()[-40:]))
        return
    # the PDF the user reads goes in the conference folder, one level above conf_guide/; the .tex and .md stay here
    shutil.copy(pdf, HERE.parent / f"{STEM}.pdf")
    print(f"missing glyphs: {log.count('Missing character')}   overfull: {len(re.findall(r'Overfull', log))}"
          f"   errors: {log.count(chr(10) + '! ')}")
    print("wrote", HERE.parent / f"{STEM}.pdf")


if __name__ == "__main__":
    main()

---
name: conference-guide
description: >-
  Plan which talks to attend at an academic conference (an association meeting, a field
  conference, a workshop, a summer school) and build a personal attendance guide from the live
  program, including mid-conference. On first use it asks for links to the user's website and CV
  and, if the user agrees, a read-only email search, and saves a profile: projects, coauthors,
  advisors, and people who shared sessions with the user at past conferences. It ranks every talk
  against the user's whole portfolio, flags the people the user knows in two evidenced tiers, and
  builds a room-grid PDF (one page per session, the user's path through the rooms, the best
  alternative for each slot, coffee windows, a reason on every talk, every paper and presenter
  linked) plus a day table with three alternative columns and quoted abstracts. Independent agents
  check the program, times, rankings, links and people before it ships. It does not choose
  journals, write emails or abstracts, or review papers.
---

# conference-guide

Turn a conference program into a plan the user can follow on the day: a room grid for each session
showing where to sit, when to move and what each move costs, the best alternative at every moment,
when to slip out for coffee, who the user knows, and why each talk is or is not worth the room, with
every paper and every presenter one tap away. A companion table holds the same plan in rows, with
three alternative columns, every author linked, and the abstracts of the talks the user is choosing
among. Both are PDFs that read well on a phone. The plan is a recommendation: every star and every
coffee window is a starting point the user overrides freely.

**This skill is conference-agnostic.** It works for any meeting with a posted program: a large
multi-program institute, a single-track workshop, an association meeting, a field conference, or a
summer school. Each rule below was learned at a real meeting. Generalize every example (a host, a URL
shape, a room name) to the meeting in front of you.

**Address the user as "you"** in every line the user reads. Never use he or she for the user or for
anyone in the guide, since a name does not tell pronouns: repeat the surname or recast.

## Reference files

- `references/build_recipe.md`: the technical layer. The pipeline file by file, the data files and
  their fields, the parser guards, the profile and portfolio brief, the name matching, the merge
  and link-collection steps, the grid and table layout with exact colors, the LaTeX escaping that
  breaks a build, the abstract-download recipe for awkward hosts, and the toolchain gotchas. Read
  it before parsing a program, building a PDF, or fetching an abstract.
- `references/validation_prompts.md`: the independent checks that run outside the first-run
  workflow (path, times and wording, links added later, quotes, and people), each with its output
  format.
- `references/examples.md`: one worked run on an invented conference, including the first-run
  profile questions. Calibrate format and depth against it. Its names are placeholders that no real
  run reuses.
- `scripts/`: templates for every step, with the file-by-file roles in the recipe's pipeline section:
  - `parse_program_html_template.py` for a static page, `parse_program_gdoc_text_template.py` for a
    program posted as a Google Doc, and `fetch_program_oxford_abstracts_template.py` to download a
    program held on Oxford Abstracts
  - `workflow_rank_template.js` and `workflow_rerank_template.js`
  - `merge_rank_template.py` (SETTINGS: file prefix, spelling corrections, split sessions, more break
    space, declined fixes, the user's name, the clock format) and `collect_links_template.py`
  - `career_events_template.py`, copied beside the merge as `career_events.py`: puts each mentoring
    or career event on the path as Option 1 when the profile puts these events first (the mentoring
    section below)
  - `room_grid_template.py` and `conference_plan_template.py`: per conference, edit each one's
    SETTINGS block (file prefix, title, venue and dates, the user's name as the program prints it,
    day names and headings, session order, short room names, how talk times were set, the note on
    the user's own session, the wording of program events, the clock format). The day rows are built
    from the data files.

## Requirements

Python 3.9 or later with matplotlib and PyMuPDF (`pip install matplotlib pymupdf`), xelatex with the
fontspec package (TeX Live or MacTeX) for the table PDF, `pdftotext` (poppler) for PDF programs and
CVs, and `curl`. Without xelatex the table builder still writes the table as markdown and as `.tex`.
In the Claude apps, the stages run where code execution is on, and a sandbox without xelatex gives the
table as markdown.

## First run: the user's profile (REQUIRED once, before the first guide)

The ranking and the people check both depend on knowing the user's research and the user's people.
That knowledge lives in a saved profile, built once from sources the user points to and reused by
every later guide.

**Where the profile lives.** In Claude Code: `~/.claude/conference-guide/profile.md` (the readable
profile) and `~/.claude/conference-guide/known_people.json` (one record per person), with the text
of past programs in `~/.claude/conference-guide/past_programs/` and any class lists the user supplies
in `~/.claude/conference-guide/class_lists/`. These sit outside the skill folder,
so replacing the skill with a newer version keeps them. Where nothing persists between chats (the
Claude apps without a file system), produce `profile.md` and `known_people.json` as downloadable
files at the end of setup and ask the user to attach them to later conference chats, or to add them
to a Claude Project's knowledge.

**At the start of every run, look for the profile first.** If it exists, read it and state in one
line what it holds and its date ("Using your profile of March 3, 2027: 9 projects, 14 coauthors, 61
people from 6 past conferences"). Offer a refresh in that same line when it is more than a year old or
the user says something changed. If it does not exist, run setup before Step 0.

### The setup questions

Ask in ONE question card (the `AskUserQuestion` tool when available, else a short numbered list),
each with a recommendation:

1. **Your website.** "A link to your personal or faculty website (the research page if there is
   one)."
2. **Your CV.** "A link to your CV, or the file itself (a PDF, a Word file, or a path on this
   computer)." If the website links a CV, offer that link as the first option.
3. **Email, if you want it searched (optional).** "May I search your email, read-only, for direct
   exchanges with the people on each conference's program? I would record only counts and dates.
   I would not quote any message, and I would not send, draft, label or change anything." Options: `Yes, search
   my email` · `No, use only my website, CV and past programs`. Recommend yes when a mail tool is
   connected (it finds the contacts a CV never lists), and say plainly when none is connected (the
   answer is then recorded for later, and the people check runs without mail).

If the user skips the website or the CV, build from what was given and say what the profile lacks.

### Profile contents

| Section | Source | Used for |
|------------------------------|--------------------------|--------------------------------------|
| Name as programs print it, with variants (initials, accents, a maiden or former name the CV shows) | CV, website | finding the user's roles on a program |
| Position, institution, department, fields | CV, website | the ranking brief and "same department" ties |
| Projects: short name, one line, keywords, status (published, working paper, in progress) | research page, CV | ranking every talk |
| Coauthors with affiliations | CV publication lists, the papers' own author lines | the "knows" tier |
| Advisors, committee, references, hosts of visits | CV | the "knows" tier |
| Classmates from the user's degree programs (a class list the user supplies, by program and years) | the user's class lists | the "knows" tier |
| Past conferences and seminars where the user presented, discussed or chaired, with year | CV presentations section, website | the past-program search below |
| People from past conferences: session-mates, discussants, chairs of the user's own sessions | the past programs themselves | the "knows" and "probably" tiers |
| People the user reports meeting at a conference, with the date and the meeting | the user's report after each meeting | the "knows" tier |
| Email search: yes or no, and which account | the setup answer | the mail agents |
| Preferences kept from meeting to meeting (home field, step-out habit, mentoring and career events first, coffee windows, clock format, topics to down-weight) | the user's answers in later guides | Step 0 defaults |

### Building the profile

1. **Fetch the website and the CV live.** Read the research page and every project listed. For a CV
   PDF, `curl -sL` it and extract text with `pdftotext -layout` (or PyMuPDF). For a Word file, use
   `pandoc` or `python-docx`. Save each source with its download date in the profile folder.
2. **Extract only what a source states.** Every entry names its source (the CV section, the web page). Do
   not take any entry from training memory. A coauthor is a coauthor only when a paper the CV or
   website lists shows it. A name in a reading list or a citation does not count as a tie.
3. **Past programs.** For each conference, workshop or summer school in the CV's presentations
   section from the last five years, find the meeting's public program (the meeting's site, the
   Wayback Machine for an old one), save it as text in `past_programs/`, and record the session the
   user was in: the other presenters, the discussants and the chair. A large meeting adds people
   only from the user's own session. A small workshop or summer school (under about 40 participants)
   gives every listed participant as "probably". Record each program the search could not find.
4. **Show the profile before saving it.** Put the projects, the coauthors and the people from past
   conferences to the user in short tables and ask once for strikes and additions (a coauthor the
   CV misses, a project that is retired, a person the user does not want flagged). In the same
   question, beside the coauthors, offer to add a class list for each degree program on the CV (a
   file or a pasted list of classmates' names, with the program and years), since classmates are
   people the user knows whom no CV lists. Save only after that answer, and record each change and
   its reason in the profile.
5. **Email is never scanned at setup.** With a yes, the mail agents of each guide search only the
   names on that meeting's program (Step 2), read-only, over two years, reporting counts and dates.

**Privacy.** The profile and every guide stay on the user's machine or in the user's own chat. The
skill does not post, send or share anything, and it does not quote email content anywhere.

## The live-program contract (binding)

- **The agenda is fetched live on every run.** Do not reconstruct a talk, an author, a time, or a
  discussant from training memory. Read it off the page.
- **Check whether the page is static before reaching for a browser.** `curl` it first and look for
  the sessions in the HTML. A static page with every session, discussant and abstract on it parses
  directly in seconds. Many program pages are drawn by JavaScript: a plain fetch returns
  "Loading..." and misses the agenda, so open those in a browser tool when one is available and read
  the page text after a short wait. If neither works, say so and stop.
- **A program posted as a Google Doc downloads as plain text, with no browser:**
  `https://docs.google.com/document/d/<ID>/export?format=txt`, and `format=html` for the formatted
  copy. `scripts/parse_program_gdoc_text_template.py` reads the text export.
- **A program on Oxford Abstracts** (`virtual.oxfordabstracts.com/event/<id>`) shows nothing to a
  plain fetch, but its public GraphQL service returns the whole program to the anonymous event
  token, with no browser: at one large meeting one query gave 161 sessions and 440 entries, with
  every author's affiliation. `scripts/fetch_program_oxford_abstracts_template.py` runs it, and the
  recipe is in `references/build_recipe.md` under parsing.
- **A program PDF can be replaced in place, under the same filename, up to the first day.** A copy
  already saved in the conference folder is not a source: re-download from the posted URL at build
  time, `curl -sI` it for `last-modified`, and if a saved copy exists, diff the two and report what
  moved. At one meeting the saved copy was three weeks old. The file had been replaced on the morning
  of day one, and against the old copy 17 talks were gone, one was added, one moved, 11 were
  retitled, and a panel changed room and slot. Rename a stale copy `<name>_YYYY_MM_DD_superseded.pdf`.
- **A re-check on the day only on request.** Programs rarely change on the day itself, so the fresh
  download at build time is the check. Offer a re-check only when the user says the program changed.
- Save the live copy with its download date, the parser, and the parsed program in the conference
  folder, and confirm that rerunning the parser reproduces the parsed file.
- If the program is not posted yet, report the dates and organizers, offer the skeleton (days and
  session blocks) to fill in later, and do not invent talks.

## Step 0: The priority question (REQUIRED, first)

Before reading the program in depth, settle the four questions below. Ask only what the request and
the profile leave open. When the request and the profile already answer all four, skip the card and
state the answers taken in the first reply. Otherwise ask the open ones in a single question card, each with a
recommendation:

1. **The program.** The URL(s) of the conference program, or the conference name if the user wants
   the page(s) found.
2. **Home vs step-out.** Which field or program is the user's home base, and how often the user is
   happy to step out of it to another field's session (default: the profile's saved habit when there
   is one, else stay in the user's fields and step out once or twice a day). This is separate from room
   moves inside a session, capped at two (Step 2). A step-out is judged per room visit (the stops in a
   row in one room) by its session's label: each visit to a session outside the home field is one
   step-out, and only a visit made for a talk the user asked for is exempt. A path check that left this
   open once counted 3 step-outs by session label and 1 by talk on the same path.
3. **Priority people or papers.** "Anyone specific, people or papers, you want to be sure to catch?"
   The options MUST include a clear "I don't know, suggest for me" choice. If the user picks it,
   proceed, and after reading the program come back with a proposed priority list (the people the
   user knows who are presenting or discussing, plus the highest-relevance talks) to confirm or
   trim. The priority list makes the schedule personal, so it is always settled, by the
   request or by the card.
4. **Mentoring and career events.** "Should mentoring and career events take priority?" The default
   is yes for a student or a junior researcher (a PhD student, a postdoc or an assistant professor,
   read from the profile's position) and no otherwise. The first guide asks it with that default as
   the recommendation, and the answer is saved in the profile, so a later guide asks again only when
   the user's position changes. With yes, every such event in the program goes on the path as Option
   1 in its slot (the mentoring section below).

Write the answers into the portfolio brief verbatim. A talk or person the user names is "asked for"
(Step 2). A priority person or paper is always flagged and never buried, even outside the user's
usual fields.

## Step 1: The parsed program

Parse the program into one JSON list of sessions (code, day, start, end, room, chair, and talks in
program order, each with authors, title, presenter and affiliation, discussant, abstract, links,
and a talk's own start and end when the program prints them). Capture the official breaks, meals,
keynotes and reception, and the room of each concurrent session so a "step out across the hall"
claim is physically real. Note the format (slot lengths, whether discussants are listed, whether a
prize session has none). Guards, each from a real miss:

- **A block ends at its own list.** At one meeting the page footer parsed as a fifth talk in the last
  session until each block was cut at its closing tag. Drop and report any entry without a title and
  a presenter, and read every drop.
- **The affiliation is the LAST parenthesis.** A name that holds a parenthesis of its own, such as
  "Ana (Nina) Ruiz (University of Example)", split at the first one gives a presenter called "Ana".
- **Talk order inside a room is read in true order, and checked by a second agent.** A two-column
  PDF program flattened to text interleaves rooms: one flattened table put a talk at 4:40 when it
  was third in its room, at about 5:00. Crop each column (`pdftotext -x -y -W -H`, or PyMuPDF blocks
  sorted by x then y).
- **Session codes**: the builders read a code as a block number followed by one room letter ("2E").
  When the program has no codes, assign them that way, with one fixed letter per room across the
  meeting, and record the mapping in the notes. More than 26 rooms take a lowercase 27th letter (`a`,
  then `b`), since the builders read a code as the block number plus ONE character. When the program numbers its sessions its own way ("Block 7" for the first room
  of the fourth time slot), keep that name in `block_label`: the pages and the table then name each
  session as the program does, and the code stays internal. When it names a time slot instead ("Block
  I" over every room of the slot), give each session of the slot that name: a label all rooms of a
  block share names the block, and each room keeps its code ("1A Migration").
- **A misspelled name is corrected in the builders' copy, in every name field.** The parsed program
  stays as the parser wrote it, so a rerun still reproduces it. The merge applies each correction to
  authors, presenter, discussant and chair alike and writes the copy both builders read. A
  correction made only in the authors field once left the misspelled presenter in place, and the
  table listed the presenter as a coauthor of themselves. Record each correction in the notes.
- **An invited session that lists several speakers and no talk times is split evenly among them**
  in the merge (`SPLIT`), as a contributed session is, so the path can reach a later speaker.
- **The user's roles**: search every name variant in the profile across the presenter, discussant,
  chair and author fields, and state every role in the first reply (session, room, position,
  estimated time, chair, whether discussants are listed). A participant list, when posted, is parsed
  too: those names enter the people check as "attending".

## Mentoring and career events

When the Step-0 answer puts mentoring and career events first, the session sweeps for them before the
ranking and puts each one on the path. A mentoring workshop that was both in one program and in two
organizer emails was once ranked as one more session, the path went through two research rooms, and
the user missed it.

- **The sweep.** Search the FULL program, every day and track, for titles and tracks naming
  mentoring, mentor, workshop, women in economics, PhD, junior, early career, job market,
  professional development, career, networking, meet the editors, or lunch with, plus any program for
  underrepresented groups the meeting runs. When the profile allows mail, also search the user's
  mail, read only, for organizer, association and committee messages from about two months before
  the meeting. The events go in `<PREFIX>_career_events.json` (fields in `references/build_recipe.md`).
- **Option 1 in its slot.** The merge puts each event on the path for its whole time, whatever tier
  the ranking gave it, and the best research talk it displaces becomes its alternative, Option 2.
  The user's own slots and meetings are never displaced. An event the program does not hold (a lunch
  announced only by email) is listed and left off the path.
- **Who can attend.** Each event states its time, room, mentors and eligibility (open,
  application-only, a registration form, or unclear) with the registration link and deadline. A
  registration form is marked as an action right away. An event whose eligibility is unclear is
  still Option 1, marked CHECK ACCESS, and never dropped.
- **The Don't miss box.** Both PDFs open with a box of every such event across all days in calendar
  order, which also names the sessions where those mentors present, discuss or chair elsewhere in the
  program (a second chance to meet them).
- **Negatives per day.** A day with no event says so in one gray line naming what was searched
  ("Checked the program and mail: no mentoring or career event on Saturday").
- With no, the sweep does not run, no events file is written, and these events are ranked like any
  other session.

## Step 2: Talk evaluation

**The ranking runs as a workflow of agents, one per block of parallel sessions, each followed by an
independent skeptic** (the orchestration section below has the shape and the launch rules). The brief
they read is the portfolio brief, a file in `conf_guide/` built from the profile: the user's projects
with short names and keywords, the Step-0 answers, anything the user has down-weighted or retired,
and the writing rules for every line they write. When the program gives no abstracts, the workflow
first fetches and checks one per talk, so the ranking reads an abstract for every talk (Step 3).
Rules for the ranking:

- **Against the WHOLE portfolio.** List every project in the profile (working papers,
  publications, under review, work in progress), tier each talk must-see, strong, or less relevant,
  and name the project each starred talk connects to. Never rank against only the paper the user is
  presenting: a first pass that did so starred talks for one project and missed the rest of the
  portfolio. A priority person or paper is at least strong, usually must-see.
- **A project the user has down-weighted gives no credit, and a list the user has retired is never
  cited.** Projects do not weigh the same, and the weighting moves. The brief states the current
  weighting in the user's own words. A talk on a down-weighted topic keeps a star only through
  ANOTHER project, read from its abstract, and a reason line says plainly when a talk has no link.
  Never write "no tie to your other projects", which implies a link to the down-weighted project. At
  one meeting a single such correction lowered 12 talks and changed the path in two of six sessions.
- **Never invent a dislike.** The brief states only interests the user gave and topics the
  portfolio shows. A brief that once told agents to down-weight AI talks, a preference the user
  never stated, sent the path away from the most useful room of the day.
- **A field the user says is far from their work does not earn a star**, whatever the setting of the talk,
  and a keynote in it is shown for awareness, at most strong. The brief's down-weighted section
  states it, and the profile keeps it for later meetings.
- **Must-see is used sparingly**: a direct link to a project's question, setting, method or model.
  The skeptic argues against every must-see and reads every abstract in the block for a talk tiered
  too low.
- **Each block returns** every talk tiered with a reason, the main room, one or two backup rooms
  with a note on when to pick each, the three to five rooms worth showing, the path, one alternative
  for every stop except the user's own slots, the plan and gives-up sentences, and a coffee note
  (fields in `references/build_recipe.md`). Agents write their file into `conf_guide/agents/` as
  they finish, so the build can start before the whole run ends.
- **The user's own slots**: where the user presents or discusses, the path stays in that room for
  that slot and, by default, for the whole session (a prize session with no discussants has the
  chair and the other finalists in the room). The slot is marked as the user's ("your talk", "you
  discuss"), gets no tier of its own, no alternative, and no coffee window over it. A session the
  user chairs keeps the path in that room for the whole session, with no coffee window and no
  alternatives.
- **The user's own meetings**: a meeting the user schedules during the conference is a labeled stop
  on the path (`{"code": "BREAK", "break_start_min", "break_end_min", "label", "note"}`), drawn teal
  in the coffee lane and as a teal row on the cover and in the table, with no alternative. Before
  building a day, check the user's calendar for one when a calendar tool is connected and the user
  agrees, else ask, and give its time in the meeting's local time and the user's home time zone.
- **A mentoring or career event takes the path in its slot** when the profile puts these events
  first (the mentoring section above). The ranking tiers it like any talk, and the merge then makes
  it Option 1, with the best research talk it displaces as its alternative.
- **A session already under way** when the guide is built is ranked for the record and placed last.
- **Paths**: at most two room moves in a session, preferring rooms with the same number of talks so
  each move falls on a clean boundary. The plan names every move and its time.
- **The user's own coffee window: one per day, and more on request.** By default one a day, on the
  least relevant stretch of the path: block agents may each propose one, and the merge keeps the
  weakest stretch of each day. When every stop on a day's path is starred, the window is the
  unscheduled gap between sessions. When the user asks for more break space (`MORE_BREAKS` in
  the merge), every big parallel block gets its own window, up to two a day, over its weakest
  stretch, and over its weakest must-see when every slot holds one, that must-see staying on the page
  as the window's alternative. A plenary or invited slot with nothing tier 1 or better is marked
  "Lighter slot" (`skip_ok`). Each window gets its own alternative, and its note names any starred
  talk it overlaps. The official breaks, meals and reception are networking time and are labeled
  that way.
- **Alternatives.** Every stop except the user's own slots and meetings gets ONE named alternative:
  the best talk in another room at the same time. It is drawn and tabled: a dashed ALT box on the
  grid, and the Alternative 1 column of the companion table, beside two computed ones (Step 4).
  Alternatives sit in a column of their own.
- **A talk or person the user names, including mid-conference, is "asked for".** Its presenter goes
  in the folder's asked-for list. The builders draw it in blue with a diamond (a star is reserved for
  relevance), the path is routed through it, and the reply states in one line what the move costs.

### Two tiers of people the user knows

Every presenter, discussant, chair, coauthor and listed attendee is checked, and anyone who passes
is tagged on the schedule: on their own talk box, on the box of a talk they discuss or coauthored
("known: coauthors X, Y" or "likely: disc. Z"), and under the room header when they chair. Two
tiers, visually distinct, each tag naming the tie in at most 22 characters and addressed to the user
as "you" ("chairs your session"):

- **Knows (evidence).** A documented tie: coauthor, advisor, committee member, reference, same
  department, someone the user named, a classmate from one of the user's degree programs (on a class
  list the user supplied, or confirmed by the user), a session-mate, discussant or chair of the user's
  own session at a past conference (from a saved past program), or a direct mail exchange.
- **Probably knows (a guess).** A strong reason without direct evidence: the same small workshop or
  summer school, a coauthor of a coauthor, a lecturer at a school the user attended, the same
  session block at a past meeting without a shared session, the same school and years with no class
  list or other evidence. Tagged as "likely", in a lighter style.
  An inferred tie is never stated as a fact.

How the check runs:

1. **Match every program name against the class lists first.** For each classmate in
   `known_people.json` (tie "classmate"), skipping a record with tier "struck", allow for accents,
   middle names and preferred first names ("Kate" for "Katherine", a second surname dropped), and
   reject a surname-only match. Each match is tier "knows", tagged with the program ("your MA
   classmate"), with the reason and the pink heart (mark "♥", close false), which the user can remove
   when both tiers are put to the user (item 6). This runs before the wider search, because a
   classmate rarely appears in a CV, a paper or a past program, so the later steps miss them. Pass the
   matches to the workflow with the profile's ties (`known_ties`), so the final evidence agent keeps
   them in the people list.
2. **Match every name on the program** (and the participant list) against `known_people.json`, the
   profile's coauthor and advisor lists, and the past programs' text in `past_programs/`. Match on
   surname plus first name or initial, and require the affiliation to fit for a common surname. A
   name the profile already confirms (a record with tier "knows") keeps its recorded tie and evidence
   and skips the search, the judges and the mail agents (it goes to the final agent with the profile's
   ties). A "probably" record is only a candidate and goes through them, so a confirmed tie can move it
   up. If the user points to local folders (papers, notes, earlier conference folders), grep those
   too, for the names left. Most raw hits are citations. The hit list only says where to look.
3. **Judge agents** open the sources and classify each name. A cited author, a reading list, a big
   program the user did not share a session with, and a file a guide wrote are never evidence.
4. **Mail agents, only when the profile says yes**, read only and over two years, search every
   presenter, discussant and chair and count only DIRECT exchanges with a small recipient list.
   Listservs, digests, conference mailings and cohort threads with 30 or more recipients do not
   count. They report counts and dates only. Before launch, record which account the mail tool reads.
   If it is not the account the profile names, say so on the people page and in the notes. When no mailbox
   was searched, set the grid builder's `MAIL_SEARCHED` to False, so the people page and the session
   pages say the ties come from the profile only.
5. **A final agent** that produced none of the claims rejects any without evidence and writes the
   list with the tie, the evidence, and each person's roles at the meeting ("attending, no program
   role" for an attendee).
6. **The tie sentence states the evidence at its true strength**: a mailing to a list is described
   as a list mailing, a sign-up sheet shows only a booked slot, and a shared institution with no other
   evidence is at most "likely". A mark an earlier pass wrote is never evidence (at one meeting, three
   bold marks written on a guess were then cited as the only "evidence"). Put both tiers to the user
   once so names can be struck and hearts removed, and a confirmed guess moves up. Names are never
   hardcoded in this skill.
7. **New ties go back into the profile.** A person the user confirms, and a session shared at this
   meeting, are added to `known_people.json` with the source, so the next guide starts from them.
   Being on the program is never a contact. When the user reports whom they met or talked with at
   the meeting, add each person as "knows" (tie "met at a meeting") with the date, the meeting and
   the user's words, and record the same people in the conference notes.

- **Routing through people the user knows is the user's call, per person.** After the people check,
  ask whether the path should go through talks by people the user knows, with a recommendation. The
  user decides it for each person, and a talk the user asks for is drawn as asked for (blue
  diamond).
- **Marks for the people the user knows, set by the user** (a `mark` field and a `close` field in
  the people file): every marked person gets the pink heart ♥ (U+2665, `D6457A`), `mark` is "♥" or
  empty, and `close` is true or false. A close person's tag is the heart with no tie wording,
  and a familiar person's tag is the heart plus the short reason ("♥ met at a summer workshop"). A
  marked coauthor is named in full with the affiliation from the program's records. A mark does not
  change a tier: a marked presenter keeps the relevance color (gray at tier 0), and the path goes to
  a marked presenter's talk only when its tier or the user's request puts it there, so the user sees
  who is presenting even in a skipped room. Every
  session page, under the plan, and every session header row of the table show "People you know
  presenting in this block:", the marked ones first, each with room and time.
- **The pink heart shows on every background.** In the grid, a marked person's tag is pink type on
  white with a pink edge, and the "People you know presenting in this block:" line is one chip per
  person, each naming the person in full: every marked person pink on white with a pink edge,
  sorted close first, anyone else on light blue `E3ECF8`. In the table, the heart is set as
  `\textcolor{heartpink}{♥}` (`D6457A`). The templates `room_grid_template.py` (`tag_box`,
  `people_tag`, `known_here`, the people-line chips) and `conference_plan_template.py`
  (`tag`, `known_here`, `esc_heart`) set it.

## Step 3: Abstracts

When the program includes abstracts, quote them from the program and tag them "[program page]".
When it gives none, fetch one for EVERY talk before the ranking, from the program's own paper link
(else a search by title and presenter): one agent fetches per block and a different agent checks
each quote word by word (`fetch_abstracts` in the first-run workflow), and the results go in the
folder's abstracts file with the source kind named. A talk with no abstract anywhere is ranked from
its title, its reason says so, and the table leaves its abstract out. Trim each to the first
sentence and the first sentence that states a result, verbatim, every cut marked " ... ". The
download recipe for awkward hosts and the quote-fidelity rules are in `references/build_recipe.md`.

## Step 4: The deliverable

**The main deliverable is ALWAYS a ROOM GRID PDF, with the day table as its companion.** With only a
table, switching is hard to judge: the grid shows at a glance what each choice gives up. A
single-track meeting is one room lane plus the coffee lane. Start from the templates in `scripts/`,
with the mechanics in `references/build_recipe.md`.

**The grid PDF opens with a cover and the people pages:**

- **Cover:** each day as rows in time order: every official break and meal marked as networking
  time, each session with the rooms in the order the path visits them and any backup room the path
  does not visit ("Lighter slot" on a block marked `skip_ok`), a block with a must-see on the path
  (a keynote included) in green, the user's own session and meetings in teal, and the user's coffee
  rows in amber. Then the room key: each session letter with its room on a light label. A day that
  does not fit starts a new cover page. When the profile puts mentoring and career events first, the
  Don't miss box with the per-day negatives sits above the first day (the mentoring section above),
  and a block holding such an event reads Option 1, the event, then Option 2, the research path, on
  a purple row.
- **Exercise options and the arrival row**: a row kind of their own, ☀ (U+2600) on light blue (fill
  `E3ECF8`, edge `6F8FC4`), listing the long gaps: a skipped opening or a lighter slot plus a meal,
  the evening when a dinner is not on the user's registration, the morning before registration.
  Both builders read them from one `<PREFIX>_extra_rows.json`, which also holds the "arr" row: where
  to go on arrival, with the address and the registration desk.
- **People to find:** knows first, then likely, each with the tie and their roles at the meeting
  (what they present, discuss or chair, and when), flowing onto a second page when long. The page is
  left out until the people check has a list.

**Every session page has:**

1. **Rooms across the top, time running down.** Only the three to five rooms worth comparing (every
   room holding an alternative included), the rooms on the path first and beside the coffee lane in
   the order the path visits them, each headed by its room name on a LIGHT highlight label (light
   viridis blue fill, dark blue type), ON YOUR PATH above every room the path visits and BACKUP
   above a backup room it does not visit, the session's name (the program's own, else its code) and
   theme under it, and a chair the user knows below that. No dark or black label. Every talk is a
   box whose height is its length, its text wrapped to the lane's width.
2. **The path**: a thick outline, an arrow straight down to stay, a sideways arrow labeled MOVE (on
   viridis blue) for a room change, with the minutes of overlap when the next talk starts before the
   current one ends.
3. **The alternative for each stop**: a dashed viridis-blue outline and a small ALT tag, in its own
   room column. The page has no paragraph of backup rooms.
4. **A regular time axis**: a light line at every quarter hour of the clock, labeled bold on the hour
   and half hour and small on the quarter, each box at its true time. A session that starts or ends off
   the quarter hour (11:05 to 12:05) gets one more small line at its start and its end, so its axis
   still shows the hour, the half hour and both edges. Gridlines at every talk start in any room (labels like
   3:54, 4:18 and 4:42) make the page unreadable.
5. **The coffee lane on the left** holding the user's own coffee windows, in amber with the coffee
   label, and any meeting of the user's own, in teal with its label.
6. **A one-line reason on every box**, gray ones included, naming the project it connects to or
   saying plainly that it has no link.
7. **A color key on every page**, wrapping onto a second row when long: must-see, strong, less
   relevant, your slot, asked for, your coffee, your path, alternative.
8. **Links.** The whole box opens the paper (else a seminar abstract, the program's own abstract, or
   the author's page), a small arrow line under the affiliation says which (a trial registry entry
   is labeled as a registry entry), and the presenter's name, in link blue, opens their website,
   else a Google Scholar author search. The companion table links every coauthor and discussant as
   well.
9. **Selectable, searchable text**: real fonts embedded as TrueType and a real bold face. An outline
   effect turns words into shapes that cannot be selected.
10. **People tags** on the boxes, in two tiers, with the user's marks, and under the plan the people
    the user knows presenting in the block (Step 2).
11. **Prose only at the top and bottom**: the plan in one or two sentences under the title, and what
    the path gives up at the bottom (every must-see it misses and the strong talks, by surname and
    room).
12. **Honest times**: a talk's own time when the program prints one, else each room's session split
    evenly among its talks, and the page says which.

**The companion table** (landscape PDF plus a markdown twin from the same data): one table per day
with six columns, Time, Room (a short room name, since long names run past the narrow column),
"Talk on your path, and why" (title linked to the paper, presenter linked, coauthors and discussant
linked, tags, and the reason under the talk, and when the program prints the presenter only, the
coauthors come from the paper or the presenter's site, recorded by the link agents), Alternative 1,
Alternative 2 and Alternative 3 (each a room label, star, linked title and presenter, one short
reason). Alternative 1 is the stop's chosen alternative. Alternatives 2 and 3 are computed: the next
best tier 1 or 2 talks overlapping the stop by at least 10 minutes, each in another room, none on the
path. A session header row states the plan and the people the user knows presenting in the block.
Official breaks are gray rows, the user's coffee amber rows, meetings teal, exercise options light
blue with ☀, and must-see, the user's own slot and asked-for talks tinted. Every row is the same
width: spanning cells are computed from the column widths, since hand-typed spans come out wider or
narrower than the table. Below each day's table: the abstracts of the starred talks on the path and
the starred alternatives, each with its source. With mentoring and career events first, the table
opens with the same Don't miss box as the cover, and an event is the path stop in its slot, tinted
purple as Option 1, with the best research talk as Alternative 1 (Option 2).

**All text, both files:** the user is "you", no line calls a presenter, a chair or anyone on the
people pages he or she (a people tie or a gives-up line repeats the surname or recasts), times use
the user's clock format (12-hour by default, `CLOCK_24 = True` in both builders for 24-hour), nothing cites a retired list, and no page shows build
or status wording (what was pending, when it was built): a version's caption says what it lacks.

**Where the files go.** Each conference gets its own folder, `<conferences folder>/<YYYY-MM
Conference>/`, where the conferences folder is the one saved in the profile (by default a
`Conferences/` folder inside the session's working folder, stated in the first reply so the user
can change it). That folder receives only the two PDFs the user reads, the room grid and the
companion table. The files that build them go in its `conf_guide/` subfolder, with the agents'
files in `conf_guide/agents/`: the live program copy, the parser, the merge, both builders, every
data file, the plan's `.tex` and `.md` twins, the portfolio brief, and the conference notes file
(what the user decided, the corrections made, the people with their evidence, the validation results,
and the file list). The user's own files in the conference folder (session papers, a registration,
slides) stay where they are. Where nothing persists between chats, hand over the two PDFs as
downloads.

## Step 5: Validation round (REQUIRED, built in)

Agents that did not build the plan check it during the build, and their fixes go in as data: a check
offered as a separate step after delivery tends never to run, because by then the sessions it would
fix are over. The prompts and output formats for the checks outside the first-run workflow are in
`references/validation_prompts.md`.

1. **Program accuracy.** A fresh agent re-downloads the LIVE program and checks every talk in the
   guide: session code, order in the room, presenter, title, affiliation, room, day and time.
2. **Path, times and wording.** An agent recomputes every stop's clock time, move and overlap, and
   checks every time, room and name in the plan, gives-up, coffee and backup lines against the
   program. It also checks that the day's path leaves the home field no more often than the Step-0
   answer allows (each step-out judged per room visit by its session's label, as Step 0 defines it),
   that every mentoring or career event the sweep found is Option 1 in its slot when the profile puts
   them first, that gives-up names every missed must-see, that each coffee note names every starred
   talk its window overlaps and the window has its alternative, that a day keeps no more coffee windows
   than the request allows, that every alternative overlaps its stop in a shown room and the user's
   own slots and meetings have none, that a marked presenter keeps the tier the talk earns, that the
   user is "you" and no line uses he or she for anyone, that no line leans on a down-weighted project
   or a retired list, and that no page shows build or status wording.
3. **Ranking.** The per-block skeptic, and after any correction a second look at every talk whose
   star could come from the corrected topic (rewording a reason on an unchanged tier does not fix it).
4. **Links.** A DIFFERENT agent opens every URL and rejects any that fails or belongs to another
   person or another paper. A link agent that checks its own URLs does not count: at one meeting a
   re-rank's link agents passed 29 new links and the independent check rejected 8 paper links. A
   link to SSRN or to any host that blocks automated reads (a 403, a Cloudflare check, a sign-in
   wall) stays. The checker rejects a link only for a wrong person, a wrong paper or a dead page, and
   matches a blocked link through its Crossref or IDEAS record. The same agent checks
   every quote the table prints word for word, the full abstract included, and rejects a URL field
   that holds text in place of an address.
5. **People.** Every "knows" tag has evidence other than the guide itself.

**Timing.** Checks 1 and 3 and the first run's link verification run inside the workflow. Before
version 1 goes out, the per-block skeptic has run for every block. The path check (a few minutes)
runs before version 1 when the next session allows, else immediately after, with its fixes in
version 2, and the delivery note says what is still being checked. After any re-rank, checks 2 and
4 run again in full. Every check writes its fixes to its own file in `agents/`
(`review_ranking.json`, `review_path.json`), each fix naming its target, the old value and the new.
The merge reads those files and applies every fix as data, so a rebuild keeps it, and a fix the
session does not take goes in the merge's DECLINED map with its reason. Report the result in one
line with counts ("validation: 0 program errors, 5 wording fixes applied, 8 paper links rejected").
Every count stated anywhere, in a reply or the notes, is measured from the files at that moment.

## Step 6: Delivery and iteration

- **When the meeting is under way, ship in order of what comes next.** Version 1 (ranked and
  reviewed, with links and people still running) goes out before the next session, version 2 adds
  the people and the links, version 3 the corrections. Each delivery note names the page to read
  first.
- **A correction from the user about how a project or topic weighs is a full re-rank**: write it
  into the portfolio brief, copy the first run's rank files into `agents/v1/`, run the re-rank
  workflow, run checks 2 and 4 again, rebuild both PDFs, and send them with a numbered old-and-new
  table of what changed.
- **A ruling about particular talks, a path, a block or a meeting goes in as fixes**: a short script
  reads the merged rank data and writes a fix file that sorts after the checks' files
  (`agents/review_zz_<topic>.json`, then `review_zzz_<topic>.json`), so the merge applies it last and
  a rebuild keeps it. The merge removes an alternative when a fix's new value is null, adds one when
  the old value is null, and takes the fields path, rooms_to_show, main_room, backups and skip_ok.
- **A first pass that ranked only some blocks** (the next sessions, under time pressure) says which
  blocks it left out and offers to rank the rest.
- **Record what the user decides the same day.** A ruling for this meeting goes into the conference
  notes. A lasting preference (a field to down-weight, a home field, more break space, a clock
  format, mentoring and career events first, a person to mark) goes into the profile, so the next
  guide starts from it. The people the user reports meeting go into the profile too (Step 2, people
  check item 7).

## Orchestration

Scout inline, then fan out. Inline: read the profile, download and parse the program, find the
user's roles, write the portfolio brief, extract every name, match the names against the profile
and the past programs (the hit list feeds the people judges), and, when the profile puts mentoring
and career events first, run their sweep and write the events file. Then one workflow
(`scripts/workflow_rank_template.js`, its arguments documented in its header):

- **Per block, as a pipeline**: fetch and quote-check the abstracts when the program has none, then
  rank, then an independent skeptic that writes the reviewed file to `agents/`, then in parallel a
  link finder followed by a different link verifier, and a fresh program check.
- **Alongside**: people judges over the matched names (about 30 names each) and, when the profile
  allows mail, read-only mail agents over every presenter, discussant and chair (about 25 names
  each), then one final evidence agent that writes the people list.
- Put the next session's block first. At one large meeting the seven reviewed blocks came back 8 to 17
  minutes after launch and the full run took 69 minutes, most of it one retried link check, so build
  and send from the reviewed ranks while links are still running.
- **Launching it**: in Claude Code, the Workflow tool runs the template, with the
  `workflow-authoring` skill loaded first, and only when the user opts in to a multi-agent workflow
  (it can start dozens of agents, and one large meeting used 49). Without that opt-in, run the same stages as
  a handful of background agents (the Agent tool), each keeping its own progress file in `agents/`:
  keep each block's ranking agent and its independent reviewer separate, run the program check
  inside the reviewer, and move the link finding and verifying and the people check to a second
  round, with version 1's note saying they follow. At a two-room workshop (four time slots, 37
  talks, no abstracts) six background agents covered the run: three fetchers (abstracts, links and
  coauthors), one people judge, one link and quote checker, and one ranking reviewer, with the
  ranking itself done in the main session. Agents outside a workflow write the same per-block files
  the workflow writes (`agents/abstracts_block_<b>.json`, `agents/links_block_<b>.json`) and the
  reviewer writes `agents/review_ranking.json`, so the merge and the link collector read them
  unchanged. Where neither tool exists (the Claude apps), run the stages in sequence in the chat,
  keeping the ranking and its review as separate passes.
- **Web searches are a shared budget.** In one build the per-turn search limit was shared by every
  agent launched in that turn, and ten fetchers ran it out mid-run. Ending the turn reset it, and an
  agent resumed in the next turn got the new budget, so when fetchers stop on the search limit, end
  the turn and resume the stopped agents in the next one. Every fetch brief requires the agent to
  write its file after its first talk and then every few talks: two fetchers once ran 20 minutes without
  writing anything and had to be stopped and relaunched. Pass each block with its session codes.
  Afterward, copy each workflow run's `journal.jsonl` (in the session's `subagents/workflows/<run
  id>/` folder) into `agents/` as `journal_first_run.jsonl` or `journal_rerank.jsonl`, since the link
  collector reads them.

Build the PDFs inline from the merged files, send version 1, and launch the path-and-time check.
After a correction, run `workflow_rerank_template.js` (re-tier, re-path, alternatives, review, links
for newly shown rooms), then the independent link check and the path check again.

## Conventions

- **Writing rules for every line the user reads**: plain words, short lines, "you" for the user, no
  he or she for anyone, the user's clock format, `why` at most 90 characters. These rules do not
  apply inside a quoted abstract, which stays verbatim.
- **Colors** come from the viridis palette (its dark purple end marks mentoring and career events),
  with the amber coffee lane and the pink heart as the two warm exceptions. No red, no dark labels.
- **Fonts**: the builders use Arial and Arial Unicode MS on a Mac and fall back automatically to
  DejaVu Sans, which matplotlib ships, elsewhere. Both have every symbol the pages print (★ ○ ● ◆ ☀ ♥
  ♨), and the grid builder narrows its wraps for the wider DejaVu. Check any other font with the
  fontTools line in `references/build_recipe.md` first.
- **Python, LaTeX and git**: if the user has skills for any of these, load them before the work they
  cover.
- **Scope**: this skill plans attendance. It does not choose where to submit a paper, write emails
  to organizers or talk abstracts, or review a paper's rigor.

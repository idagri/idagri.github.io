# build_recipe: from the live program to the grid, the table, and the abstracts

Read this before parsing a program, building either PDF, or fetching an abstract. It is the
technical layer. The profile setup, the workflow, the ranking rules and the priority prompt live
in `SKILL.md`. The templates named here are in `scripts/`.

## The pipeline, file by file

Everything goes in the `conf_guide/` subfolder of the conference's own folder (`<conferences
folder>/<YYYY-MM Conference>/conf_guide/`, the conferences folder named in the profile), every file
named `<PREFIX>_...` with PREFIX such as `2027_05_XYZ`, and the agents' files in `conf_guide/agents/`,
so every step can be rerun from that folder. The two builders write their PDFs one level up, into
the conference folder, which holds nothing else of the guide. Only the LaTeX build runs outside the
tree, in a temporary folder.

| # | Step | Produces | Template |
|---|------------------------------|------------------------------------------------|----------------|
| 1 | Download the live page or PDF | the live copy, named with its download date | Oxford Abstracts fetcher, when the program is there |
| 2 | Parse it | the parsed program (and the day's events, from a Google Doc or Oxford Abstracts) | parser |
| 3 | Write the portfolio brief from the profile | the brief the agents read | |
| 4 | Extract every name, match it against the profile and past programs | names, classmate matches, raw hits, hit list | inline, below |
| 5 | First-run workflow | per-block rankings, the final people list, per-block abstracts when fetched | rank workflow |
| 6 | Copy the workflow record | the first run's journal | |
| 7 | Merge ranks and abstracts, apply fixes | the rank data file, the builders' copy of the program, and the abstracts file when fetched | merge |
| 8 | Collect checked links | the links file | link collector |
| 9 | Write the people file, and the extra rows | the people file, from the final list, the classmate matches and any tier change or mark the user sets, and the extra rows file (exercise options, the arrival row) | |
| 10 | Build | the grid PDF, and the plan PDF, `.tex` and `.md` | grid and plan builders |
| 11 | Path check, and link check for any links added later | the fix file and the link check file, both read by the merge or the collector | validation prompts |
| 12 | After a ruling on particular talks, a path or a meeting: a fix-writing script | a later-sorting fix file, read by the merge | |
| 13 | After a correction to how the user weighs a project: re-rank workflow | re-ranked blocks and the re-rank journal | re-rank workflow |
| 14 | Record | the conference notes file | |

Templates, in `scripts/`:

- parser: `parse_program_html_template.py` for a static page, `parse_program_gdoc_text_template.py`
  for a Google Doc's text export, and `fetch_program_oxford_abstracts_template.py` to download a
  program held on Oxford Abstracts
- rank workflow: `workflow_rank_template.js`, and re-rank workflow: `workflow_rerank_template.js`
- merge: `merge_rank_template.py`, and link collector: `collect_links_template.py`
- grid and plan builders: `room_grid_template.py`, `conference_plan_template.py`
- validation prompts: `references/validation_prompts.md`

The builders read only the folder's files, so a rebuild after any fix is one command each.

## Data files and their fields

- **Parsed program**: a list of sessions, each `{sid, day, start, end, room, code, title, chair,
  talks}`, the talks in program order, each `{authors, title, presenter, discussant, abstract,
  links}`, plus `start` and `end` when the program prints a talk's own times. `presenter` and
  `discussant` keep the program's "Name (Affiliation)" string. A code is a block number and one room
  letter ("2E"). A keynote's code has no letter, and past 26 rooms the letter is lowercase ("2a").
  `block_label`, when the program numbers its sessions its own way, is that name ("Block 7"), and the
  builders show it in place of the code. `affils`, when the program gives each author's own
  affiliation, is `{author: affiliation}`, and the builders name a coauthor the user marked with it.
- **Builders' copy** (`<PREFIX>_program_builders.json`): the parsed program with every spelling
  correction in the merge's `NAME_FIX` applied to authors, presenter, discussant, chair and the
  `affils` names, each invited session in `SPLIT` divided among its speakers, and every parenthesis
  inside an affiliation flattened to a comma, written by the merge. Both builders and the link
  collector read this copy. The parsed program stays as the parser wrote it, so a rerun of the
  parser still reproduces it.
- **Events** (`<PREFIX>_program_events.json`, from the Google Doc or Oxford Abstracts parser):
  `{day, start, end, title, room}` for each break, meal, social and plenary item, for the cover's and
  the table's rows. The builders' `EVENT_SKIP` leaves an event out and `EVENT_NOTE` rewords one, such
  as a dinner that is not on the user's registration.
- **Extra rows** (`<PREFIX>_extra_rows.json`, written by the session, read by both builders): rows
  the program does not hold, `{day, start, kind, label}`. `kind` is `ex` for an exercise option (☀
  at the start of the label, a light blue row), `arr` for where to go on arrival (the address, the
  registration desk, what to bring, in a teal row in bold), or `logi` for a break or meal typed by
  hand. A keynote that is not a ranked block is `key`, with `tier`, `title`, `speaker`, `affiliation`,
  `room` and `note` in place of `label`. Its room goes through the plan builder's `ROOM_SHORT` map,
  and the cover draws it green only at tier 2.
- **Rank data** `{"blocks": {"<b>": {...}}}`, one entry per block of parallel sessions:
  - `talks`: EVERY talk in the block, `{code, order, presenter, affiliation_short, title, tier, why,
    project}`, with `order` the 0-based position in its room, `presenter` the name only, `tier` 2, 1
    or 0, and `why` at most 90 characters.
  - `main_room`, `backups` (one or two `{code, note}`), and `rooms_to_show` (three to five codes,
    main first, including every room that holds an alternative).
  - `path`: stops `{code, order}` or `{code: "BREAK", break_start_min, break_end_min}` (minutes after
    the session start). A BREAK stop is the user's coffee, or, with `label` and `note`, a meeting of the user's own.
    The merge keeps `COFFEE_PER_DAY` coffee windows a day (one, or two when `MORE_BREAKS` is on
    because the user asked for break space) and never drops a meeting.
  - `alternatives`: one `{stop_code, stop_order, alt_code, alt_order, why}` per talk stop (why at most
    70 characters), none for the user's own slots or the user's meetings. A coffee stop gets one too,
    with `stop_order` set to `break_start_min`.
  - `plan`, `gives_up`, `coffee_note`: one or two sentences each. `skip_ok` is true on a lighter slot
    (a plenary or invited slot with nothing tier 1 or better, set by the merge when `MORE_BREAKS` is
    on, or by a fix). `changes` is the agent's own log, which the builders leave out.
- **Links**, keyed `"<code>|<order>"`: `{presenter, paper_url, paper_kind, site_url, site_kind, note,
  coauthors}`. `paper_kind` is one of paper, working paper page, seminar page, program page, author
  page, coauthor page, registry entry. A link back to the program's own page gets `program page`, and
  a trial registry page (AEA RCT Registry, RIDIE, ClinicalTrials.gov) gets `registry entry`, which
  the grid labels "trial registry entry". `coauthors` lists the paper's other authors when the
  program prints the presenter only, as the paper or the presenter's site lists them, and the plan
  builder adds them to the "with" line.
- **Fix files** (`agents/review_<check>.json`, one per independent check, and
  `agents/review_zz_<topic>.json`, `review_zzz_<topic>.json` for the user's rulings, so they sort and
  apply after the checks'): `{"fixes": [{block, code, order, field, old, new, reason}]}`. `field` is
  one of these:
  - a talk's `tier`, `why` or `project` (code and order name the talk)
  - a block's `plan`, `gives_up`, `coffee_note`, `main_room`, `path`, `rooms_to_show`, `backups` or
    `skip_ok` (code "", order null)
  - `alternative` (code and order name the stop). `new` is the why, or a dict of the fields that
    change, with `old` a dict of their old values. `new` null removes the stop's alternative, and
    `old` null adds one.
  - `backup` (code names the room). `new` is its note, and `old` null adds the room.
- **Link check** (`<PREFIX>_links2_check.json`): a list of `{key, paper_ok, site_ok, reason}` from the
  independent check of links added after the first run. The collector blanks every rejected URL.
- **People** `{"people": [...], "rejected": [...], "method": "..."}`, each person `{name, tier
  ("knows" or "probably"), tag (at most 22 characters, addressed to the user as "you"), tie (one sentence),
  evidence, where (their roles at the meeting, or "attending, no program role"), mark}`. `mark` is
  "♥" (pink) for anyone marked, else "", with `close` true for someone close (the tag is the heart
  with no tie wording) or false for someone familiar (the heart and the tag). The user sets every
  mark, except that a classmate match starts with the heart, which the user can remove. The session
  writes `method` (how the check ran, which mailbox) when it writes the file from
  `agents/people_final.json` and the classmate matches.
- **Abstracts** (`<PREFIX>_abstracts.json`, only when the program gives none), keyed `"<code>|<order>"`:
  `{text, source_kind, source_url, caveat, verdict}`, merged by the merge script from the per-block
  files the workflow writes (`agents/abstracts_block_<b>.json`). The plan builder prints `source_kind`
  after each quote and skips a blanked one.
- **Asked for** (`<PREFIX>_asked.json`): a list of presenter names the user asked to catch, drawn in blue
  with a diamond.

## Parsing the program

- **Static HTML** (a page that holds every session in its own element): split on each session's
  element, read the header (day, time, room), the code and title, the chair, then one list item per
  talk. Two guards: end each block at its own closing list tag (the page footer otherwise parsed as
  a fifth talk in the last session), and drop and report any entry without a title and a presenter.
  `html.unescape` every field and link, then grep the JSON for a surviving `&amp;`.
- **The affiliation is the last parenthesis**: `re.match(r"^(.*)\s\(([^()]*)\)\s*$", field)`. A name
  with a parenthesis of its own, such as "Ana (Nina) Ruiz (University of Example)", split at the first
  one gives "Ana".
- **A Google Doc** (`scripts/parse_program_gdoc_text_template.py`): download
  `https://docs.google.com/document/d/<ID>/export?format=txt`, and `format=html` for the formatted
  copy, both named with the download date. The export opens with a byte-order mark and indents with
  tabs. The template strips both, reads each time range, a session header ("Block 1: Theme") with its
  room and chair lines, then each talk as a title line followed by a "Name (Affiliation)" line, and
  stops at the footnote. A time range with no session header under it is an event, written to the
  events file. A title line left with no presenter line is reported, so read each one. An event page
  can link the doc under a label such as "See the full agenda".
- **Oxford Abstracts** (`virtual.oxfordabstracts.com/event/<id>`): the page is drawn by script, but
  its public GraphQL service returns the whole program, with no browser and no sign-in.
  `scripts/fetch_program_oxford_abstracts_template.py` runs both steps below and saves the raw answer.
  1. Token: POST `{}` to `https://app.oxfordabstracts.com/api/virtual/events/<id>/hasura-authenticate-event-tokens`
     with `content-type: application/json` and `origin: https://virtual.oxfordabstracts.com`. The
     answer's `publicEvent.token` is the anonymous event token.
  2. Query: POST `{"operationName": ..., "variables": {}, "query": ...}` to
     `https://graphql.oxfordabstracts.com/v1/graphql` with `authorization: Bearer <token>` and the
     same origin. One query over `program_sessions` returns each session's date, start and end, track,
     type, room (`program_sessions_program_columns`), chairs, invited speakers with roles and
     affiliations, and its papers in display order (`program_sessions_submissions`), each with its
     authors (a `presenting` flag and affiliations) and its form answers (`responses`). The title and
     the abstract are answers to named questions (such as "Paper title" and "Abstract"), so read the
     question names off one record first.
  3. Save the raw answer with its download date, and the fetcher beside it, so the fetch can be
     rerun. At one large meeting a single query returned 161 sessions and 440 entries.
  4. Parse: a session with no room and no papers is an event (a break, a meal, a social) for the
     events file. An overflow room that streams a plenary is dropped as a choice. A paper links to its
     own page, `.../event/<id>/submission/<serial_number>`, which shows the abstract. A session with
     no papers is one box with its speakers joined by semicolons (`A (x); B (y)`), which the merge
     reads as "A and B (x, y)" or divides with `SPLIT`. Each author's affiliation goes in the talk's
     `affils`. Such a program may print no talk times, with the organizers splitting each session
     evenly among its papers.
- **A PDF program**: read each column separately (`pdftotext -x -y -W -H`, or PyMuPDF blocks sorted
  by x then y). A flattened two-column page interleaves rooms and puts talks in the wrong order.
- **No session codes on the program**: assign `<block number><room letter>`, one fixed letter per
  room across the meeting, and record the mapping in the notes. Past 26 rooms the letters go on in
  lowercase (`a`, `b`): the builders read a code as the block number plus ONE character, so a
  two-letter code breaks them. When the program numbers its sessions itself, keep its name in
  `block_label`.
- **An invited session that lists several speakers and no talk times** is one entry in the parse.
  The merge's `SPLIT` divides it evenly among its speakers in the builders' copy and in the rank
  files, so the path can reach a later speaker.
- **A participant list**: parse it too, and give each name the role "attending" in the names file.
- Save the parser beside its output and check that rerunning it reproduces the file (`cmp`).

## The profile (built once, reused by every guide)

Kept in `~/.claude/conference-guide/` in Claude Code (outside the skill folder, so a new version of
the skill keeps it), or as two files the user attaches where nothing persists between chats.

- **`profile.md`**: the date built and the date of each refresh, the sources with their URLs and
  download dates (website pages, CV), the name as programs print it with its variants, the position,
  institution, department and fields, a projects table (short name, one line, keywords, status), the
  email answer (yes or no, and which account), the conferences folder, lasting preferences from past
  guides (home field, step-out habit, coffee windows, clock format, fields to down-weight, in the
  user's own words), and a change log of the user's strikes and additions.
- **`known_people.json`**: `{"people": [{name, variants, affiliation, tie, tier ("knows" or
  "probably"), source, source_detail, added}]}`. `tie` is one of coauthor, advisor, committee,
  reference, visit host, same department, classmate, session-mate, discussant of the user's paper,
  discussed by the user, chair of the user's session, workshop participant, named by the user. A
  classmate's record also holds `program` and `years`. `source` is cv, website, class_list,
  past_program, mail, or user, and `source_detail` names the CV section, the page, or the program
  file and session. A person the user strikes is kept with `tier` "struck", so a rebuild does not add
  the person back, and every match below skips a struck record.
- **`class_lists/`**: each class list the user supplied, as given (a CSV, a text file, or the pasted
  names saved as text), named `<program>_<years>.<ext>`. Every name on it is copied into
  `known_people.json` with tie "classmate", source "class_list" and the file name as `source_detail`.
- **`past_programs/`**: one text file per past meeting, named `<YYYY>_<meeting>.txt`, beside the
  downloaded original, and `past_programs/index.json` listing each meeting from the CV with the
  program URL used, or "not found" and where the search looked.

**Extracting from the CV.** `pdftotext -layout` keeps the columns of a two-column CV apart. Read the
publications and working papers for coauthors (the author line as printed, then the paper's own
title page for affiliations when the CV gives none), the references or letter writers, the advisors
and committee, visits and their hosts, and the presentations section for past meetings (conference
name and year, while a seminar is a talk at a department and gives the host department only). A
name in a "selected coursework" or "teaching" section does not count as a tie.

## The portfolio brief

A short markdown file in `conf_guide/` (`<PREFIX>_portfolio_brief.md`) that the ranking agents read
first, written from the profile. It holds the user's roles at the meeting (session, room, position,
time), the Step-0 answers verbatim, a table of the user's projects with a short name each and
keywords, a section titled "Down-weighted, by the user's instruction" holding anything the user has
down-weighted or retired in the user's own words, the ranking rules (whole portfolio, never invent a
dislike, must-see used sparingly, stay in the user's fields, at most two room moves a session), and
the writing rules for every line an agent writes (plain words, "you" for the user, no he or she for
anyone since names do not tell pronouns, the user's clock format, `why` at most 90 characters). A
correction from the user is written into this file before any re-rank.

## Names and the match against the profile (feeds the people check)

Extract every presenter, discussant, chair, coauthor and listed attendee into `agents/names.json`
with their roles, and their names, one per line, into `agents/names.txt`. First match every name
against the classmates in `known_people.json` (tie "classmate", skipping a record with tier
"struck"): ignore accents, allow a middle name, a dropped second surname or a preferred first name,
and require the first name or its initial to fit, so a surname-only match is rejected. Each match
goes into `agents/classmates.json` as tier "knows", tagged with the program ("your MA classmate"),
with the reason and the pink heart (mark "♥", close false), before the search below runs. Pass the
matches to the workflow in `known_ties`, and write them into the people file with the final list
(step 9). Then search the profile, the past programs and any folder the user points to:

```bash
rg -F -f agents/names.txt -o --no-heading -i --max-filesize 4M \
  -g '*.md' -g '*.txt' -g '*.json' -g '*.tex' -g '*.csv' -g '*.html' -g '!*.bib' \
  ~/.claude/conference-guide/ <any folder the user named>
```

Save the raw output as `agents/namehits_raw.txt`, tally the hits per name (a name with its file
list) into `agents/namehits_summary.txt` for the judge agents, and copy the past programs' text the
hits point to into `agents/confpdf/`. A hit in `known_people.json` is a candidate with its tie
already stated. A hit in a past program is a candidate only when the program puts the name in the
user's own session or a small event. A hit in the user's papers is usually a citation, so the list
only says where to look. Without `rg`, `grep -r -i -F -f` does the same more slowly.

## Merge, fixes and links

- `merge_rank_template.py` reads `agents/rank_block_<b>.json`, then the re-rank's
  `agents/rank2_block_<b>.json`, keying each block by its FILE NAME (an agent once wrote a sentence
  into `block`). It cuts a presenter written with the affiliation down to the name, drops any talk
  the program does not have, stops if a block leaves out a talk the program lists or ranks one twice,
  keeps `COFFEE_PER_DAY` own-coffee windows a day (the weakest stretches: one, or two with
  `MORE_BREAKS` on), never drops a meeting, sets `skip_ok` on a block with nothing tier 1 or better
  when `MORE_BREAKS` is on, and writes the rank data file. It also writes the builders' copy of the
  program, applying each spelling correction in `NAME_FIX` to every name field and to the presenter
  in the rank files: a correction made only in the authors field left the misspelled presenter in
  place, and the table listed the presenter as a coauthor of themselves. It flattens a parenthesis
  inside an affiliation to a comma, taking the last balanced parenthesis as the affiliation, so a
  nickname stays in the name ("Institute of Applied Economic Research (IPEA), Brazil" once printed
  whole as a name).
- **Fixes are data, read from the checks' own files.** The merge reads every `agents/review_*.json`
  (the ranking reviewer's, the path check's) and applies each fix to its target, asserting the
  target exists and still holds the old value. A fix already in place is counted and skipped, and a
  stale one stops the merge. A fix the session does not take goes in the merge's `DECLINED` map,
  keyed `(block, code, order, field)`, with its reason, and the merge prints each declined fix and
  any `DECLINED` entry that matches no fix. A fix typed into a PDF by hand, or retyped into the script
  from a reviewer's prose, is lost or drifts on the next rebuild. An `alternative` fix that moves an
  alternative to a new stop (after a `path` fix earlier in the file) is found by its OLD stop, which
  the fix gives as `old: {stop_code, stop_order, ...}`, since a lookup by the new stop once found
  nothing and stopped the merge. An `alternative` fix with `new` null removes the stop's alternative
  (its stop left the path or became a meeting), and one with `old` null adds an alternative.
- **The user's rulings are fix files too.** A ruling about particular talks, a path, a block or a meeting
  is written by a short script (`agents/write_<topic>_fixes.py`) that reads the merged rank data,
  takes each `old` from it, and writes `agents/review_zz_<topic>.json`, then `review_zzz_<topic>.json`
  for the next ruling, so each sorts after the checks' files and applies on top of them. Run a writer
  once, against the merged state before its own file exists: a writer that skips a value already in
  place, run again after the merge, writes an empty file, and the next rebuild silently drops the
  ruling. To change a ruling, move its file aside, rerun the merge, then rerun its writer. The merge
  applies fix files before it drops the extra coffee windows, so for a block whose window it dropped,
  take the `old` path (and the window's alternative, to remove with a second fix) from that block's
  `agents/rank_block_<b>.json`. At one meeting four such files (people the user knows, a meeting, two
  rounds of rulings) held 78 fixes, applied after the reviewers' 46, and the template merge applied
  all 124 and reproduced that meeting's rank data exactly.
- `collect_links_template.py` reads the workflow records copied into `agents/`
  (`journal_first_run.jsonl`, `journal_rerank.jsonl`) and takes the first run's verified links. It
  then reads the files link agents write when they run outside a workflow
  (`agents/links_block_<b>.json`, `{"links": [...]}`, and with no workflow records it runs with no
  arguments), fills gaps from the re-rank's link agents, and blanks every URL the independent check
  file rejected. It reads the builders' copy, drops an entry whose presenter does not match the
  program at that position (accents and case aside, since an agent once dropped the accent from a
  name and its entry was lost), labels a trial registry page `registry entry`, and keeps each
  entry's `coauthors`.

## Companion table (xelatex)

**Generated from the rank data.** One script emits the `.tex` and the markdown twin from the same
data, on a landscape page. Row kinds: a session header (the plan and the people the user knows
presenting in the block, full width), a talk on the path (its reason under it, its three
alternatives in the last three columns), the user's own coffee (with its alternatives), a meeting of
the user's own (teal, no alternative), an official break or meal, an exercise option or the arrival
row (from the extra rows file), a keynote. The rows of each day come from the events file, the ranked
blocks in time order and the extra rows file, so no day is typed into the builder. The old step-out
row is retired: the alternative is a column. The markdown twin's separator row is proportioned to
the columns (a short dash run for Time, long ones for the talk and alternatives), since equal runs
give equal columns. The builder writes the `.md` and the `.tex` before it compiles, so a machine
without xelatex still gets the table as text.

- **Columns**: Time, Room, "Talk on your path, and why", Alternative 1, Alternative 2, Alternative 3,
  at widths `[1.0, 1.7, 6.2, 4.6, 4.6, 4.6]` cm on a landscape page. Alternative 1 is the stop's
  chosen alternative. `extra_alts` computes Alternatives 2 and 3 as the next best tier 1 or 2 talks
  overlapping the stop by at least 10 minutes, each in a room other than the stop's and Alternative
  1's, none on the path, best tier first, then longest overlap. A stop with no Alternative 1 (the user's own
  slot, a single-room block) gets none. The Room column takes the short names in the builder's
  `ROOM_SHORT` map, a keynote's room included: two long room names once ran 10 to 18 pt past the
  column until the map was added, and the legend at the top keeps the full names. The talk cell
  holds the linked title, the linked presenter with any tag and the affiliation, then "with" and the
  linked coauthors (the program's, else the links file's `coauthors`), then "disc." and the linked
  discussant, then the reason in small dark teal. The session's name under the room label is cut at
  70 characters. An alternative cell holds a room label and code, the star, the linked title and
  presenter, and one short reason.
- **Every row the same width.** Define the widths once and compute every span: a cell covering
  columns i to j is `sum(widths[i..j]) + 2 * tabcolsep * (j - i)`, with `tabcolsep` 4pt = 0.1411cm.
  The table must fit the text width, `sum(widths) + 2 * tabcolsep * ncols` at most 10in in
  landscape (7.5in in portrait). Column widths summing to 17.8cm left a portrait table 4.6pt too
  wide, logged as Overfull. Hand-typed spans came out wider or narrower than the table.
- **Room label**: `\fcolorbox{9FB2D9}{DDE5F3}` around bold dark blue `2F4478` type, the session's
  name (its `block_label`, else its code) and theme under it in small gray, the session header row
  naming the block the same way ("Blocks 3 and 4"), and a letter-to-room key at the top when rooms keep their letter.
  The key joins its labels with `\enspace{} `: TeX swallows the space after a bare `\enspace`, so
  the key cannot wrap, and on 27 rooms it ran 303pt past the page. No label is dark or black.
- **Colors, one meaning each, applied with `\rowcolor`**: must-see green `E3F1DE`, the user's own slot
  (the user presents or discusses) and the user's meetings and the arrival row teal `CFE7E5`, asked for light
  blue `D3DAF0`, exercise option lighter blue `E3ECF8` with ☀, official break or meal gray `F3F4F6`,
  the user's own coffee amber `FBE8C6` with the ♨ marker,
  session header light teal `DCEEEC`, table header solid teal `21918C` with white text, reasons in
  dark teal `1D6F6A`, the heart of every marked person pink `D6457A` (`\textcolor{heartpink}{♥}`), since a smaller or paler mark is
  hard to notice.
  In the grid, a marked person's tag is pink type on white with a pink edge, and the "People you know presenting
  in this block" line is one chip per person, each named in full: every marked person pink on white with a pink
  edge, sorted close first, anyone else on light blue `E3ECF8`. The chips are placed from
  `fig.canvas.get_renderer()` text widths and wrap to a new row at the right margin.
- **Relevance symbols** read in grayscale: `★★` must-see (green), `★` strong (teal), `○` less
  relevant (gray), `●` the user's own slot ("YOUR TALK." or "YOU DISCUSS." before the title), `◆` asked for
  (blue). A symbol macro is followed by `\ ` (a control space), or it fuses
  with the next word into an undefined control sequence, and a plain space after it is eaten.
- **Links**: `\usepackage{hyperref}`, `colorlinks=true`, and bold goes INSIDE the link text
  (`\href{u}{\textbf{Name}}`). Escape `&`, `%` and `#` in every URL as `\&`, `\%`, `\#` when the
  `\href` sits in a table cell or inside another command's argument: the URL is then already read as
  ordinary text, a bare `&` splits the cell, and the compile fails with "Forbidden control sequence
  found while scanning use of \href@split" (107 errors in one build). A name with no verified site
  links to `https://scholar.google.com/citations?view_op=search_authors&mauthors=<name>`
  (`urllib.parse.quote_plus`).
- **Escape every text field** for `&`, `%`, `$`, `#`, `_`, braces, `~` and `^`. Abstracts contain `%`
  and `$`: a bare `%` eats the rest of the line, and a bare `$` opens math mode.
- **Font**: `\setmainfont{Arial Unicode MS}[AutoFakeBold=2.5]`, compiled twice with `xelatex`. The
  bracketed option is required: Arial Unicode MS has a regular face only, so without it every
  `\textbf{}` renders plain with a clean log. On a Mac it has the star and circle glyphs, the sun ☀
  (U+2600) and the heart ♥ (U+2665). It lacks the coffee cup (U+2615), so the coffee marker is ♨
  (U+2668). On a system without it, both builders fall back to DejaVu Sans from matplotlib's own font
  folder, which has every symbol the pages print and a real bold face. Check any other font first:
  `python3 -c "from fontTools.ttLib import TTFont; c=TTFont('<font file>').getBestCmap(); print([ch for ch in '★○●◆☀♥♨→' if ord(ch) not in c])"`
  prints the missing ones, and an empty list passes. The font choice sits in `font_line()` in the plan
  builder and beside `ON_MAC` in the grid builder. DejaVu Sans is wider than Arial, so the grid builder scales its
  character wrap widths by `WRAP` (1.0 with Arial, 0.85 with DejaVu Sans), and `fit_title()` shrinks a cover or
  session title wider than 7.8 inches. After a fallback build, render the densest session pages and the table and
  check that no name or reason runs past its box or cell.
- **Clock**: `CLOCK_24` in each builder's SETTINGS prints 24-hour times (14:30) when the profile asks
  for them, and the 12-hour clock is the default.
- **Layout**: `longtable` with the header in `\endhead`, `\arraystretch` 1.35 for air between rows,
  `\newline` for line breaks inside a cell, since `\\` there ends the row. Abstracts follow each day's
  table with no `\clearpage`, and each new day starts on a fresh page.
- **Abstracts**: the starred and asked-for talks on the path and the starred alternatives, each
  "time, code, star, title (presenter)", then the trimmed quote and its source in brackets: "program
  page" for the program's own abstract, else the `source_kind` from the abstracts file. A quote the
  checker blanked is left out.
- **Build outside the tree**: compile in a temporary folder and copy the PDF and `.tex` into the folder.
  After the compile, `grep -c 'Missing character'`, `Overfull` and error lines must all be 0, then
  render pages and look.

## Room grid (matplotlib)

Drawn straight to a multi-page PDF (`PdfPages`), portrait 8.5 by 11 inches: the cover, the people
pages, then one page per session in the order the user will need them, a session already over last.

- **Cover**: the meeting's name and venue, then every day as rows in time order, built by
  `day_rows()` from the events file, each ranked block's path and the extra rows file. The rows:
  official breaks, meals and socials in gray marked "network", each session with the rooms in the
  order the path visits them and any backup room the path does not visit (no "Backup:" when there is
  none) and "Lighter slot" on a `skip_ok` block, a block with a must-see on the path in green, the
  user's own session in teal and bold with `MY_SESSION_NOTE`, the user's meetings in teal, the user's
  own coffee in amber, exercise options on light blue with ☀, and the arrival row in teal and bold.
  Then the room key on light labels, each as wide as the longest room name needs and wrapping to a
  second row at the right edge (labels sized for short names let two long ones run into each other).
  A taller row moves its center down by half its extra height, since a three-line row covered the row
  above. A day, or the room key, that does not fit starts a new cover page, and `draw_cover` returns
  its page count so the link hotspots fall on the right pages. The note under the key names only the
  row kinds the cover has.
- **People pages**: knows first, then likely, each row a tier tag (the user's mark in its place when
  the user set one), the name, and the tie plus "At the meeting:" their roles, wrapped at about 104
  characters, with a little space between rows. A row that would pass the page foot starts a
  "continued" page. The draw function returns how many pages it used, so the session pages' link
  hotspots fall on the right pages. With no people list yet, the page is left out.
- **Session page header, stacked so nothing collides**: the title (the day and the block as the
  program names it, "Blocks 3 and 4", else "session 3"), the plan (two lines at most), "People you
  know presenting in this block:" in bold teal (presenters the user knows, marked ones first, then each
  marked coauthor in full with the affiliation, every one with room and time), the color key a fixed
  gap below, then ON YOUR PATH above every room the path visits and BACKUP above a
  backup room it does not visit, the room label, the session's name and theme (two lines at most,
  the second cut with an ellipsis), and a chair the user knows, then the grid. With the path in both
  rooms of a session, MAIN over one of them misled. The key: must-see, strong, less relevant, your
  talk and asked for (each only when the page has one), your coffee, your path, alternative (a dashed
  swatch), where "your slot" covers a talk the user presents and one the user discusses. A swatch that
  would pass the right edge starts a second row, and the grid starts below the last row, since a
  seventh swatch once ran off the page.
- **Room order**: the rooms the path visits come first, in the order it visits them, beside the
  coffee lane, then the backups and alternative rooms. A path room drawn third once had its coffee
  arrow run across two other rooms.
- **Lanes**: the time labels, a narrow coffee lane, then the rooms, their width shared equally. The
  type shrinks with a narrow lane and never grows past full size (`scale`, capped at 1), while the
  wrap widths follow the lane width in both directions (`wscale = room_w / 1.55 * 0.92`), so five
  rooms still fit and two wide ones fill their boxes: in a two-room lane about 3.3 inches wide, wraps
  sized for 1.55 inches left the text in a narrow column inside a wide box. A room that holds an
  alternative is always drawn (five rooms at most), so no ALT box disappears.
- **Time axis**: a line every 15 minutes, labeled bold on the half hour and small and gray on the
  quarter. A box sits at the talk's own time when the program prints one, else at its share of the
  even split of the room's session.
- **Boxes**: fill and edge by tier (the user's own slot in teal, asked for in blue, and a marked
  presenter keeps the tier's color), then the star, the presenter's name in link blue, a tag for
  someone the user knows, wrapped inside the box (a close person's pink ♥ on white, a familiar one's
  pink ♥ and reason on white), the affiliation (two lines at most, the department giving way to the
  institution after its last comma when it runs longer), a "known:" or "likely:" line for a
  discussant or coauthor the user knows, joined by "and" (a marked coauthor named in full with the
  mark and the affiliation), the arrow line saying what the box opens, the full title, and ONE reason
  bullet in dark teal. The arrow line names what opens ("paper", "seminar abstract", "trial registry
  entry"). If the content would pass the box's bottom, the type shrinks in steps (1.0 down to 0.68)
  until it fits, keeping room at the foot of a box the path leaves by a MOVE, whose badge once
  covered the last words of the reason.
- **Path**: a thick dark outline on every stop, an arrow straight down to stay, a sideways arrow for
  a room change with a MOVE label on viridis blue `3B528B` (red and pink are out) sitting in the foot of
  the box being left, and "MOVE, N min overlap" when the next stop starts early.
- **Alternatives**: a dashed viridis-blue outline and an ALT tag in the box's bottom corner, for
  every alternative that is not itself on the path.
- **Coffee lane**: the user's own windows as amber boxes on the path, labeled with their clock times, and a
  meeting of the user's own (a BREAK stop with a label) as a teal box with its label and times.
- **Links**: laid on after the PDF is written, with PyMuPDF (`page.insert_link`, `LINK_URI`, box
  inches times 72, top-left origin). The name line opens the presenter's site (else the Scholar
  search), and the rest of the box opens the paper. The two tap areas never overlap.
- **Bottom of the page**: what the path gives up, then a small note on reading the page (the path,
  the tap targets, the tags and marks, the even split of session times). With `MAIL_SEARCHED = False` (no
  mailbox searched), that note and the people page say the ties come from the profile only.
- **Text that stays text**: register Arial, Arial Bold and Arial Unicode MS with
  `font_manager.fontManager.addfont(...)`, `rcParams["font.family"] = ["Arial", "Arial Unicode MS"]`,
  `rcParams["pdf.fonttype"] = 42`. Faking bold with `patheffects.withStroke` turns names into shapes
  that cannot be selected, so use the real bold face. `matplotlib.use("Agg")` before pyplot, and wrap every line with
  `textwrap` by hand. After every build, `page.get_text()` must contain every presenter's name on its
  session page (a hyphenated name can wrap across lines).

## Local-toolchain gotchas (each one has cost a rebuild)

- A **basic TeX install** can lack packages (`emptypage` and `newunicodechar` were missing on one).
  The plan builder uses only `hyperref`, `longtable`, `tabularx`, `array`, `colortbl` (via
  `\usepackage[table]{xcolor}`), `geometry` and `fontspec`. Check a new package with `kpsewhich`.
- **`\char"XXXX` breaks a Python raw string**, so put the literal glyph (★ ○ ♨ ●) in the source.
- **Waiting on agents' files from zsh**: a bare glob that matches nothing is an error in zsh, so a
  monitor loop over `rank_block_*.json` dies on its first pass. List with `ls pattern 2>/dev/null`
  instead.
- **Verify by rendering**: a clean build proves nothing about the layout. Render the cover, the people page and the two
  densest sessions to PNG (`page.get_pixmap`) and look before sending.

## Fetching abstracts (the hosts that fight back)

When the program itself includes abstracts, use those and tag them "[program page]". Otherwise most
paper links are a direct PDF: `curl -sL -A <a browser UA> -o file.pdf <url>`, then PyMuPDF the first
pages, find "Abstract", and cut at `JEL` / `Keywords` / `1 Introduction`. A working-paper cover
sheet can push the abstract to page 2. The awkward cases:

- **Dropbox:** a `www.dropbox.com/scl/...?...&dl=1` link often still serves the HTML preview. Use
  `https://dl.dropboxusercontent.com/scl/fi/.../file.pdf?rlkey=...` (drop `dl=`) and confirm with
  `file <name>` that it is a PDF.
- **Google Drive** view link: `https://drive.google.com/uc?export=download&id=<FILE_ID>`.
- **A working-paper landing page** (NBER, IZA, CEPR, SSRN, RePEc) may return boilerplate. Get the
  abstract from OpenAlex by DOI (`https://api.openalex.org/works/doi:<DOI>`, rebuilt from
  `abstract_inverted_index`, where an NBER working paper's DOI is `10.3386/wNNNNN`), or from Crossref.
- **A site that answers curl with 403** often opens in a browser or through WebFetch, so a 403 does
  not make a failed link. A link on a host that blocks automated reads (SSRN, a Cloudflare check, a
  sign-in wall) stays in the guide whatever the fetch returns, and its title and authors are
  confirmed through Crossref or IDEAS/RePEc.

**Trim by rule, verbatim, every cut marked.** The first sentence, then the first later sentence that
states a result, joined by " ... ", with a trailing " ..." when more follows. Cutting by rule in code
keeps every run of words verbatim. A one-pass fetch at one meeting returned excerpts that read as clean
abstracts and were not: sentences welded with invented connectives, "17-18 percent" rewritten as
"17-18%", interior sentences dropped with no ellipsis. A fidelity pass found problems in 14 of the
20 it could open. So a quote pulled from a paper by an agent is checked word by word by a SECOND
agent against its source.

- **Label what the text IS**: a program abstract, a paper abstract, a registry entry, a seminar
  announcement, or a project description. Never present a registry entry as an abstract, and never
  splice two registry fields together.
- **Record the caveat in its own field**: a null result, a retitled version, midline-only results, no
  public draft, a presenter who is third of four authors.
- **The writing rules do NOT apply inside a quotation.** Never change a dash, a phrase or a
  spelling in a quoted abstract. To drop part of a sentence, cut it with a marked ellipsis.

## Deliverable placement

- The grid PDF and the plan's PDF sit in the conference folder. The plan's `.tex` and `.md`, every
  data file, every script (parser, merge, collector, both builders), the live program copy, the
  portfolio brief and the conference notes live in `conf_guide/`, so any of it can be rebuilt by
  rerunning one script there.
- Each template is copied into the folder under a name with the meeting's short tag, such as
  `parse_xyz_program.py`, `merge_xyz_rank.py`, `collect_xyz_links.py`, `build_xyz_grid.py` and
  `build_xyz_schedule.py`.
- Hand over the grid and the plan with a note naming the page to read first.

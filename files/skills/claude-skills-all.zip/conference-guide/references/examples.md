# Examples: a worked conference-guide run

One end-to-end illustration, on an invented conference with invented talks, authors and a
made-up priority person. Every name and talk here is invented, to calibrate format and depth. Never reuse
these names or reproduce this as if it were a real program. The format is the room grid first and
the companion table with three alternative columns second.

## First run: the profile questions, asked once

No profile exists yet, so the first question card asks for the sources:

- **Your website.** "A link to your personal or faculty website (the research page if there is
  one)." *(Answer: a faculty page with a Research tab.)*
- **Your CV.** "A link to your CV, or the file itself." Options: `Use the CV linked on your website
  (recommended)` · `I'll attach a file` · `I'll paste a link`. *(Answer: the linked CV.)*
- **Email, if you want it searched.** "May I search your email, read-only, for direct exchanges with
  the people on each conference's program? I would record only counts and dates. I would not quote
  any message, and I would not send, draft, label or change anything." Options: `Yes, search my email
  (recommended: it finds contacts a CV never lists)` · `No, use only my website, CV and past
  programs`. *(Answer: yes.)*

Setup then reads the website and the CV, finds the programs of the five meetings the CV lists from
the last five years (four found, one recorded as "not found"), and shows the result before saving:

| Section | Found | Example entries |
|--------------------|--------|------------------------------------------------|
| Projects | 7 | "Informal settlements" (slums, satellite imagery, land titling) and "Migration and schooling" |
| Coauthors | 9 | [a former coauthor], Example U., from the 2024 working paper |
| Advisors, references | 4 | [an advisor], Lake U., CV references section |
| Classmates | 31 | [an MA classmate], from the MA class list the user pasted in this step |
| People from past conferences | 23 | [a session-mate], same session at a 2025 workshop, from its program |

*"Strike anyone you would rather not see flagged, add anyone missing, and mark any project as
retired. If you have a class list from a degree program on your CV, paste it or attach it, with the
program and years, so your classmates are flagged too."* The user strikes one project as retired and
pastes the MA class list, and the profile records both changes and is saved.

## Step 0: the priority question, asked before reading the program in depth

The profile already holds the user's fields, so the card asks only what it leaves open. Note the
required "suggest for me" path on the third question.

- **Program.** "Paste the program URL(s), or name the conference and I will find the page(s)."
  *(Answer: a link to the workshop agenda.)*
- **Home vs step-out.** Options: `Stay in Development (recommended: your profile's home field)` ·
  `Stay in Urban` · `Split evenly` · `Follow the best talks anywhere`. *(Answer: Development, step out
  once or twice.)*
- **Priority people or papers.** "Anyone specific, people or papers, you want to be sure to catch?"
  Options: `I'll name them` · `A coauthor or advisor is presenting` · `I don't know, suggest for
  me` · `No, just tag by my fields`. *(Answer: "I don't know, suggest for me.")*
- **Mentoring and career events.** "Should mentoring and career events take priority?" Options:
  `Yes, put them first (recommended: your profile lists you as a PhD candidate)` · `No, rank them
  like any session`. *(Answer: yes, saved in the profile, so the next guide does not ask.)*

Because the user picked "suggest for me," the first reply after reading the program states the
user's own talk (session, room, position, estimated time, chair) and a short proposed list to
confirm: *"People you know: [a former coauthor] discusses the 9:40 firm-dynamics paper, and [a
session-mate from a 2025 workshop] presents at 2:10. Highest relevance to your projects: the 9:00
slums paper and the 11:30 migration-and-schooling paper."*

## One session page of the room grid

A three-room block, Development in Room A, Urban in Room B and Labor in Room C, 9:00 to 10:20, two
40-minute talks each.

- **Header**: the title "Day 1, session 1, 9:00 am to 10:20 am", then the plan, "Sit in Room A for
  Okonjo at 9:00, then move to Room B at 9:40 for Adeyemi." Under it, in bold teal, "People you know
  presenting in this block: ♥ Lia Ramos (Example U.), coauthor, Room A 9:00 am, ♥ Lund (Room C, 9:40
  am), Adeyemi (Room B, 9:40 am)", the marked people first. Then the color key, and above the first
  two rooms' light blue labels, ON YOUR PATH, since the path visits both (BACKUP is only for a room
  the path does not visit), with "1A Development", "1B Urban" or "1C Labor" under each.
- **Time axis**: lines at 9:00, 9:15, 9:30, 9:45, 10:00 and 10:15, bold on the half hour.
- **Room A**: Okonjo (★★, thick outline, the path): "Mapping Informal Settlements from Satellite
  Imagery", with the reason "Slum mapping, your satellite work". Chen (★): "Firm Dynamics after a Credit
  Shock", with "known: disc. [former coauthor]" under the affiliation.
- **Room B**: Vos (★, dashed outline with ALT, the alternative to Okonjo): "Travel-Time Access in
  Secondary Cities". Adeyemi (★★, the path): "Migration and Schooling in Secondary Cities".
- **Room C**: Ibarra (★): "Job Search with Cell Phones". Lund (○, gray, with the pink ♥ tag, since
  the user marked Lund as close and the talk is still far from the user's projects): "Pension Reform
  and Labor Supply".
- **The arrow** runs from the foot of Okonjo's box to Adeyemi's with a MOVE label. The coffee lane
  is empty, since every stop is starred.
- **Bottom**: "The path misses no must-see. It skips Chen (1A) at 9:40 and Vos (1B) at 9:00."

## The companion table for the same day

`★★` must-see, `★` strong, `○` less relevant. Colors are in brackets here, and in the PDF they are row
fills. Every name and every linked title is a live link in the PDF.

| Time | Room | Talk on your path, and why | Alternative 1 | Alternative 2 | Alternative 3 |
|----|------------|------------------------------------|--------------------|--------------------|-----------|
| 8:00 | | ☀ Exercise option before 8:30: breakfast and registration run to 9:00 [light blue] | | | |
| 8:30 | | *Coffee and pastries: network* [gray] | | | |
| | | **Session 1, 9:00 to 10:20.** Sit in Room A for Okonjo, then move to Room B at 9:40 for Adeyemi. People you know presenting in this block: ♥ Lia Ramos (Example U.), coauthor, Room A 9:00, ♥ Lund (Room C, 9:40), Adeyemi (Room B, 9:40). [light teal] | | | |
| 9:00 | Room A, 1A Development | ★★ [Mapping Informal Settlements from Satellite Imagery], **Okonjo**, Example U., with Ramos [♥, Example U.]<br>Slum mapping, your satellite work | Room B, 1B: ★ Travel-Time Access in Secondary Cities, Vos. City access in a developing country | Room C, 1C: ★ Job Search with Cell Phones, Ibarra. Phones and job search, your field work | |
| 9:40 | Room B, 1B Urban | ★★ [Migration and Schooling in Secondary Cities], **Adeyemi**, Lake U., with Torres<br>Migration and schooling, two of your threads | Room A, 1A: ★ Firm Dynamics after a Credit Shock, Chen. A coauthor discusses | | |
| 10:20 | | *Break: network* [gray] | | | |
| ♨ | | **Your coffee, 1:30 to 2:10.** The softest stretch of the day, back for the 2:10 talk. [amber] | Room B, 2B: ○ Housing Supply and Zoning Reform, Novak. Less relevant, urban but off your projects | | |
| 3:00 | | **Your meeting, 3:00 to 3:30:** Call with a coauthor. That is 12:00 to 12:30pm in your home time zone. [teal] | | | |

**Abstracts** (below each day's table, the starred talks on the path and the starred alternatives,
quoted with every cut marked and the source named):

- **9:00 1A ★★ Mapping Informal Settlements from Satellite Imagery** (Okonjo). Builds a
  settlement-classification pipeline from high-resolution imagery ... validates it against ground
  surveys in three cities. [program page]
- **9:00 1B ★ Travel-Time Access in Secondary Cities** (Vos). Measures door-to-door travel times to
  jobs across twelve secondary cities ... finds that access falls fastest at the urban edge. [paper]

## Calibration points

- The profile is built once, shown to the user before it is saved, and read at the start of every
  later run. Every entry names its source.
- The priority prompt runs first when the request and the profile leave something open, and offers
  "suggest for me". The first reply states the user's own talk and the answers taken.
- Relevance comes from the whole portfolio and the priority list, with the project named on every
  starred box. A talk whose only link is a down-weighted project does not earn a star.
- Every stop except the user's own slots and meetings has one alternative, drawn as a dashed ALT box
  and listed as Alternative 1. Alternatives 2 and 3 are the next best tier 1 or 2 talks in other
  rooms overlapping the stop by at least 10 minutes, so the 9:40 stop leaves them empty: Room C holds
  only Lund, who is less relevant. The page has no backup paragraph, and the table has no step-out row.
- The user's coffee sits on the softest stretch, amber and distinct from the gray official breaks.
  When every stop is starred it moves to an unscheduled gap. One window a day, up to two when the
  user asks for more break space.
- A mark does not change a tier: Lund stays gray with the heart, and the path does not go to Room C for it.
- With mentoring and career events first, such an event is Option 1 in its slot whatever its tier.
  Had this invented program held a "Junior Mentoring Lunch" at 12:30 in Room D, the path would go to
  Room D for it, the best research talk at that time would be its dashed ALT box and Alternative 1
  (Option 2), and the lunch would open the cover's and the table's Don't miss box. A day with no mentoring
  or career event shows one gray line, "Checked the program and mail: no mentoring or career event on <day>".
- Every row of the table is the same width, and every name opens something.

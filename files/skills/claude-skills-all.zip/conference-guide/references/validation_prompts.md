# Validation prompts: the independent checks and their output formats

These are the prompts for the checks in `SKILL.md` Step 5 that run outside the first-run workflow. Launch each as a background agent that did not build the
guide (the Agent tool, or a small workflow when several run together). Fill the angle brackets from
the conference folder: `<folder>` is its `conf_guide/` subfolder, where every input and agent file
lives, and `<conference folder>` is the folder above it, which holds only the two PDFs.

## Path, times and wording

Run it on the merged rank data before version 1 when the next session allows (it takes a few
minutes), and again after every re-rank.

```text
Independent check of a conference guide for <conference>. You did not build it; try to find errors.
Files: the program <folder>/<prefix>_program_parsed.json, and the builders' copy
<folder>/<prefix>_program_builders.json, which differs from it only by the spelling corrections in
<folder>/merge_<conf>_rank.py (NAME_FIX; a name that differs only by one of them is no error); the guide data
<folder>/<prefix>_grid_rank.json ({"blocks": {...}}); the rendered grid <conference folder>/<prefix>_room_grid.pdf
(read it with PyMuPDF page.get_text()); abstracts the program lacks, in <folder>/<prefix>_abstracts.json
when it exists. The user's roles at the meeting: <roles>. What the user down-weighted or
retired: <downweighted>; <retired>.
Time rule: <times_note>. A BREAK stop is minutes after the session start.
For every block still ahead of the user:
1. Every path stop exists and runs in time order; at most two room moves; any coffee window sits
   over no starred talk and none of the user's own slots, except that when the brief says the user asked for
   more break space, a window may sit over the weakest must-see of a block where every slot holds
   one, with that must-see as its alternative; a day keeps one coffee window, or at most two when the
   user asked for more break space; a session the user chairs keeps the path in its room; and, per
   day, the path leaves the home field no more often than the Step-0 answer (in the brief) allows.
   Judge each room visit (the stops in a row in one room) by its session's label: each visit to a
   session outside the home field is one step-out, and only a visit made for a talk the user asked
   for is exempt. Report the step-outs per day by code and theme.
2. Recompute every stop's clock time. Check every time, presenter and room named in plan, gives_up,
   coffee_note and every backup note against the program and the time rule.
3. gives_up names every tier-2 talk the path misses and no talk on the path.
4. Each coffee note names every starred talk its window overlaps, and the window has its alternative.
5. Every talk stop except the user's own slot has one alternative; each overlaps its stop, sits in another
   room, and that room is in rooms_to_show. A meeting of the user's (a BREAK stop with a label) has
   none, and its day, start and end match the user's calendar or the time the user gave, in the
   meeting's local time.
6. No line leans on a down-weighted project or mentions a retired list; no talk keeps a star through
   a down-weighted project only (read the abstract); no talk in a field the brief down-weights
   holds a star, and a keynote in one is at most strong; a presenter the user marked (the people
   file's mark) keeps the tier the talk earns, and no path stop rests only on a mark unless the
   user asked for that talk; skip_ok sits only on a block with no talk tier 1 or better.
7. The user is "you" in every rendered line; no line calls a presenter, a chair or anyone on the
   people pages he or she, since names do not tell pronouns; times use <clock format>; no build or status
   wording appears on any page.
8. Every presenter and title matches the program at the same code and order; every presenter of
   every shown room is printed on that session's page.
9. When the brief says mentoring and career events come first: re-run the keyword sweep of the
   skill's mentoring section on the program (every day and track) and list any match missing from
   <folder>/<prefix>_career_events.json. Every event in that file with a program code is the path stop
   in its slot as Option 1, with the best research talk it displaces as its alternative (Option 2);
   the cover and the table open with the Don't miss box listing every event in calendar order, with
   time, room, mentors, eligibility, and registration link and deadline; an event with unclear
   eligibility is still listed, marked check access; each day with no event has its negatives line.
Write every fix to <folder>/agents/review_path.json as {"fixes": [{block, code, order, field, old,
new, reason}]}, in the format of the "Fix files" entry in the conference-guide skill's
references/build_recipe.md, with old copied exactly from the guide data. Return a table of the same
errors: block, field, what it says, and the correction. Say "no errors" for a clean block.
```

The merge reads `agents/review_path.json` and the ranking reviewer's `agents/review_ranking.json`, then
the files holding the user's rulings (`agents/review_zz_<topic>.json` and later-sorting names), and
applies every fix as data. A fix the session does not take goes in the merge's `DECLINED` map with
its reason. After a ruling's file is merged, run the path check again on the blocks it touched. Rerun the merge, rebuild both PDFs, and record the counts in the conference notes
(applied, already in place, declined).

## Ranking review outside a workflow

When the ranking runs in the main session or in background agents (no workflow opt-in), one agent
that did not rank reviews every block, the next session's block first, and writes its fixes as data.

```text
Independent review of the ranking in a conference guide for <conference>. You did not rank it; try
to refute it. Files: the program <folder>/<prefix>_program_parsed.json; the portfolio brief
<folder>/<prefix>_portfolio_brief.md; the rankings <folder>/agents/rank_block_<b>.json; abstracts in
<folder>/<prefix>_abstracts.json or <folder>/agents/abstracts_block_<b>.json when they exist.
For every block: argue against every must-see; read every abstract in the block for a talk tiered
too low; check that every star links to a project other than a down-weighted one, read from the
abstract, that no talk in a field the brief down-weights holds a star, and that no line mentions a
retired list; check the path, the coffee windows and the alternatives as the path check does; check the
writing rules in the brief, with no he or she for anyone.
Write <folder>/agents/review_ranking.json as {"fixes": [{block, code, order, field, old, new,
reason}], "verdicts": [...]}, in the format of the "Fix files" entry in the conference-guide skill's
references/build_recipe.md, with old copied exactly from the ranking file. Write the next session's
block first, so the build can start, and add the others as you finish them.
```

## Independent link check

For links a first agent found and did not hand to a separate verifier (the re-rank's link agents
check their own URLs, and in one build the independent check still rejected 8 of their 29 paper links).
First write the entries to check to `<folder>/agents/links_to_verify.json` as a list of
`{key, presenter, paper_url, site_url}`.

```text
Independent link check for a conference guide (<conference>). You did not find these links; try to
reject bad ones. Input: <folder>/agents/links_to_verify.json. The program (title and presenter per
key "CODE|order") is <folder>/<prefix>_program_parsed.json.
For each entry: open paper_url (curl -sL -A "Mozilla/5.0", or WebFetch) and confirm it resolves and
is THIS presenter's paper (same person; the program title or clearly the same project). Open
site_url and confirm it is the same person (affiliation or research listed matches), and neither a
directory list nor a same-name stranger. A 403 from curl does not justify a rejection: try WebFetch.
A link to SSRN or to any host that blocks automated reads (403, a Cloudflare check, a sign-in wall)
is KEPT: reject a link only when it belongs to another person or another paper or
the page is dead (404, a parked domain). Match a blocked link another way and say so in its reason:
the Crossref record of its DOI (SSRN is 10.2139/ssrn.<id>) or its IDEAS/RePEc record gives the
title and authors. Do not wait out or work around a bot check.
A page that lists the same project with the same coauthors passes; a page that does not list the
talk fails. When the entries hold quotes, check every quote the guide prints word for word against
its source, the full abstract as well as the trimmed one, and reject a URL field that holds text in
place of an address ("no public draft found").
Write <folder>/<prefix>_links2_check.json as a list of {key, paper_ok, site_ok, reason}, and return
how many you checked, how many paper and site links you rejected, and each rejection with its reason.
```

`collect_links_template.py` reads that file and blanks every rejected URL on the next collection.

## Quote check (when abstracts come from papers)

Built into `workflow_rank_template.js` as the `quote-check:<block>` stage when `fetch_abstracts` is
on. For a quote added later, the same prompt applies: a different agent opens the source, compares
word by word (every run of words between ellipses verbatim and in order, every cut marked, the
source kind stated), and writes a verdict per entry.

## People evidence

Built into `workflow_rank_template.js` as the `people-final` agent. When the user confirms or strikes a
name, or a later check moves someone between tiers, edit the people file, record the change and its
reason in the conference notes, and update `known_people.json` in the profile the same way. When the
user reports whom they met at the meeting, add each person to `known_people.json` as "knows" (tie "met
at a meeting", with `met` holding the date, the meeting and the user's words) and list them in the
conference notes. Being on the program is never a contact, so a name the guide only tagged gets no
`met` entry.

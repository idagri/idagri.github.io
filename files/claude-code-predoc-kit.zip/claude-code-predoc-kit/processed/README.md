# Intermediate files

The task 2 scripts write their stage-named intermediate files to this folder.

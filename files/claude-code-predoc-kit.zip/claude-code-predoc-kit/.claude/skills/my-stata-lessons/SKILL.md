---
name: my-stata-lessons
description: >-
  Fires on the task. A request to build, rebuild, merge, clean, check, review, or fix a dataset,
  variable, sample, regression, table, or figure in a project whose analysis runs in Stata triggers
  it, even when the prompt names only the output ("rebuild the summary table", "add the 2010
  download", "why did N drop", "a district shows zero"). Read it BEFORE writing, editing, or
  reviewing any do-file and before running one; run references/checklist.md after drafting. Do NOT
  use for Python (my-python-lessons) or for a LaTeX file that will not compile.
---
# Stata lessons learned (mine)
Every mistake that cost me time, as a one-line Rule with the incident under it. This folder is the only home; a project never keeps its own copy.

## Routine for every do-file
1. Before editing a do-file, read the reference file the map names
2. After drafting, run references/checklist.md top to bottom
3. Print ✅ after the file name in the reply when both happened; no ✅ means they did not
4. When a mistake bites, add a numbered lesson the same day, unprompted, and tell me in one line

## Reference map
- references/merges_missing.md: read before any merge, append, collapse, drop, or missing-value handling
- references/checklist.md: run before handing any do-file back, every time

## Adding a lesson
- Take the next free number (series 1 incidents, series 2 general pitfalls); grep the skill for the number first
- Never renumber; on a collision suffix a and b in file order
- A lesson later found wrong gets a dated correction appended under its heading; the heading stays so old citations still resolve
- One-line **Rule:** first, then the incident (symptom, cause, fix, general form)
- If the lesson implies a mechanical check, add a grep line to references/checklist.md in the same pass

# Merges and missing values

Index
- 2.1  `drop if x < c` keeps the rows where x is missing
- 2.2  collapse (sum) returns a hard zero for an all-missing group
- 2.3  a crosswalk missing a whole region passes every uniqueness check

## 2.1 `drop if x < c` keeps the rows where x is missing (2026-09-23)
**Rule:** Write the missing clause in every `drop if` and `keep if`.
Stata treats missing as larger than any number, so `drop if x < c` leaves every row where x is missing in the sample, while the same filter ported to pandas or R as "keep x >= c" removes them. Symptom: two scripts that read alike define different samples, with no error. Fix: decide what missing should do and write it in the line, `drop if x < c & !mi(x)` to keep those rows or `drop if x < c | mi(x)` to drop them.

## 2.2 collapse (sum) returns a hard zero for an all-missing group (2026-09-23)
**Rule:** Count the non-missing members in the same collapse and set the sum to missing where that count is 0.
A district whose every village is missing comes back as 0 and enters the regression as a real observation. Keying on the zero afterward destroys real zeros. Native `collapse` has no `missing` option (it stops with r(198)), so write `collapse (sum) x (count) n_x = x, by(g)` and then `replace x = . if n_x == 0`.

## 2.3 A crosswalk missing a whole region passes every uniqueness check (2026-09-23)
**Rule:** After a crosswalk merge, tabulate the key's prefix against the merge result and assert a match rate.
Uniqueness checks look only at the rows that are there; absence is a property of no row. With keep(match), the missing region's units vanish with no error.

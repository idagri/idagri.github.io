# Pre-flight checklist (run before handing back any do-file)
1. Every filter names missing: `grep -n "drop if\|keep if" <file>`; every hit has an explicit missing clause (lesson 2.1)
2. No silent fill: `grep -n 'collapse (sum)' <file>` and `grep -n '= 0 if mi(' <file>`; every sum is paired with a `(count)` of the same variable and set to missing where that count is 0, or the zero is justified in a comment (lesson 2.2)
3. Every merge is followed by a match-rate assertion and `tab <prefix> _merge, row` (lesson 2.3)
4. The file opens a timestamped plain-text log and closes it; no dataset is saved under the name it was read from
5. After a batch run: `grep -cE '^r\([0-9]+\);' <log>` is 0 and the output file's timestamp moved

**Last item: report the pass.** Print a ✅ immediately after the file name in the reply (`build_sample.do ✅`). No ✅ means this checklist did not run; never write a sentence saying it did.

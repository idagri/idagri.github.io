# Merges and missing values

Index
- 2.1  groupby sum returns a hard zero for an all-missing group
- 2.2  a derived id built with the wrong divisor merges to zero matches
- 2.3  a merge without `validate` and `indicator` hides duplicates and holes

## 2.1 groupby sum returns a hard zero for an all-missing group (2026-09-23)
**Rule:** Pass `min_count=1` to every groupby sum.
`df.groupby("g")["x"].sum()` skips missing values, so a group whose every member is missing comes back as 0.0 and enters the next step as a real observation. With `min_count=1` the group returns NaN. Keying on the zero afterward destroys real zeros.

## 2.2 A derived id built with the wrong divisor merges to zero matches (2026-09-23)
**Rule:** Print three sample values and the length of a derived id on both sides before merging on it.
An id built by integer division (`code // 1000`) with the wrong divisor produces valid-looking integers that match nothing in the other file. An outer or left merge raises no error and returns every row unmatched. Fix: print the values, compare them by eye to the other file's key, and assert the match rate after the merge.

## 2.3 A merge without `validate` and `indicator` hides duplicates and holes (2026-09-23)
**Rule:** Pass `validate="m:1"` (or the relation you expect) and `indicator=True` to every merge, then assert the match rate.
A duplicated key on the right side multiplies rows with no warning, and a region missing from a crosswalk simply fails to match. `validate` stops the first; the `_merge` column and an assertion on its share of "both" catch the second.

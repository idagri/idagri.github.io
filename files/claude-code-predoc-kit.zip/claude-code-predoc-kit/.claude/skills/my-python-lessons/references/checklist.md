# Pre-flight checklist (run before handing back any script)
1. No silent zero in a sum: `grep -n "\.sum(" <file>`; every groupby sum passes `min_count=1`, or the zero is justified in a comment (lesson 2.1)
2. No silent fill: `grep -n "fillna" <file>`; every hit has a comment saying why the blank is a real zero
3. Every derived id prints three sample values and its length on both sides before the merge (lesson 2.2)
4. Every merge passes `validate=` and `indicator=True` and is followed by an assertion on the match rate (lesson 2.3)
5. No file is read and written under the same name; outputs go to `processed/` under a stage name

**Last item: report the pass.** Print a ✅ immediately after the file name in the reply (`build_sample.py ✅`). No ✅ means this checklist did not run; never write a sentence saying it did.

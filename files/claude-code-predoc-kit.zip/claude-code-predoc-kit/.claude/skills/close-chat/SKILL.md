---
name: close-chat
description: >-
  Closes a chat so nothing lives only in its memory: re-checks what was done, writes the findings,
  decisions, errors, and open questions to the project's files, updates the lessons skills, hands
  the next task to a fresh chat with a handoff file and a blurb, and ends on a verdict. Use when I
  say "are we done", "close this off", "close this chat", or "wrap up", when I ask what is
  outstanding, or when the context indicator turns yellow or red. The "Closing a chat" section of
  CLAUDE.md is the short version; this is the full one.
---
# Close chat (basic)

From the workshop: "Closing the chat also means for me that it updates my local files." Then "the useful insights from the chat's memory are documented locally, and you can feel confident that you can close the chat."

1. **Re-check now.** Re-read every file this chat changed and the newest log of every script it ran, and say what was re-read. A claim of done with no check made now is reported as NOT verified
2. **Write it down.** Add a dated note, `notes/YYYY_MM_DD_<topic>.md`: what was done, each decision and assumption with its reason, errors found and how they were fixed, where the sample changed and why, and every open question. Nothing stays only in the chat
3. **Update the lessons.** A coding mistake this chat hit becomes a numbered lesson in the matching lessons skill (my-stata-lessons, my-python-lessons), with a one-line Rule and, where it implies one, a checklist line
4. **Summarize.** Print `## What this chat accomplished`, grouped in this order: Runs and decisions, Code fixes, Documents, Errors found and corrected, Lessons. One outcome-first sentence per bullet; each group ends on a bold **Takeaway:** line. A mistake this chat corrected is owned here, with its undo path
5. **Hand off the next task.** For anything left, write `notes/YYYY_MM_DD_handoff_<slug>.md` with a `STATUS: NOT STARTED` line, the files to read first, and the next step. Print a blurb in its own fenced block: a project code (a one-word name for the project), a short task name, a colon, then two sentences (what to run, plus the one fact the next chat needs), then the model and effort level the task needs. Offer a task chip where the app shows one
6. **Verdict.** End on two lines: "This chat is closed." or "This chat is NOT closed:" plus what is outstanding (an unanswered 🟢 question, unfinished work, a 🟡 next step that no handoff owns, a claim of done not checked now); then "Safe to close this window: yes" or "no", with the reason

A handoff written to a file with its blurb printed counts as done, so it never keeps a chat open.

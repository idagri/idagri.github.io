---
name: code-to-text-audit
description: >-
  Audits a draft's description of its empirical work against the code that produces it: sample
  restrictions, specification, fixed effects, clustering, variable definitions, and every number
  the text quotes, each claim traced to a line of code or of the log. Use when asked to check a
  draft, a methods section, a table note, or a memo against a do-file, an R script, or a Python
  script, or to ask "does the text match the code". The audit does not edit either side.
---
# Code-to-text audit (basic)

1. **Inputs.** The draft section, the script that produces its results, and the newest log of that script; say which files were read. Run nothing unless asked: the audit reads code and logs
2. **List the claims.** Every sentence about the sample, the specification, the fixed effects, the clustering, or a variable's definition, and every number, each with its line number
3. **Trace each claim.** Quote the sentence with its line, cite the code or log line that implements it, and give one verdict: MATCHES, DISAGREES, or CANNOT VERIFY (the files settle nothing, such as a robustness check with no code behind it)
4. **Rank the disagreements.** Inference first (clustering, standard errors), then the sample and the specification, then definitions and numbers. For each, say which side to change, the text or the code, and why, with a one-line fix
5. **Report** as a numbered table: No., the sentence and its line, the code or log line, verdict, side to change, fix. End with two short lists: what checks out, and what the files could not settle
6. **Fixes are a separate step.** Change nothing during the audit; when asked to apply a fix, show the old and the new version side by side first

A claim counts as checked only once it is traced to a line; a claim that merely sounds right is CANNOT VERIFY.

---
name: bib-check
description: >-
  Checks and maintains a bibliography with live lookups: whether each entry in a .bib file is a real
  paper with the right authors, year, title, journal, volume, and pages; whether the paper supports
  the sentence that cites it; and adding a new reference to the .bib from its DOI. Use when asked to
  check, verify, fix, or add references, to ask "is this citation real" or "does this paper say
  that", or before a draft with citations goes to a PI. For the workshop exercise, which reads saved
  records and stays off the web, use citation-check. Report first; edit only when asked.
---
# Bib check (basic)

From the workshop: "It pulls each citation, opens it, and checks that the title, the authors, the year, everything is correct." Then it checks whether the paper supports the sentence that cites it.

## Checking entries

1. Find the .bib the document loads (`\bibliography{...}` or `\addbibresource{...}`) and every citation command that uses it; list cited keys missing from the .bib, and entries nothing cites
2. Look up each entry by DOI first: `https://api.crossref.org/works/<DOI>`. With no DOI, search by title and first author, with the words joined by +: `https://api.crossref.org/works?query.bibliographic=<title+and+first+author>&rows=5`. Pause a second between lookups; when Crossref answers HTTP 429 (too many requests), wait a few seconds and retry. A search often returns the working-paper version (NBER, SSRN) before the journal article, so match on the journal too
3. Compare every field with the record: each author's name and order, year, title, journal, volume, issue, pages
4. Give each entry exactly one status:
   - VERIFIED: every field matches, and the paper supports the sentence
   - WRONG DETAIL: a real paper with a wrong field; name the field, the value in the .bib, and the value in the record
   - FABRICATED: positive evidence that the paper does not exist as cited (the DOI belongs to a different paper, or no record matches the authors and title); say which paper the DOI points to
   - UNVERIFIABLE: no record either way (a working paper, a conference talk, a paper not yet public); list what was searched. Absence of a record proves nothing, so this status is separate from FABRICATED
   - CLAIM MISMATCH: the metadata is right, but the paper does not report what the sentence says; quote the sentence next to what the abstract reports
5. Check the claim for every entry: read the abstract (in the record, on the working-paper page, or on the publisher's page, which often refuses automated requests) against the sentence that cites it. When no abstract can be reached, the entry cannot be VERIFIED: write "claim not checked" in the evidence and ask me for the PDF
6. Report as a numbered table: No., entry key, status, evidence, proposed fix. End with the questions I need to answer, one per line
7. Delete nothing: a FABRICATED or UNVERIFIABLE entry stays in the file until I decide

## Adding a new reference

1. Get the BibTeX from the DOI: `curl -sL -H "Accept: application/x-bibtex" https://doi.org/<DOI>`
2. Clean what comes back: drop footnote markers from the title (a trailing `*`), write page ranges with `--`, and remove fields the style does not print (`url`, `ISSN`, `month`)
3. Check the cleaned entry against the Crossref record before it goes in the .bib
4. Key it as author, year, and one title word (`Smith2024roads`) unless the project already uses another convention, and check that the key is free
5. Protect capitals that must stay capitals with braces (`{India}`, `{GDP}`), then say which entries were added

## Rules

- A working paper that has since been published: show both records side by side and suggest the published version; change nothing without my yes
- After fixes, a second run checks only the entries that changed

---
name: reduce-ai
description: >-
  Finds and fixes language that reads as written by AI, in text I will send, sign, or submit: flags
  AI-sounding phrases and structures, checks the text against how academic economics papers read,
  and proposes each change as a numbered old/new table for me to accept or decline. Use when asked
  "does this sound like AI", "make sure this doesn't sound like AI", "make this sound less like AI",
  "remove AI language", "does this read like an econ paper", or before a draft goes to a PI or an
  advisor.
---
# Reduce AI (basic)

From the workshop: "Building the skill requires your input. You have to tell Claude what you don't like or what sounds like AI to you." And: "It's not always effective." Swapping phrases fixes what a reader notices. Text reads as yours once you rewrite it in your own words.

## Steps

1. **Ask the two questions** about the text: What sounds like AI here, and which phrases are awkward? Does it read like an academic economics paper?
2. **Run the sweep**: `python3 <skill folder>/scripts/sweep.py <file>`, where the skill folder is `.claude/skills/reduce-ai` inside the kit and `~/.claude/skills/reduce-ai` once installed (on Windows, type `python` in place of `python3`). It prints every hit with its line number and family, then a count by family. Report the counts, then read the text as well: a word search finds only part of the problem
3. **Propose each change** in a numbered table: No., old, new, why. I accept or decline by row number. Apply only the accepted rows, and leave the rest of the text as it was
4. **Keep the meaning.** A fix never drops a number, a condition, or a qualifier; when a fix would change what a sentence claims, the sentence stays and the row asks me
5. **Learn my words.** Every word or phrase I ban goes into `banned_words.txt` in this folder, one per line, so the sweep finds it in every later chat

## Patterns the sweep flags

| Family | Examples |
|---|---|
| Contrast frames | "It's not X, it's Y"; "X, not Y"; "X, rather than Y" |
| Punctuation habits | em dashes; more colons and semicolons than the prose needs |
| Posed questions | a question the text asks and then answers itself |
| Headings about themselves | "Key takeaways", "In short", "At a glance" |
| Stock words | delve, tapestry, landscape, pivotal, crucial, notably, underscore, seamless |
| Your own list | every line of banned_words.txt |

Two families need a reader because no word search finds them: three parallel items in a row, again and again, and sentences that all run the same length.

## Your own voice, next

The stronger fix is a voice skill. Collect three or four pieces of your own writing you like, ask Claude to describe how you write, and save the description as a skill that drafts in your style.

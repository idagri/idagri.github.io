"""Flag AI-sounding language in a text, LaTeX, or Markdown file.

Prints every hit with its line number and family, then a count by family. The patterns are a
starting point: add your own words to banned_words.txt in the folder above this script.

Usage: python3 sweep.py <file>
"""
import re
import sys
from collections import Counter
from pathlib import Path

HERE = Path(__file__).resolve().parent
BANNED = HERE.parent / "banned_words.txt"

# Build the two special characters from their codes, so the patterns survive any editor
EM_DASH = chr(0x2014)
APOSTROPHE = "['" + chr(0x2019) + "]"

# Each family maps to a list of case-insensitive patterns
FAMILIES = {
    "contrast frame": [
        r"\bit" + APOSTROPHE + r"s not\b[^.;]{0,80}?,\s*(?:it" + APOSTROPHE + r"s|but)\b",
        r",\s+not\s+(?!(?:reported|shown|surprisingly|significant)\b)(?:a|an|the|just|only)?\s*\w+",
        r",\s*rather than\b",
    ],
    "em dash": [EM_DASH, r"(?<![-|])---(?![-|])"],
    "posed question": [r"\?(?=\s|$|[\"')\]}])"],
    "heading about itself": [
        r"\bkey takeaways?\b", r"\bin short\b(?=\s*[,:.}])", r"\bat a glance\b", r"\bin a nutshell\b",
        r"\btl;?dr\b", r"\bthe bottom line\b(?=\s*(?:[,:.}]|is\b))",
    ],
    "stock word": [
        r"\bdelv(?:e|es|ed|ing)\b", r"\btapestry\b",
        r"\blandscape of\b|\b(?:evolving|changing|shifting|broader|policy|research|economic|political)\s+landscape\b",
        r"\bpivotal\b", r"\bcrucial(?:ly)?\b", r"\bnotably\b", r"\bunderscor(?:e|es|ed|ing)\b",
        r"\bseamless(?:ly)?\b", r"\bmultifaceted\b", r"\bintricate\b", r"\btestament\b",
        r"\brealm\b",
    ],
}


def own_words():
    """Read the user's banned words, one per line, skipping blank lines and notes"""
    if not BANNED.exists():
        return []
    lines = BANNED.read_text(encoding="utf-8").splitlines()
    return [w.strip() for w in lines if w.strip() and not w.strip().startswith("#")]


def main():
    if len(sys.argv) != 2:
        sys.exit("Usage: python3 sweep.py <file>")
    target = Path(sys.argv[1])
    text = target.read_text(encoding="utf-8")
    families = dict(FAMILIES)
    families["your own list"] = [r"\b%s\b" % re.escape(w) for w in own_words()]
    counts = Counter()
    for n, line in enumerate(text.splitlines(), 1):
        # Skip LaTeX comment lines, which a reader never sees
        if line.lstrip().startswith("%"):
            continue
        # Skip Markdown table rules and front-matter fences, which hold dashes and no prose
        if re.fullmatch(r"[\s|:-]*", line):
            continue
        for family, patterns in families.items():
            for pat in patterns:
                for m in re.finditer(pat, line, flags=re.IGNORECASE):
                    counts[family] += 1
                    print(f"line {n} [{family}] {m.group(0).strip()!r}: {line.strip()[:120]}")
    # Count words, colons, and semicolons in prose only, leaving out comments, reference keys, and web addresses
    kept = "\n".join(l for l in text.splitlines() if not l.lstrip().startswith("%"))
    kept = re.sub(r"\\(?:label|ref|autoref|eqref|cref|cite\w*|url|href|input|include\w*)\{[^}]*\}", " ", kept)
    kept = re.sub(r"https?://\S+", " ", kept)
    words = len(re.findall(r"\w+", kept))
    colons = kept.count(":")
    semis = kept.count(";")
    print()
    print(f"{target.name}: {words} words, {colons} colons, {semis} semicolons")
    for family in families:
        print(f"  {family}: {counts[family]}")
    print(f"  total hits: {sum(counts.values())}")


if __name__ == "__main__":
    main()

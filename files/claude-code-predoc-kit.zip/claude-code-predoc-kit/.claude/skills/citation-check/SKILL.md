---
name: citation-check
description: >-
  Checks citations in a .tex or .bib file: whether each cited entry is a real paper with the right
  authors, year, journal, volume, and pages, and whether the paper supports the sentence that cites
  it. Use when asked to check, verify, or audit references, a bibliography, or a literature summary,
  or to ask "is this citation real" or "does this paper say that". Report only unless told to edit.
---
# Citation check

1. Read the sentence that cites each entry, then the entry itself. Check the entry against the saved publisher record for its DOI (in the folder the prompt names) before any other source; stay off the web when the prompt says so
2. Give each entry exactly one status:
   - VERIFIED: the record matches on authors, year, title, journal, volume, and pages, and the paper supports the sentence
   - WRONG DETAIL: a real paper with a wrong field; name the field, the value in the .bib, and the value in the record
   - FABRICATED: positive evidence that the paper does not exist as cited (the DOI belongs to a different paper, or the authors and title match no record); say what the DOI actually points to
   - UNVERIFIABLE: no record found either way (a working paper, a talk, a paper not yet public); list what was searched. This is a separate status from FABRICATED: absence of a record proves nothing
   - CLAIM MISMATCH: the metadata is right, but the paper does not report what the sentence says; quote the sentence next to what the record's summary says
3. Check the claim as well as the metadata: a real paper cited for the wrong finding is an error even when every field matches
4. Delete nothing. A FABRICATED or UNVERIFIABLE entry stays in the file until the user decides what happens to it
5. Report as a numbered table with the columns: No., entry key, status, evidence (record file and the field or passage), proposed fix. End with the questions the user has to answer, one per line

"""Estimate the effect of urban exposure on log employment in the village panel.

Python twin of main_regressions.do.
Input: 4_code_to_text/village_panel.csv (simulated village panel)
Run from the project folder.
"""
import pandas as pd
import statsmodels.formula.api as smf

panel = pd.read_csv("4_code_to_text/village_panel.csv")

# drop villages within 10 km of a city, where commuting blurs the village economy
sample = panel[panel["dist_to_city_km"] >= 10].copy()

# regress log employment on urban exposure with district fixed effects, clustered by village
model = smf.ols("ln_emp ~ urban_exposure + C(district_id)", data=sample)
result = model.fit(cov_type="cluster", cov_kwds={"groups": sample["village_id"]})

print(f"N = {int(result.nobs)}")
print(f"urban_exposure: {result.params['urban_exposure']:.4f} (SE {result.bse['urban_exposure']:.4f})")

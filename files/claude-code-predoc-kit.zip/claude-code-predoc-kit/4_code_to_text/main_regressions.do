* main_regressions.do
* Estimate the effect of urban exposure on log employment in the village panel
* Input:  4_code_to_text/village_panel.csv (simulated village panel)
* Output: 4_code_to_text/main_regressions.log
* Run from the project folder

capture log close
log using "4_code_to_text/main_regressions.log", replace text nomsg
version 18
set more off
set varabbrev off

import delimited "4_code_to_text/village_panel.csv", clear

* drop villages within 10 km of a city, where commuting blurs the village economy
drop if dist_to_city_km < 10 | missing(dist_to_city_km)

* regress log employment on urban exposure with district fixed effects, clustered by village
areg ln_emp urban_exposure, absorb(district_id) vce(cluster village_id)

log close

# Prompt Card

Every prompt of the session, in order. Copy one fenced block at a time into the Code tab. "Laptop" prompts are yours to run; "Projector" prompts are the follow-ups shown on the screen, and you are welcome to run them too.

## Setup

Laptop: check that the project rules loaded

```
ping
```

## Task 1: citation check

Laptop

```
Use the citation-check skill on the first paragraph of 1_citation_check/lit_summary.tex and the entries it cites in 1_citation_check/lit.bib. For each entry: is it a real paper with the right authors, year, and journal, and does the paper support the sentence that cites it? Use only the saved records in 1_citation_check/publisher_records/ and stay off the web. Report only, as a numbered table: entry, status (VERIFIED, WRONG DETAIL, FABRICATED, UNVERIFIABLE, or CLAIM MISMATCH), the evidence, the proposed fix. Do not edit any file and do not delete any entry.
```

Projector follow-up

```
Apply the WRONG DETAIL fix in 1_citation_check/lit.bib. Keep the UNVERIFIABLE entry as it is: I saw that paper presented and it is not public yet. For the CLAIM MISMATCH, show me the current sentence and your proposed rewording side by side before you change anything. Tell me what the FABRICATED entry claimed to be, and do not delete it until I say so.
```

## Task 2: do-file review with a lessons skill

Laptop (Stata users)

```
Review 2_dofile_review/build_district_totals.do for silent bugs before I run it. Do not run it.
```

Laptop (Python users)

```
Review 2_dofile_review/build_district_totals.py for silent bugs before I run it. Do not run it.
```

Projector follow-up 1

```
Add what you just found as a numbered lesson in my lessons skill, with a one-line Rule and the incident, and add a text search to references/checklist.md that catches it next time.
```

Projector follow-up 2

```
Now fix the file.
```

## Task 3: close-off with a handoff

Laptop

```
Read TODO.md and notes/ first. Are we done? What is outstanding?
```

Projector follow-up (then open a new session and paste only the blurb it prints)

```
Hand the open item to a fresh chat: write the handoff file and print the blurb. If you can offer it as a task chip, do that too.
```

## Task 4 (backup module): code-to-text audit

Laptop

```
Audit the draft section in 4_code_to_text/ against the do-file in 4_code_to_text/. For every claim in the text about the sample, the specification, the fixed effects, the clustering, and the variable definitions: quote the sentence with its line number, cite the code line that implements it, say whether they agree, and for each disagreement say which side you would change and why. Do not edit either file and do not run anything. End with two short lists: what checks out, and what you could not verify from the files.
```

Projector follow-up

```
Apply fix 2 to the text only, and show me the old and new sentence side by side.
```

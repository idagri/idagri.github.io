# Setup for the Claude Code Predoc Kit

The village panel is simulated, and the code and drafts were written for this kit as teaching material; none of it comes from a real research project. The literature summary in `1_citation_check/` cites real papers next to deliberate citation errors, including invented authors and an invented paper, for the citation-check exercise; do not cite anything from it.

## Before the session (5 minutes)

1. Download `claude-code-predoc-kit.zip` and unzip it
   - Mac: double-click the zip in Finder; move the folder `claude-code-predoc-kit` to Documents
   - Windows: right-click the zip, choose "Extract All", and extract to Documents
   - Windows may nest the folder one level deep; the folder to open is the one that holds `CLAUDE.md`
2. Open the Claude Desktop app, sign in with your UChicago account, and open the **Code** tab
3. Choose the folder: select `claude-code-predoc-kit`, the top folder that holds `CLAUDE.md`
4. Find the mode picker next to the message box. It starts in **Manual** (Claude asks before each action). Switch it to **Auto** for the session
5. Type `ping` and send it

## What the reply should say

One line that starts `pong: kit rules loaded` and names the markers, the close-off, the data rules, and the code gate. If you see it, the project rules in `CLAUDE.md` are loaded. If the reply is anything else, check that you opened the top folder of the kit, start a new session, and send `ping` again.

## What is in the folder

- The project rules (every task): the reply markers, the close-off, the data rules, and the code gate
- The prompt card (every task): copy each prompt from it
- Task 1: a two-page literature summary, its bibliography, and saved publisher records
- Task 2: a district totals build in Stata and in Python
- Task 3: the to-do list and one dated note, for the close-off
- Task 4 (backup): a draft empirical section, the do-file, its Python twin, and the log
- Skills: the citation-check skill and two starter lessons skills (Stata and Python)
- Data: 500 simulated villages in 50 districts, 2000 and 2010

Where each one sits, in the order above:

```
CLAUDE.md
prompt_card.md
1_citation_check/
2_dofile_review/
TODO.md and notes/
4_code_to_text/
.claude/skills/
data/village_panel.csv
```

The laptop prompts read files only. Nothing in the session needs Stata or Python to be installed, and no prompt asks Claude to run code.

## Take-home: installing the skills and rules for your own projects

1. Copy a skill folder to your personal skills folder, so every project sees it
   - Mac: `~/.claude/skills/` (for example `~/.claude/skills/my-stata-lessons/`)
   - Windows: `%USERPROFILE%\.claude\skills\` (for example `%USERPROFILE%\.claude\skills\my-stata-lessons\`)
2. Rewrite the `description` at the top of each `SKILL.md` in the words of your own project, since the description decides when the skill loads
3. Paste the blocks you want from this kit's `CLAUDE.md` into your personal rules file (Mac `~/.claude/CLAUDE.md`, Windows `%USERPROFILE%\.claude\CLAUDE.md`) or into a project's own `CLAUDE.md`
4. Keep adding lessons: when a mistake bites, ask Claude to add it as a numbered lesson with a one-line Rule and a checklist line

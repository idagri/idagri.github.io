# TODO

## Open
- Write the guard after the district collapse in `2_dofile_review/build_district_totals.do`: assert that the collapse returns 50 districts in each of the two years and that no district's employment total is a zero produced by an all-missing district (not written yet)

## Done
- Wrote the district totals build in Stata and Python (`2_dofile_review/`), September 22, 2026; see `notes/2026_09_22_district_totals_build.md`

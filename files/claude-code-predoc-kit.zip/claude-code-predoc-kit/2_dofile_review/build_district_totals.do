* build_district_totals.do
* Build district totals of population and employment for 2000 and 2010
* Input:  data/village_panel.csv (simulated village panel)
* Output: processed/villages_01_levels.dta and processed/district_totals_02.dta
* Run from the project folder

clear all
set more off

import delimited "data/village_panel.csv", clear

* convert log population and log employment to levels
gen pop = exp(ln_pop)
gen emp = exp(ln_emp)

* blank employment in district 17, where the employment module was not fielded
replace emp = . if district_id == 17

* compute employment per resident, the village outcome for the district maps
gen emp_pc = emp / pop
* remove the predicted-employment helper that an earlier version of this file created
cap drop emp_p

* save the village file with levels and employment per resident
save "processed/villages_01_levels.dta", replace

* sum population and employment to the district
collapse (sum) pop emp, by(district_id year)

* compute the district employment rate
gen emp_rate = emp / pop

save "processed/district_totals_02.dta", replace

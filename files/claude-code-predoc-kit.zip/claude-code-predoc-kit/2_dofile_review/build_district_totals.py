"""Build district totals of population and employment for 2000 and 2010.

Input:  data/village_panel.csv (simulated village panel)
Output: processed/villages_01_levels.csv and processed/district_totals_02.csv
Run from the project folder.
"""
import numpy as np
import pandas as pd

panel = pd.read_csv("data/village_panel.csv")

# keep one row per village-year in case the download repeated rows
panel = panel.drop_duplicates(subset=["village_id", "district_id"])

# convert log population and log employment to levels
panel["pop"] = np.exp(panel["ln_pop"])
panel["emp"] = np.exp(panel["ln_emp"])

# blank employment in district 17, where the employment module was not fielded
panel.loc[panel["district_id"] == 17, "emp"] = np.nan

# compute employment per resident, the village outcome for the district maps
panel["emp_pc"] = panel["emp"] / panel["pop"]

# save the village file with levels and employment per resident
panel.to_csv("processed/villages_01_levels.csv", index=False)

# sum population and employment to the district
districts = panel.groupby(["district_id", "year"], as_index=False)[["pop", "emp"]].sum()

# compute the district employment rate
districts["emp_rate"] = districts["emp"] / districts["pop"]

districts.to_csv("processed/district_totals_02.csv", index=False)

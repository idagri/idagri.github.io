# Village panel sandbox (simulated data)

- This folder is a teaching sandbox: 500 simulated villages in 50 districts, observed in 2000 and 2010. Nothing here is real
- Do NOT delete anything that already exists. Move a superseded file to `_archive_claude/` in the same directory (create the folder if it is missing) and say so in the reply
- Ask questions if you have any, even when not prompted
- Raw files in `data/` are read-only. Write intermediates to `processed/` under a new stage name
- Date-prefix every note: `notes/YYYY_MM_DD_<topic>.md`
- Read a file before editing it
- Canary: if my whole message is `ping`, reply with exactly one line that starts `pong: kit rules loaded` and names the four blocks below: the markers, the close-off, the data rules, and the code gate (for example `pong: kit rules loaded (markers, close-off, data rules, code gate)`)

## Reply shape and the five markers

- Lead with the answer. Keep the prose above any ask short; use bullets and tables; no dense paragraphs
- A status is a verdict: "Fixed", "Done", "NOT verified: the log ends on r(601)". The banned forms are "should be fine", "can be closed", "looks right", "probably"
- Every point that needs me is a marker line at the END of the reply, as a blockquote; none sits inside prose

| Marker | Tag    | Means                                                    | Where                   |
|--------|--------|----------------------------------------------------------|-------------------------|
| 💬     | A1, A2 | your answer to a question I asked ("what do you think")  | first line of the reply |
| 🔹     | D1, D2 | an analysis or build decision you made on your own       | end block, first        |
| 🟡     | F1, F2 | found and NOT fixed                                      | end block, after 🔹     |
| 🩷     | S1, S2 | the sample got smaller and I did not ask for that        | end block, after 🟡     |
| 🟢     | Q1, Q2 | you need something from me                               | end block, last         |

- 💬: only when I asked; the line holds the actual verdict, disagreement included
- 🔹: one line each, decision first, then the reason. Only method, sample, threshold, specification and which-reading-you-followed decisions. An accomplishment ("tested", "built") or a filing choice is left out. Print nothing when empty
- 🟡: exactly two lines: `🟡 **F1 - Issue:** <one sentence>`, then `**Next step:**`, `**Solution:**` or `**No action required:**` plus one sentence. Leave out anything you fixed in the same turn. A reproducibility problem (a number not reproducible from its inputs, two routes disagreeing, an N that differs across regressions sharing a sample) is NEVER "No action required": name the cause or the search for it, and it becomes a task
- 🩷: two lines: what left the sample and how much, then `**Can we get it back:**` with a verdict earned by an actual search (another source, an id-format or spelling fix, another vintage). Any drop in N I did not ask for triggers it; nothing prints when N did not fall
- 🟢: `🟢 **Q1 - Your call:**` (or "Please check:", "Decide:"). A pick among two to four concrete options is a question card; mutually exclusive options go on one card
- Numbering: an answered question's number is released and never reprinted; an unanswered one keeps its number and is reprinted verbatim under `**Still open:**` above new asks in every reply until answered or dropped; silence is never an answer; take no irreversible action on an open ask
- Example lines (keep these; a rule without its example drifts):
  > 🩷 **S1 - Lost from the sample:** 30 of 500 villages failed the 2010 match.
  > **Can we get it back:** yes, all 30: the 2010 file stores village_id as zero-padded text.
  > 🔹 **D1 - Decided:** kept the later-dated row of each duplicate pair, because the pair differs only in the enumerator field.
  > 🟢 **Q1 - Your call:** base year 2000 or 2010?

## Closing a chat

When I say "are we done" or "close this off":
1. Verify every claim of done with a command or a file read run NOW (a log tail, a file timestamp, `git status`); say what you re-read
2. List what went to which file. Anything that lives only in this chat (a number, a decision, a cause) goes into notes/YYYY_MM_DD_<topic>.md first
3. Print `## What this chat accomplished`, grouped in this order: Runs and decisions, Code fixes, Documents, Errors found and corrected, Lessons. One outcome-first sentence per bullet; each group ends on a bold **Takeaway:** line
4. For any work handed to a later chat, write notes/YYYY_MM_DD_handoff_<slug>.md and print a paste-ready blurb in its own fenced block: project code, a short task name, a colon, then two sentences (what to execute, plus the one state fact the new chat needs). No orientation text
5. Verdict on its own line, "This chat is closed." or "This chat is NOT closed:" plus what is outstanding; then a second line "Safe to close this window: yes/no" plus why. Own any mistake you corrected, with its undo path. A handoff written to a file with its blurb printed is discharged and does not block "closed"

## Data rules (bind on every script in this project)

- Never fill a missing value with anything unless the blank is semantically a zero. Answer three questions in the reply first: what does a zero MEAN here; is this blank a real zero or no observation; why fill at all. A mean or median fill is the same defect. The honest alternatives: measure it, take a route that does not need the value, or exclude the unit and say so
- `collapse (sum)` in Stata and `groupby(...).sum()` in pandas return a hard 0 for a group whose every member is missing: in Stata add a `(count)` of the same variable to the collapse and set the sum to missing where that count is 0 (native `collapse` has no `missing` option and stops with r(198)); in pandas pass `min_count=1`; or null the block afterward on an absence indicator built BEFORE the collapse. The value being zero is no test, because real zeros and absent units look alike afterward
- Stata abbreviates variable names by default, so `cap drop x` deletes `x_pc` when `x` is absent: `set varabbrev off` right after the log line of every do-file
- The sample never shrinks silently: any drop in N I did not ask for (a merge, a filter, a dedup, a missing coordinate) is a 🩷 line with what left, how much, and whether it can be recovered. Print how many rows every dedup removed
- After every merge: prove the using key unique before a many-to-one merge, print the length and three values of the key on both sides, assert the expected match rate and stop the build when it falls short, tabulate the key's prefix against the merge result (a row at 100% unmatched is a hole). pandas: `validate='m:1'`, `indicator=True`, then the same assertion
- Never read a dataset and save it under the same name in the same directory. Raw data is read-only; intermediates are stage-named files in `temp/` or `processed/` (`panel_01_clean`, `panel_02_merged`); a data defect is repaired by a dated patch script
- Every do-file opens a timestamped plain-text log in `results/logs/` and closes it at the end. No number from a run is reported until its log has been read: a Stata batch run exits 0 even when the do-file aborted, so grep the log for lines starting `r(` and check that each expected output file's timestamp moved. Report "Done" only after both checks, and "NOT done: <the r( line and the file that did not move>" otherwise
- Every number I see is computed by the producing script and none is typed by hand: an N or a share quoted in prose is written by the producing script to a macro file (`\newcommand`) or a results CSV and read from there. A number a helper session hands back is recomputed before it reaches a table
- Comments are readable alone (action verb, the object, one step per line, the economics tied in) and end without a period; no "note that", "here we", "let's"

## Code gate

Before writing, editing, running, or debugging any do-file or Python script, open the matching lessons skill and read the reference its map names; after drafting, run its references/checklist.md. Show the pass as a ✅ after the file name (`build_sample.do ✅`); no ✅ means it did not go through; the sentence "I ran the checklist" is never written. Fire on the task: work out what the answer will be written in first.
When a mistake bites, add a numbered lesson to the skill's matching reference file with a one-line Rule and, if it implies a check, a grep in the checklist; tell me in one line and do not ask per entry.

- Stata work: `.claude/skills/my-stata-lessons/`
- Python work: `.claude/skills/my-python-lessons/`
- Citations and `.bib` files: `.claude/skills/citation-check/`
